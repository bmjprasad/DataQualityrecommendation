import streamlit as st
import requests
import base64
import json
from typing import List, Dict, Optional
import os
from datetime import datetime

# Configuration
AZURE_DEVOPS_ORG = os.getenv("AZURE_DEVOPS_ORG", "")
AZURE_DEVOPS_PROJECT = os.getenv("AZURE_DEVOPS_PROJECT", "")
AZURE_DEVOPS_REPO = os.getenv("AZURE_DEVOPS_REPO", "")
AZURE_DEVOPS_PAT = os.getenv("AZURE_DEVOPS_PAT", "")
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "")  # Your GitHub Personal Access Token with Copilot access

st.set_page_config(
    page_title="Azure DevOps Copilot Assistant",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        background: linear-gradient(90deg, #0078d4, #00bcf2);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 0.5rem;
    }
    .stChatMessage {
        padding: 1rem;
        border-radius: 0.5rem;
        margin-bottom: 1rem;
    }
    .copilot-badge {
        display: inline-block;
        padding: 4px 8px;
        background: linear-gradient(135deg, #7928CA 0%, #FF0080 100%);
        color: white;
        border-radius: 4px;
        font-size: 12px;
        font-weight: bold;
        margin-left: 8px;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if "messages" not in st.session_state:
    st.session_state.messages = []

if "repo_context" not in st.session_state:
    st.session_state.repo_context = {}

if "file_contents" not in st.session_state:
    st.session_state.file_contents = {}


class AzureDevOpsRepository:
    """Azure DevOps Repository Client that reads actual file content"""
    
    def __init__(self, org: str, project: str, repo: str, pat: str):
        self.org = org
        self.project = project
        self.repo = repo
        self.pat = pat
        self.base_url = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}"
        
        # Encode PAT for Basic Auth
        encoded_pat = base64.b64encode(f":{pat}".encode()).decode()
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Basic {encoded_pat}"
        }
    
    def get_repository_items(self, path: str = "/", recursion_level: str = "Full") -> List[Dict]:
        """Get all items in repository"""
        url = f"{self.base_url}/items"
        params = {
            "scopePath": path,
            "recursionLevel": recursion_level,
            "api-version": "7.0"
        }
        
        try:
            response = requests.get(url, params=params, headers=self.headers, timeout=30)
            response.raise_for_status()
            items = response.json().get("value", [])
            return [item for item in items if not item.get("isFolder", False)]
        except Exception as e:
            st.error(f"❌ Error fetching repository items: {e}")
            return []
    
    def get_file_content(self, path: str) -> Optional[str]:
        """Get actual content of a specific file"""
        url = f"{self.base_url}/items"
        params = {
            "path": path,
            "api-version": "7.0",
            "includeContent": "true"
        }
        
        try:
            response = requests.get(url, params=params, headers=self.headers, timeout=30)
            response.raise_for_status()
            return response.text
        except Exception as e:
            return f"Error reading file: {e}"
    
    def get_multiple_file_contents(self, file_paths: List[str], max_files: int = 25) -> Dict[str, str]:
        """Get content of multiple files"""
        contents = {}
        for i, path in enumerate(file_paths[:max_files]):
            if i >= max_files:
                break
            content = self.get_file_content(path)
            if content and not content.startswith("Error"):
                contents[path] = content
        return contents
    
    def get_repository_structure(self) -> str:
        """Get formatted repository structure"""
        items = self.get_repository_items()
        
        structure = f"# Repository: {self.repo}\n"
        structure += f"Organization: {self.org} | Project: {self.project}\n"
        structure += f"Total Files: {len(items)}\n\n"
        
        # Organize by directory
        directories = {}
        for item in items:
            path = item.get("path", "")
            parts = path.split("/")
            
            if len(parts) > 1:
                directory = "/".join(parts[:-1])
                if directory not in directories:
                    directories[directory] = []
                directories[directory].append(parts[-1])
            else:
                if "root" not in directories:
                    directories["root"] = []
                directories["root"].append(path)
        
        # Format structure
        for directory, files in sorted(directories.items())[:30]:
            structure += f"\n📁 {directory}\n"
            for file in files[:10]:
                structure += f"  └─ {file}\n"
        
        return structure


class GitHubCopilotClient:
    """Client for GitHub Copilot Chat API"""
    
    def __init__(self, github_token: str):
        self.github_token = github_token
        self.headers = {
            "Authorization": f"token {github_token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28"
        }
    
    def chat_completion(self, messages: List[Dict], repo_context: str) -> str:
        """
        Use GitHub Copilot for chat completion
        
        Note: This uses the GitHub Models API which provides access to various AI models
        including those used by Copilot. For direct Copilot API access, you need
        GitHub Copilot Business or Enterprise.
        """
        
        # GitHub Models API endpoint (available with GitHub Copilot)
        url = "https://api.github.com/models/gpt-4o/chat/completions"
        
        # Alternative: If your organization has Copilot Business/Enterprise
        # url = "https://api.githubcopilot.com/chat/completions"
        
        # Prepare system message with repository context
        system_message = f"""You are GitHub Copilot, an AI coding assistant analyzing an Azure DevOps repository.

REPOSITORY CONTEXT:
{repo_context}

Provide helpful, accurate answers based on the actual code and files in this repository.
When referencing code, be specific about file names and implementations.
"""
        
        # Prepare messages
        all_messages = [
            {"role": "system", "content": system_message}
        ] + messages
        
        payload = {
            "messages": all_messages,
            "temperature": 0.7,
            "max_tokens": 2000,
            "top_p": 1.0
        }
        
        try:
            response = requests.post(url, headers=self.headers, json=payload, timeout=60)
            response.raise_for_status()
            
            result = response.json()
            return result["choices"][0]["message"]["content"]
        
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                return self._fallback_response(messages, repo_context)
            else:
                return f"❌ GitHub API Error: {e.response.status_code}\n\n{e.response.text}"
        except Exception as e:
            return f"❌ Error calling GitHub Copilot: {str(e)}"
    
    def _fallback_response(self, messages: List[Dict], repo_context: str) -> str:
        """
        Fallback response when GitHub Models API is not available.
        This provides instructions for using VS Code Copilot Chat instead.
        """
        
        user_question = messages[-1]["content"] if messages else ""
        
        return f"""🔧 **GitHub Copilot Integration Info**

I see you're asking: "{user_question}"

**Using GitHub Copilot in VS Code:**

Since direct API access requires GitHub Copilot Business/Enterprise, here's how to use Copilot in VS Code:

1. **Open your repository in VS Code**
2. **Press `Ctrl+I` (or `Cmd+I` on Mac)** to open Copilot Chat
3. **Ask your question there**

**Alternative - Manual Analysis:**

Based on your repository context:
{repo_context[:1000]}...

To get the best help:
- Use Copilot Chat directly in VS Code (`Ctrl+I`)
- Or ask me specific questions about files, and I'll show you the content
- Or use the special commands like `show file: /path/to/file`

**Special Commands Available:**
- `show file: <path>` - Display specific file content
- `list python files` - Show all Python files
- `list config files` - Show configuration files
"""


def build_intelligent_context(ado_client: AzureDevOpsRepository) -> Dict[str, any]:
    """Build comprehensive context with actual file contents"""
    
    with st.spinner("🔍 Reading repository structure..."):
        all_files = ado_client.get_repository_items()
        
        # Categorize files
        code_files = []
        config_files = []
        doc_files = []
        
        for item in all_files:
            path = item.get("path", "")
            
            if any(path.endswith(ext) for ext in ['.py', '.js', '.ts', '.java', '.cs', '.go', '.cpp', '.c', '.rb', '.php']):
                code_files.append(path)
            elif any(path.endswith(ext) for ext in ['.json', '.yaml', '.yml', '.xml', '.toml', '.ini', '.config']):
                config_files.append(path)
            elif any(path.endswith(ext) for ext in ['.md', '.txt', '.rst', '.adoc']):
                doc_files.append(path)
    
    with st.spinner(f"📖 Reading content from {min(len(code_files), 15)} code files..."):
        important_files = code_files[:15] + config_files[:8] + doc_files[:2]
        file_contents = ado_client.get_multiple_file_contents(important_files, max_files=25)
    
    # Build context
    context = {
        "structure": ado_client.get_repository_structure(),
        "file_list": {
            "code_files": code_files,
            "config_files": config_files,
            "doc_files": doc_files
        },
        "file_contents": file_contents,
        "total_files": len(all_files),
        "loaded_at": datetime.now().isoformat()
    }
    
    return context


def create_copilot_context(repo_context: Dict) -> str:
    """Create context string for GitHub Copilot"""
    
    context = f"""REPOSITORY STRUCTURE:
{repo_context.get('structure', 'No structure available')}

FILE STATISTICS:
- Code Files: {len(repo_context.get('file_list', {}).get('code_files', []))}
- Config Files: {len(repo_context.get('file_list', {}).get('config_files', []))}
- Documentation: {len(repo_context.get('file_list', {}).get('doc_files', []))}

ACTUAL FILE CONTENTS:
"""
    
    file_contents = repo_context.get('file_contents', {})
    for file_path, content in list(file_contents.items())[:8]:
        context += f"\n--- {file_path} ---\n"
        if len(content) > 1500:
            context += content[:1500] + "\n... (truncated)"
        else:
            context += content
        context += "\n"
    
    return context


def chat_with_copilot(user_message: str, repo_context: Dict, conversation_history: List[Dict]) -> str:
    """Generate response using GitHub Copilot"""
    
    if not GITHUB_TOKEN:
        return """⚠️ **GitHub Token Required**

To use GitHub Copilot:

**Option 1: Get GitHub Personal Access Token**
1. Go to https://github.com/settings/tokens
2. Click "Generate new token (classic)"
3. Select scopes: `repo`, `user`, `copilot`
4. Copy the token
5. Add to `.env`: `GITHUB_TOKEN=your_token_here`

**Option 2: Use VS Code Copilot Directly**
1. Open your repo in VS Code
2. Press `Ctrl+I` (Windows) or `Cmd+I` (Mac)
3. Ask your questions there

**Option 3: Special Commands (No Token Needed)**
- `show file: /path/to/file` - View file content
- `list python files` - List all Python files
- `list config files` - List configuration files
"""
    
    try:
        copilot_client = GitHubCopilotClient(GITHUB_TOKEN)
        context = create_copilot_context(repo_context)
        
        # Prepare messages
        messages = []
        for msg in conversation_history[-5:]:  # Last 5 messages for context
            messages.append({
                "role": msg["role"],
                "content": msg["content"]
            })
        
        # Get Copilot response
        response = copilot_client.chat_completion(messages, context)
        return response
    
    except Exception as e:
        return f"❌ Error: {str(e)}\n\nTry using VS Code Copilot Chat instead (`Ctrl+I`)"


def handle_special_commands(user_input: str, ado_client: AzureDevOpsRepository, repo_context: Dict) -> Optional[str]:
    """Handle special commands for file operations"""
    
    user_input_lower = user_input.lower()
    
    # Show specific file content
    if user_input_lower.startswith("show file:") or user_input_lower.startswith("read file:"):
        file_path = user_input.split(":", 1)[1].strip()
        content = ado_client.get_file_content(file_path)
        return f"### 📄 File: `{file_path}`\n\n```\n{content}\n```"
    
    # List files by type
    if "list python files" in user_input_lower:
        python_files = [f for f in repo_context.get('file_list', {}).get('code_files', []) if f.endswith('.py')]
        return "**Python Files:**\n" + "\n".join(f"- {f}" for f in python_files[:50])
    
    if "list javascript files" in user_input_lower or "list js files" in user_input_lower:
        js_files = [f for f in repo_context.get('file_list', {}).get('code_files', []) 
                   if f.endswith(('.js', '.ts', '.jsx', '.tsx'))]
        return "**JavaScript/TypeScript Files:**\n" + "\n".join(f"- {f}" for f in js_files[:50])
    
    if "list config files" in user_input_lower:
        config_files = repo_context.get('file_list', {}).get('config_files', [])
        return "**Configuration Files:**\n" + "\n".join(f"- {f}" for f in config_files[:50])
    
    if "show structure" in user_input_lower or "show repo" in user_input_lower:
        return repo_context.get('structure', 'Repository structure not available')
    
    return None


# ============================================
# SIDEBAR CONFIGURATION
# ============================================

with st.sidebar:
    st.title("⚙️ Configuration")
    
    with st.expander("🔐 Azure DevOps Settings", expanded=True):
        org = st.text_input("Organization", value=AZURE_DEVOPS_ORG, key="org")
        project = st.text_input("Project", value=AZURE_DEVOPS_PROJECT, key="project")
        repo = st.text_input("Repository", value=AZURE_DEVOPS_REPO, key="repo")
        pat = st.text_input("PAT Token", type="password", value=AZURE_DEVOPS_PAT, key="pat")
    
    with st.expander("🤖 GitHub Copilot Settings", expanded=True):
        github_token = st.text_input("GitHub Token", type="password", value=GITHUB_TOKEN, key="github_token",
                                     help="Get from https://github.com/settings/tokens")
        
        if github_token:
            st.success("✅ GitHub Token configured")
        else:
            st.info("ℹ️ Optional: Add GitHub token for Copilot API access")
    
    st.divider()
    
    # Load Repository Button
    if st.button("🔄 Load Repository", use_container_width=True, type="primary"):
        if all([org, project, repo, pat]):
            try:
                with st.spinner("🚀 Loading repository..."):
                    ado_client = AzureDevOpsRepository(org, project, repo, pat)
                    st.session_state.ado_client = ado_client
                    st.session_state.repo_context = build_intelligent_context(ado_client)
                    st.success("✅ Repository loaded!")
                    st.balloons()
            except Exception as e:
                st.error(f"❌ Error: {e}")
        else:
            st.error("⚠️ Please fill in all Azure DevOps fields")
    
    if st.button("🗑️ Clear Chat", use_container_width=True):
        st.session_state.messages = []
        st.rerun()
    
    st.divider()
    
    # Repository Stats
    if st.session_state.repo_context:
        st.markdown("### 📊 Repository Stats")
        ctx = st.session_state.repo_context
        
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Total Files", ctx.get('total_files', 0))
        with col2:
            st.metric("Loaded", len(ctx.get('file_contents', {})))
        
        st.metric("Code Files", len(ctx.get('file_list', {}).get('code_files', [])))
    
    st.divider()
    
    st.markdown("### 💡 Try These")
    examples = [
        "What is this repo about?",
        "Show the project structure",
        "List Python files",
        "Explain main.py",
        "What dependencies are used?"
    ]
    
    for ex in examples:
        if st.button(ex, key=f"ex_{ex}", use_container_width=True):
            st.session_state.messages.append({"role": "user", "content": ex})
            st.rerun()

# ============================================
# MAIN INTERFACE
# ============================================

st.markdown('<h1 class="main-header">🤖 Azure DevOps Assistant</h1>', unsafe_allow_html=True)
st.markdown('*Powered by <span class="copilot-badge">GitHub Copilot</span>*', unsafe_allow_html=True)

# Status Banner
if st.session_state.repo_context:
    files_loaded = len(st.session_state.repo_context.get('file_contents', {}))
    st.success(f"✅ Repository loaded with {files_loaded} files analyzed!")
elif GITHUB_TOKEN:
    st.info("👈 **Configure Azure DevOps in sidebar and load your repository**")
else:
    st.warning("⚠️ **GitHub Token not configured** - Some features limited. Add token in sidebar or use VS Code Copilot.")

st.divider()

# Display Chat Messages
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Chat Input
if prompt := st.chat_input("Ask about your repository..."):
    
    if not st.session_state.repo_context:
        st.warning("⚠️ Please load your repository first!")
    else:
        # Add user message
        st.session_state.messages.append({"role": "user", "content": prompt})
        
        with st.chat_message("user"):
            st.markdown(prompt)
        
        # Generate response
        with st.chat_message("assistant"):
            with st.spinner("🤔 Thinking..."):
                
                # Check for special commands
                special_response = handle_special_commands(
                    prompt,
                    st.session_state.ado_client,
                    st.session_state.repo_context
                )
                
                if special_response:
                    response = special_response
                else:
                    # Use GitHub Copilot
                    response = chat_with_copilot(
                        prompt,
                        st.session_state.repo_context,
                        st.session_state.messages
                    )
                
                st.markdown(response)
        
        st.session_state.messages.append({"role": "assistant", "content": response})

# Footer
st.divider()
st.markdown("""
<div style='text-align: center; color: #666;'>
    <p><b>Special Commands:</b></p>
    <p><code>show file: /path</code> | <code>list python files</code> | <code>show structure</code></p>
</div>
""", unsafe_allow_html=True)

st.caption("🚀 Powered by GitHub Copilot + Azure DevOps | Built with Streamlit")
