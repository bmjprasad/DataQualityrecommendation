# Azure DevOps Chatbot with GitHub Copilot 🤖

## Perfect for Organizations with GitHub Copilot! ✅

This chatbot is designed for companies that **already have GitHub Copilot** but don't have OpenAI API access.

---

## 🎯 What This Does

✅ Reads your **Azure DevOps repository content**  
✅ Uses **GitHub Copilot** (your existing license!)  
✅ Works in **Streamlit UI** for easy team access  
✅ Integrates with **VS Code Copilot Chat**  
✅ No OpenAI API needed!  

---

## 🚀 Quick Setup (5 Minutes)

### Step 1: Install Python Dependencies

```bash
pip install streamlit requests python-dotenv
```

### Step 2: Get Azure DevOps PAT Token

1. Go to `https://dev.azure.com/{your-org}`
2. Click profile icon → **Personal Access Tokens**
3. Click **+ New Token**
4. Name: `Chatbot Reader`
5. Scopes: **Code (Read)** ✅
6. Click **Create** and copy the token

### Step 3: Get GitHub Personal Access Token

Since you have GitHub Copilot, you need a GitHub token:

1. Go to https://github.com/settings/tokens
2. Click **Generate new token (classic)**
3. Name: `Azure DevOps Chatbot`
4. Select scopes:
   - ✅ `repo` (Full control of repositories)
   - ✅ `user` (Read user profile)
   - ✅ `copilot` (Access to GitHub Copilot) - if available
5. Click **Generate token**
6. **Copy the token immediately**

### Step 4: Create `.env` File

Create a file named `.env`:

```env
# Azure DevOps Configuration
AZURE_DEVOPS_ORG=your-organization
AZURE_DEVOPS_PROJECT=your-project
AZURE_DEVOPS_REPO=your-repository
AZURE_DEVOPS_PAT=your-azure-devops-pat-token

# GitHub Token (for Copilot access)
GITHUB_TOKEN=ghp_your_github_token_here
```

### Step 5: Run the Chatbot

```bash
streamlit run github_copilot_chatbot.py
```

---

## 💡 Three Ways to Use GitHub Copilot

### Option 1: Direct API Access (Copilot Business/Enterprise)

If your company has **GitHub Copilot Business or Enterprise**:

✅ Configure GitHub token in `.env`  
✅ The chatbot will use Copilot API directly  
✅ Get AI responses in the Streamlit UI  

### Option 2: VS Code Copilot Integration (Recommended)

The chatbot shows you repository content, then you use VS Code Copilot:

1. **Load repository** in the Streamlit app
2. **View file contents** and structure
3. **Copy relevant context** 
4. **Open VS Code** and press `Ctrl+I` (or `Cmd+I`)
5. **Paste context** and ask questions in Copilot Chat

**Example workflow:**

```
1. In Streamlit: "show file: /src/main.py"
   → Copy the displayed code

2. In VS Code Copilot Chat (Ctrl+I):
   "Here's main.py from our Azure DevOps repo:
   [paste code]
   
   Question: How does the authentication work?"
```

### Option 3: Special Commands (No AI Needed)

Use built-in commands to explore your repo:

- `show file: /path/to/file` - Display file content
- `list python files` - Show all .py files
- `list javascript files` - Show all .js/.ts files
- `list config files` - Show configuration files
- `show structure` - Display repository structure

---

## 📖 Usage Examples

### Example 1: Understanding the Codebase

**In the chatbot:**
```
You: "show structure"
```

**Response:**
```
# Repository: MyProject
Total Files: 127

📁 /src
  └─ main.py
  └─ auth.py
  └─ models.py
  └─ utils.py

📁 /tests
  └─ test_auth.py
  └─ test_models.py
```

**Then in VS Code:**
- Press `Ctrl+I`
- Ask: "Based on this structure, explain the project architecture"

### Example 2: Analyzing Specific Code

**In the chatbot:**
```
You: "show file: /src/auth.py"
```

**Response shows the actual code:**
```python
# File: /src/auth.py

import jwt
from datetime import datetime, timedelta

def generate_token(user_id):
    payload = {
        'user_id': user_id,
        'exp': datetime.utcnow() + timedelta(hours=24)
    }
    return jwt.encode(payload, SECRET_KEY, algorithm='HS256')
...
```

**Then:**
- Copy the code
- In VS Code Copilot (`Ctrl+I`): "Review this authentication code for security issues"

### Example 3: Finding Files

**In the chatbot:**
```
You: "list python files"
```

**Response:**
```
Python Files:
- /src/main.py
- /src/auth.py
- /src/models.py
- /src/database.py
- /tests/test_auth.py
- /tests/test_models.py
```

---

## 🔧 Configuration Options

### Basic Configuration (Recommended)

```env
# Minimum required - works with VS Code Copilot workflow
AZURE_DEVOPS_ORG=myorg
AZURE_DEVOPS_PROJECT=myproject
AZURE_DEVOPS_REPO=myrepo
AZURE_DEVOPS_PAT=xxxxxxxxxx
```

### Full Configuration (For API Access)

```env
# Full setup - direct Copilot API usage
AZURE_DEVOPS_ORG=myorg
AZURE_DEVOPS_PROJECT=myproject
AZURE_DEVOPS_REPO=myrepo
AZURE_DEVOPS_PAT=xxxxxxxxxx
GITHUB_TOKEN=ghp_xxxxxxxxxx
```

---

## 🎯 Best Practices

### 1. Use as a Repository Explorer

Think of this chatbot as a **smart repository viewer**:

- ✅ Load repository structure
- ✅ View file contents
- ✅ Search for specific files
- ✅ Export info to VS Code Copilot

### 2. Combine with VS Code Copilot

**Workflow:**
1. **Explore** in Streamlit chatbot
2. **Analyze** in VS Code Copilot
3. **Implement** in VS Code

### 3. Team Collaboration

**Deploy as a shared resource:**

```bash
# Run on a shared server
streamlit run github_copilot_chatbot.py --server.port 8501 --server.address 0.0.0.0
```

Team members can:
- Browse the repository
- Get file contents
- Share findings
- Use with their individual Copilot licenses

---

## 🔐 Security

### Azure DevOps PAT Token

✅ **Only needs**: Code (Read) permission  
✅ **Set expiration**: 90 days maximum  
✅ **Rotate regularly**: Every 60-90 days  
✅ **Never commit**: Add `.env` to `.gitignore`  

### GitHub Token

✅ **Use Classic Token**: Better compatibility  
✅ **Minimal scopes**: Only what you need  
✅ **Keep private**: Don't share or commit  
✅ **Monitor usage**: Check GitHub settings regularly  

### `.gitignore` File

Create this file:

```gitignore
# Environment variables
.env
.env.local

# Python
__pycache__/
*.py[cod]
*$py.class

# Streamlit
.streamlit/
```

---

## 🛠️ Troubleshooting

### Issue: "GitHub Token Required"

**Solution:**
- Add `GITHUB_TOKEN` to `.env` file
- OR use the VS Code Copilot workflow
- OR use special commands (no token needed)

### Issue: "Error 404 - Not Found" from GitHub

**This is normal!** It means:
- GitHub Models API is not available to your token
- **Use VS Code Copilot workflow instead**
- The chatbot will guide you

### Issue: "Error fetching repository items"

**Solutions:**
1. Check Azure DevOps PAT token permissions
2. Verify organization/project/repo names
3. Test token in Azure DevOps web interface

### Issue: "No files loaded"

**Solutions:**
1. Ensure repository has files
2. Check PAT token has Code (Read) permission
3. Try loading again

---

## 📊 Comparison: API vs VS Code Workflow

| Feature | With API Access | VS Code Workflow |
|---------|----------------|------------------|
| Setup Complexity | Medium | Easy |
| Cost | Included in Copilot | Free |
| Response Speed | Instant | Manual copy/paste |
| Team Access | ✅ Web UI | ❌ Individual |
| Best For | Large teams | Individual devs |

---

## 🎓 Advanced Usage

### Custom Queries

Create templates for common questions:

```python
# In sidebar, add custom buttons
if st.button("Security Audit"):
    question = "List all files and check for security issues"
    st.session_state.messages.append({"role": "user", "content": question})
```

### Export Repository Context

Add an export button:

```python
if st.button("📋 Export Context"):
    context = create_copilot_context(st.session_state.repo_context)
    st.download_button(
        label="Download Context",
        data=context,
        file_name="repo_context.txt"
    )
```

### Integration with CI/CD

Run automated repository analysis:

```bash
# In your pipeline
python analyze_repo.py --org=myorg --project=myproj --repo=myrepo
```

---

## 🚀 Deployment Options

### Local Development

```bash
streamlit run github_copilot_chatbot.py
```

### Internal Server

```bash
# Run on internal network
streamlit run github_copilot_chatbot.py \
  --server.port 8501 \
  --server.address 0.0.0.0
```

### Docker Container

```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY github_copilot_chatbot.py .
COPY .env .

EXPOSE 8501

CMD ["streamlit", "run", "github_copilot_chatbot.py"]
```

---

## 📝 Quick Reference

### Special Commands

| Command | Description |
|---------|-------------|
| `show file: <path>` | Display file content |
| `list python files` | List all .py files |
| `list javascript files` | List all .js/.ts files |
| `list config files` | List configuration files |
| `show structure` | Show repository structure |

### Keyboard Shortcuts (VS Code)

| Shortcut | Action |
|----------|--------|
| `Ctrl+I` / `Cmd+I` | Open Copilot Chat |
| `Ctrl+Shift+I` | Open Copilot inline |
| `Alt+\` | Trigger Copilot suggestion |

---

## 💡 Tips for Success

1. **Start Simple**: Load repo → View structure → Explore files
2. **Be Specific**: Ask targeted questions about specific files
3. **Use Context**: Copy relevant code to VS Code Copilot
4. **Iterate**: Refine questions based on previous answers
5. **Share Knowledge**: Use with your team for collaboration

---

## 📞 Support

**Azure DevOps Issues:**
- Check https://status.dev.azure.com/
- Verify PAT token permissions

**GitHub Copilot Issues:**
- Check https://www.githubstatus.com/
- Verify your Copilot subscription
- Try VS Code Copilot directly

**Streamlit Issues:**
- Check https://docs.streamlit.io/
- Restart the application
- Clear browser cache

---

## ✅ Success Checklist

Before using:
- [ ] Python dependencies installed
- [ ] Azure DevOps PAT token created
- [ ] GitHub token created (optional)
- [ ] `.env` file configured
- [ ] `.gitignore` file created
- [ ] Repository loaded successfully
- [ ] Files loaded (check sidebar stats)
- [ ] VS Code Copilot is working

---

## 🎉 You're Ready!

You now have a powerful tool that:
- ✅ Connects to Azure DevOps
- ✅ Reads repository content
- ✅ Integrates with GitHub Copilot
- ✅ Provides a web UI for exploration

**Start exploring your codebase!** 🚀

---

**Note**: This tool is designed to complement, not replace, your existing GitHub Copilot setup in VS Code. Use them together for the best experience!
