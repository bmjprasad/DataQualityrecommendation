# Databricks App Deployment Guide

## 📱 Building a Databricks App for Metadata Search

This guide walks you through deploying your metadata search solution as a **Databricks App** - a native application that runs directly in your Databricks workspace.

## 🎯 What is a Databricks App?

Databricks Apps allow you to build and deploy interactive web applications that:
- Run natively in your Databricks workspace
- Automatically inherit workspace authentication
- Access Delta tables and SQL Warehouses securely
- Can be shared with other workspace users
- Support Streamlit, Dash, Gradio, and Flask

## 📋 Prerequisites

- Databricks workspace (AWS, Azure, or GCP)
- Unity Catalog enabled
- SQL Warehouse created and running
- Metadata loaded into Delta tables
- Databricks CLI installed

## 🚀 Quick Start

### Step 1: Prepare Files

Your app directory structure:
```
metadata-search-app/
├── app.py                          # Main Streamlit app
├── databricks_app.yaml             # App configuration  
├── databricks_app_requirements.txt # Dependencies
└── README.md                       # Documentation
```

### Step 2: Configure Secrets

```bash
# Create secret scope
databricks secrets create-scope --scope metadata

# Add credentials
databricks secrets put --scope metadata --key server_hostname
databricks secrets put --scope metadata --key http_path
databricks secrets put --scope metadata --key token
```

### Step 3: Deploy

```bash
# Using Databricks CLI
databricks apps deploy \
    --name data-catalog-search \
    --source-directory . \
    --description "Metadata search application"

# Access your app
# https://your-workspace.cloud.databricks.com/apps/data-catalog-search
```

## 🎨 Key Features

The Databricks App includes:

✅ **Full-text search** across tables, columns, and descriptions
✅ **Advanced filtering** by source, database, schema, PII status
✅ **Table details** with complete column information
✅ **Access management** showing required AD groups
✅ **Statistics dashboard** with data type distributions
✅ **Responsive UI** with modern design
✅ **Real-time** data from Delta tables

## 📊 App Screenshots

### Search Interface
- Search bar with auto-complete
- Faceted filters (source, database, schema, PII)
- Results displayed as cards
- Real-time statistics

### Table Details
- Complete metadata overview
- Column list with data types
- PII indicators
- Access group information
- Statistics and visualizations

## 🔐 Security

The app implements:
- **Workspace SSO**: Automatic authentication
- **Row-level security**: User-specific data filtering
- **Audit logging**: All searches tracked
- **PII masking**: Sensitive data protection
- **Secrets management**: Secure credential storage

## 📈 Monitoring

Built-in monitoring features:
- Health checks for database connectivity
- Data freshness indicators
- Usage analytics
- Popular searches tracking
- Error logging

## 🛠️ Customization

Easy to customize:
- Update branding and colors
- Add company logo
- Modify search algorithms
- Add custom metrics
- Integrate with other tools

## 📚 Additional Resources

- See `app.py` for full application code
- See `DATABRICKS_DELTA_SERVING_GUIDE.md` for data setup
- See `QUICK_REFERENCE.md` for SQL queries
- [Databricks Apps Docs](https://docs.databricks.com/apps/)

## 🎉 Summary

Deploy a production-ready metadata search app in minutes with full Databricks integration!
