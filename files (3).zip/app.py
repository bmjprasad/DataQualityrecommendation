"""
Databricks App: Metadata Search and Discovery
A Streamlit-based UI for searching and discovering data assets
"""

import streamlit as st
from databricks import sql
import pandas as pd
import os
from datetime import datetime
import json

# Page configuration
st.set_page_config(
    page_title="Data Catalog Search",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: 700;
        color: #1E3A8A;
        margin-bottom: 1rem;
    }
    .sub-header {
        font-size: 1.2rem;
        color: #6B7280;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1.5rem;
        border-radius: 10px;
        color: white;
        margin-bottom: 1rem;
    }
    .table-card {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        margin-bottom: 1rem;
        border-left: 4px solid #667eea;
    }
    .source-badge {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 12px;
        font-size: 0.75rem;
        font-weight: 600;
        margin-right: 0.5rem;
    }
    .badge-databricks { background: #FF3621; color: white; }
    .badge-hive { background: #FDDB3A; color: #333; }
    .badge-db2 { background: #0066CC; color: white; }
    .badge-erwin { background: #6B4C9A; color: white; }
    .pii-badge {
        background: #EF4444;
        color: white;
        padding: 0.25rem 0.5rem;
        border-radius: 8px;
        font-size: 0.7rem;
        font-weight: 600;
    }
    .access-group {
        background: #F3F4F6;
        padding: 0.75rem;
        border-radius: 8px;
        margin-bottom: 0.5rem;
        border-left: 3px solid #10B981;
    }
    .stButton>button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        padding: 0.5rem 2rem;
        border-radius: 8px;
        font-weight: 600;
    }
</style>
""", unsafe_allow_html=True)

# Configuration
CATALOG_NAME = os.getenv('METADATA_CATALOG', 'metadata_catalog')
SCHEMA_NAME = os.getenv('METADATA_SCHEMA', 'technical_metadata')

# Initialize session state
if 'selected_table' not in st.session_state:
    st.session_state.selected_table = None
if 'search_history' not in st.session_state:
    st.session_state.search_history = []

@st.cache_resource
def get_connection():
    """Get Databricks SQL connection"""
    try:
        connection = sql.connect(
            server_hostname=os.getenv('DATABRICKS_SERVER_HOSTNAME'),
            http_path=os.getenv('DATABRICKS_HTTP_PATH'),
            access_token=os.getenv('DATABRICKS_TOKEN')
        )
        return connection
    except Exception as e:
        st.error(f"Failed to connect to Databricks: {e}")
        return None

def execute_query(query, params=None):
    """Execute SQL query and return DataFrame"""
    conn = get_connection()
    if not conn:
        return pd.DataFrame()
    
    try:
        cursor = conn.cursor()
        cursor.execute(query, params or {})
        
        # Get column names
        columns = [desc[0] for desc in cursor.description]
        
        # Fetch results
        results = cursor.fetchall()
        
        # Create DataFrame
        df = pd.DataFrame(results, columns=columns)
        return df
    except Exception as e:
        st.error(f"Query failed: {e}")
        return pd.DataFrame()

@st.cache_data(ttl=300)
def get_statistics():
    """Get overall metadata statistics"""
    query = f"""
    SELECT 
        source_system,
        COUNT(DISTINCT table_id) as table_count,
        SUM(row_count) as total_rows,
        SUM(size_bytes) / 1024 / 1024 / 1024 as total_size_gb
    FROM {CATALOG_NAME}.{SCHEMA_NAME}.tables_metadata
    GROUP BY source_system
    """
    return execute_query(query)

@st.cache_data(ttl=60)
def search_tables(search_term, source_filter=None, database_filter=None, 
                  schema_filter=None, pii_filter=None, limit=50):
    """Search for tables"""
    query = f"""
    SELECT DISTINCT
        t.table_id,
        t.source_system,
        t.database_name,
        t.schema_name,
        t.table_name,
        t.full_table_name,
        t.table_type,
        t.description,
        t.owner,
        t.row_count,
        t.size_bytes,
        t.created_at,
        t.last_modified,
        t.tags,
        COUNT(DISTINCT c.column_id) as column_count,
        MAX(CASE WHEN c.is_pii = true THEN 1 ELSE 0 END) as has_pii
    FROM {CATALOG_NAME}.{SCHEMA_NAME}.tables_metadata t
    LEFT JOIN {CATALOG_NAME}.{SCHEMA_NAME}.columns_metadata c ON t.table_id = c.table_id
    WHERE (
        LOWER(t.table_name) LIKE LOWER('%{search_term}%')
        OR LOWER(t.description) LIKE LOWER('%{search_term}%')
        OR LOWER(t.database_name) LIKE LOWER('%{search_term}%')
        OR LOWER(t.schema_name) LIKE LOWER('%{search_term}%')
        OR EXISTS (
            SELECT 1 FROM {CATALOG_NAME}.{SCHEMA_NAME}.columns_metadata c2
            WHERE c2.table_id = t.table_id 
            AND (LOWER(c2.column_name) LIKE LOWER('%{search_term}%')
                 OR LOWER(c2.description) LIKE LOWER('%{search_term}%'))
        )
    )
    """
    
    if source_filter and source_filter != "All":
        query += f" AND t.source_system = '{source_filter}'"
    
    if database_filter and database_filter != "All":
        query += f" AND t.database_name = '{database_filter}'"
    
    if schema_filter and schema_filter != "All":
        query += f" AND t.schema_name = '{schema_filter}'"
    
    query += f"""
    GROUP BY t.table_id, t.source_system, t.database_name, t.schema_name,
             t.table_name, t.full_table_name, t.table_type, t.description,
             t.owner, t.row_count, t.size_bytes, t.created_at, t.last_modified, t.tags
    """
    
    if pii_filter == "PII Only":
        query += " HAVING has_pii = 1"
    elif pii_filter == "No PII":
        query += " HAVING has_pii = 0"
    
    query += f" ORDER BY t.table_name LIMIT {limit}"
    
    return execute_query(query)

def get_table_details(table_id):
    """Get detailed table information"""
    table_query = f"""
    SELECT * 
    FROM {CATALOG_NAME}.{SCHEMA_NAME}.tables_metadata
    WHERE table_id = '{table_id}'
    """
    
    columns_query = f"""
    SELECT 
        column_name,
        ordinal_position,
        data_type,
        is_nullable,
        is_primary_key,
        is_pii,
        description,
        data_classification
    FROM {CATALOG_NAME}.{SCHEMA_NAME}.columns_metadata
    WHERE table_id = '{table_id}'
    ORDER BY ordinal_position
    """
    
    access_query = f"""
    SELECT 
        ag.group_name,
        ag.group_description,
        ram.access_level,
        ag.request_process,
        ag.approval_workflow_url,
        ag.sla_days,
        ag.contact_email
    FROM {CATALOG_NAME}.{SCHEMA_NAME}.resource_access_mapping ram
    JOIN {CATALOG_NAME}.{SCHEMA_NAME}.ad_groups ag ON ram.ad_group_id = ag.ad_group_id
    WHERE ram.table_id = '{table_id}'
    AND ag.is_active = true
    ORDER BY ram.access_level, ag.group_name
    """
    
    table_df = execute_query(table_query)
    columns_df = execute_query(columns_query)
    access_df = execute_query(access_query)
    
    return table_df, columns_df, access_df

@st.cache_data(ttl=300)
def get_filter_options():
    """Get available filter options"""
    sources_query = f"""
    SELECT DISTINCT source_system FROM {CATALOG_NAME}.{SCHEMA_NAME}.tables_metadata 
    ORDER BY source_system
    """
    
    databases_query = f"""
    SELECT DISTINCT database_name FROM {CATALOG_NAME}.{SCHEMA_NAME}.tables_metadata 
    ORDER BY database_name
    """
    
    schemas_query = f"""
    SELECT DISTINCT schema_name FROM {CATALOG_NAME}.{SCHEMA_NAME}.tables_metadata 
    ORDER BY schema_name
    """
    
    sources = execute_query(sources_query)['source_system'].tolist()
    databases = execute_query(databases_query)['database_name'].tolist()
    schemas = execute_query(schemas_query)['schema_name'].tolist()
    
    return sources, databases, schemas

def format_size(size_bytes):
    """Format bytes to human-readable size"""
    if pd.isna(size_bytes):
        return "N/A"
    
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.2f} PB"

def render_source_badge(source):
    """Render source system badge"""
    badge_class = f"badge-{source.lower()}" if source.lower() in ['databricks', 'hive', 'db2', 'erwin'] else 'badge-databricks'
    return f'<span class="source-badge {badge_class}">{source.upper()}</span>'

def render_table_card(row):
    """Render a table result card"""
    has_pii = bool(row['has_pii'])
    pii_badge = '<span class="pii-badge">🔒 CONTAINS PII</span>' if has_pii else ''
    
    size_str = format_size(row['size_bytes']) if not pd.isna(row['size_bytes']) else 'N/A'
    rows_str = f"{int(row['row_count']):,}" if not pd.isna(row['row_count']) else 'N/A'
    
    description = row['description'] if not pd.isna(row['description']) else 'No description available'
    
    return f"""
    <div class="table-card">
        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 0.75rem;">
            <h3 style="margin: 0; color: #1E3A8A;">{row['table_name']}</h3>
            <div>
                {render_source_badge(row['source_system'])}
                {pii_badge}
            </div>
        </div>
        <div style="font-family: monospace; color: #6B7280; font-size: 0.9rem; margin-bottom: 0.75rem;">
            {row['full_table_name']}
        </div>
        <p style="color: #374151; margin-bottom: 0.75rem;">
            {description[:200]}{'...' if len(description) > 200 else ''}
        </p>
        <div style="display: flex; gap: 1.5rem; font-size: 0.9rem; color: #6B7280;">
            <div><strong>Type:</strong> {row['table_type']}</div>
            <div><strong>Columns:</strong> {int(row['column_count'])}</div>
            <div><strong>Rows:</strong> {rows_str}</div>
            <div><strong>Size:</strong> {size_str}</div>
            {f"<div><strong>Owner:</strong> {row['owner']}</div>" if not pd.isna(row['owner']) else ''}
        </div>
    </div>
    """

def main():
    # Header
    st.markdown('<h1 class="main-header">🔍 Data Catalog Search</h1>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Discover and explore data assets across all platforms</p>', unsafe_allow_html=True)
    
    # Sidebar
    with st.sidebar:
        st.image("https://www.databricks.com/wp-content/uploads/2021/06/db-nav-logo.svg", width=200)
        st.markdown("---")
        
        # Statistics
        st.subheader("📊 Overview")
        stats_df = get_statistics()
        
        if not stats_df.empty:
            total_tables = stats_df['table_count'].sum()
            total_rows = stats_df['total_rows'].sum()
            total_size = stats_df['total_size_gb'].sum()
            
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Total Tables", f"{int(total_tables):,}")
            with col2:
                st.metric("Total Size", f"{total_size:.1f} GB")
            
            st.markdown("**By Source:**")
            for _, row in stats_df.iterrows():
                st.markdown(f"• **{row['source_system']}**: {int(row['table_count']):,} tables")
        
        st.markdown("---")
        
        # Filters
        st.subheader("🎛️ Filters")
        
        sources, databases, schemas = get_filter_options()
        
        source_filter = st.selectbox(
            "Source System",
            ["All"] + sources,
            key="source_filter"
        )
        
        database_filter = st.selectbox(
            "Database",
            ["All"] + databases[:20],  # Limit to 20 for performance
            key="database_filter"
        )
        
        schema_filter = st.selectbox(
            "Schema",
            ["All"] + schemas[:20],  # Limit to 20 for performance
            key="schema_filter"
        )
        
        pii_filter = st.selectbox(
            "PII Data",
            ["All", "PII Only", "No PII"],
            key="pii_filter"
        )
        
        if st.button("🔄 Reset Filters"):
            st.session_state.source_filter = "All"
            st.session_state.database_filter = "All"
            st.session_state.schema_filter = "All"
            st.session_state.pii_filter = "All"
            st.rerun()
    
    # Main content area
    if st.session_state.selected_table is None:
        # Search interface
        col1, col2 = st.columns([4, 1])
        
        with col1:
            search_term = st.text_input(
                "🔎 Search tables, columns, or descriptions",
                placeholder="e.g., customer, sales, email...",
                key="search_input"
            )
        
        with col2:
            st.markdown("<br>", unsafe_allow_html=True)
            search_button = st.button("Search", type="primary", use_container_width=True)
        
        # Perform search
        if search_term or search_button:
            if search_term:
                with st.spinner("Searching..."):
                    results_df = search_tables(
                        search_term,
                        source_filter if source_filter != "All" else None,
                        database_filter if database_filter != "All" else None,
                        schema_filter if schema_filter != "All" else None,
                        pii_filter if pii_filter != "All" else None
                    )
                
                if not results_df.empty:
                    st.success(f"Found {len(results_df)} results")
                    
                    # Display results
                    for idx, row in results_df.iterrows():
                        st.markdown(render_table_card(row), unsafe_allow_html=True)
                        
                        # View details button
                        if st.button(f"View Details", key=f"view_{idx}"):
                            st.session_state.selected_table = row['table_id']
                            st.rerun()
                else:
                    st.warning("No results found. Try different search terms or adjust filters.")
            else:
                st.info("Enter a search term to find tables.")
    
    else:
        # Table details view
        table_id = st.session_state.selected_table
        
        if st.button("← Back to Search"):
            st.session_state.selected_table = None
            st.rerun()
        
        st.markdown("---")
        
        # Get table details
        table_df, columns_df, access_df = get_table_details(table_id)
        
        if not table_df.empty:
            table = table_df.iloc[0]
            
            # Table header
            col1, col2 = st.columns([3, 1])
            with col1:
                st.markdown(f"# {table['table_name']}")
                st.markdown(f"**{table['full_table_name']}**")
            with col2:
                st.markdown(render_source_badge(table['source_system']), unsafe_allow_html=True)
            
            # Description
            if not pd.isna(table['description']):
                st.info(table['description'])
            
            # Metadata tabs
            tab1, tab2, tab3, tab4 = st.tabs(["📋 Overview", "📊 Columns", "🔐 Access", "📈 Statistics"])
            
            with tab1:
                # Overview
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    st.metric("Table Type", table['table_type'])
                with col2:
                    row_count = f"{int(table['row_count']):,}" if not pd.isna(table['row_count']) else 'N/A'
                    st.metric("Row Count", row_count)
                with col3:
                    size = format_size(table['size_bytes'])
                    st.metric("Size", size)
                with col4:
                    st.metric("Columns", len(columns_df))
                
                st.markdown("---")
                
                # Additional details
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("**Table Properties**")
                    if not pd.isna(table['owner']):
                        st.write(f"**Owner:** {table['owner']}")
                    if not pd.isna(table['storage_location']):
                        st.write(f"**Location:** `{table['storage_location']}`")
                    if not pd.isna(table['data_format']):
                        st.write(f"**Format:** {table['data_format']}")
                    st.write(f"**Partitioned:** {'Yes' if table['is_partitioned'] else 'No'}")
                
                with col2:
                    st.markdown("**Timestamps**")
                    if not pd.isna(table['created_at']):
                        st.write(f"**Created:** {table['created_at']}")
                    if not pd.isna(table['last_modified']):
                        st.write(f"**Modified:** {table['last_modified']}")
                
                # Tags
                if not pd.isna(table['tags']) and table['tags']:
                    st.markdown("**Tags**")
                    tags_html = " ".join([f'<span style="background: #E5E7EB; padding: 0.25rem 0.75rem; border-radius: 12px; margin-right: 0.5rem; font-size: 0.85rem;">{tag}</span>' for tag in table['tags']])
                    st.markdown(tags_html, unsafe_allow_html=True)
            
            with tab2:
                # Columns table
                if not columns_df.empty:
                    st.markdown(f"### Columns ({len(columns_df)})")
                    
                    # Add icons for special columns
                    columns_df['Flags'] = columns_df.apply(lambda row: 
                        ('🔑' if row['is_primary_key'] else '') + 
                        ('🔒' if row['is_pii'] else '') +
                        ('❗' if not row['is_nullable'] else ''), axis=1)
                    
                    # Display columns
                    st.dataframe(
                        columns_df[['ordinal_position', 'column_name', 'data_type', 'Flags', 'description']],
                        use_container_width=True,
                        hide_index=True,
                        column_config={
                            'ordinal_position': '#',
                            'column_name': 'Column Name',
                            'data_type': 'Data Type',
                            'Flags': st.column_config.TextColumn('', width='small'),
                            'description': 'Description'
                        }
                    )
                    
                    st.caption("🔑 Primary Key | 🔒 PII | ❗ Not Nullable")
                    
                    # PII warning
                    pii_columns = columns_df[columns_df['is_pii'] == True]
                    if not pii_columns.empty:
                        st.warning(f"⚠️ This table contains {len(pii_columns)} PII column(s): {', '.join(pii_columns['column_name'].tolist())}")
                else:
                    st.info("No column information available.")
            
            with tab3:
                # Access groups
                if not access_df.empty:
                    st.markdown("### Required Access Groups")
                    
                    read_groups = access_df[access_df['access_level'] == 'READ']
                    write_groups = access_df[access_df['access_level'] == 'WRITE']
                    
                    if not read_groups.empty:
                        st.markdown("#### 📖 Read Access")
                        for _, group in read_groups.iterrows():
                            with st.expander(f"**{group['group_name']}**"):
                                if not pd.isna(group['group_description']):
                                    st.write(group['group_description'])
                                if not pd.isna(group['request_process']):
                                    st.info(f"**How to request:** {group['request_process']}")
                                if not pd.isna(group['approval_workflow_url']):
                                    st.markdown(f"[🎫 Submit Request]({group['approval_workflow_url']})")
                                if not pd.isna(group['sla_days']):
                                    st.write(f"**SLA:** {int(group['sla_days'])} business days")
                                if not pd.isna(group['contact_email']):
                                    st.write(f"**Contact:** {group['contact_email']}")
                    
                    if not write_groups.empty:
                        st.markdown("#### ✏️ Write Access")
                        for _, group in write_groups.iterrows():
                            with st.expander(f"**{group['group_name']}**"):
                                if not pd.isna(group['group_description']):
                                    st.write(group['group_description'])
                                if not pd.isna(group['request_process']):
                                    st.info(f"**How to request:** {group['request_process']}")
                                if not pd.isna(group['approval_workflow_url']):
                                    st.markdown(f"[🎫 Submit Request]({group['approval_workflow_url']})")
                                if not pd.isna(group['sla_days']):
                                    st.write(f"**SLA:** {int(group['sla_days'])} business days")
                else:
                    st.info("No access group information available for this table.")
            
            with tab4:
                # Statistics and visualizations
                st.markdown("### Table Statistics")
                
                if not columns_df.empty:
                    # Data type distribution
                    type_counts = columns_df['data_type'].value_counts()
                    
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.markdown("**Data Type Distribution**")
                        st.bar_chart(type_counts)
                    
                    with col2:
                        st.markdown("**Column Characteristics**")
                        characteristics = {
                            'Primary Keys': len(columns_df[columns_df['is_primary_key'] == True]),
                            'PII Columns': len(columns_df[columns_df['is_pii'] == True]),
                            'Nullable': len(columns_df[columns_df['is_nullable'] == True]),
                            'Required': len(columns_df[columns_df['is_nullable'] == False])
                        }
                        st.bar_chart(characteristics)

if __name__ == "__main__":
    main()
