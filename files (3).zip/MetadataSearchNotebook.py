# Databricks notebook source
# MAGIC %md
# MAGIC # Metadata Search and Serving from Delta Tables
# MAGIC 
# MAGIC This notebook provides SQL queries and Python functions to search and serve metadata from Delta tables.
# MAGIC 
# MAGIC ## Setup
# MAGIC - Catalog: `metadata_catalog`
# MAGIC - Schema: `technical_metadata`
# MAGIC - Tables: `tables_metadata`, `columns_metadata`, `ad_groups`, `resource_access_mapping`

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Setup and Configuration

# COMMAND ----------

# Set catalog and schema
spark.sql("USE CATALOG metadata_catalog")
spark.sql("USE SCHEMA technical_metadata")

# Import libraries
from pyspark.sql.functions import *
from pyspark.sql import DataFrame
import json

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Search Functions

# COMMAND ----------

def search_tables(search_term: str, 
                  source_system: str = None,
                  database_name: str = None,
                  has_pii: bool = None,
                  limit: int = 50) -> DataFrame:
    """
    Search for tables using keyword search
    
    Args:
        search_term: Search keyword
        source_system: Filter by source (databricks, hive, db2, erwin)
        database_name: Filter by database
        has_pii: Filter by PII presence
        limit: Max results
        
    Returns:
        DataFrame with search results
    """
    
    query = """
    SELECT DISTINCT
        t.table_id,
        t.source_system,
        t.database_name,
        t.schema_name,
        t.table_name,
        t.full_table_name,
        t.table_type,
        t.description,
        t.owner,
        t.row_count,
        t.size_bytes,
        t.created_at,
        t.last_modified,
        t.tags,
        COUNT(DISTINCT c.column_id) as column_count,
        MAX(CASE WHEN c.is_pii = true THEN 1 ELSE 0 END) as has_pii,
        COLLECT_LIST(DISTINCT ram.ad_group_id) FILTER (WHERE ram.access_level = 'READ') as read_groups,
        COLLECT_LIST(DISTINCT ram.ad_group_id) FILTER (WHERE ram.access_level = 'WRITE') as write_groups
    FROM tables_metadata t
    LEFT JOIN columns_metadata c ON t.table_id = c.table_id
    LEFT JOIN resource_access_mapping ram ON ram.table_id = t.table_id
    WHERE (
        LOWER(t.table_name) LIKE LOWER('%{search}%')
        OR LOWER(t.description) LIKE LOWER('%{search}%')
        OR LOWER(t.database_name) LIKE LOWER('%{search}%')
        OR LOWER(t.schema_name) LIKE LOWER('%{search}%')
        OR EXISTS (
            SELECT 1 FROM columns_metadata c2 
            WHERE c2.table_id = t.table_id 
            AND (LOWER(c2.column_name) LIKE LOWER('%{search}%')
                 OR LOWER(c2.description) LIKE LOWER('%{search}%'))
        )
    )
    """.format(search=search_term)
    
    # Add filters
    if source_system:
        query += f" AND t.source_system = '{source_system}'"
    
    if database_name:
        query += f" AND t.database_name = '{database_name}'"
    
    query += """
    GROUP BY t.table_id, t.source_system, t.database_name, t.schema_name,
             t.table_name, t.full_table_name, t.table_type, t.description,
             t.owner, t.row_count, t.size_bytes, t.created_at, t.last_modified, t.tags
    """
    
    if has_pii is not None:
        if has_pii:
            query += " HAVING has_pii = 1"
        else:
            query += " HAVING has_pii = 0"
    
    query += f" ORDER BY t.table_name LIMIT {limit}"
    
    return spark.sql(query)

# COMMAND ----------

def get_table_details(table_id: str) -> DataFrame:
    """Get complete details for a specific table"""
    
    return spark.sql(f"""
        SELECT 
            t.*,
            COLLECT_LIST(
                STRUCT(
                    c.column_name,
                    c.ordinal_position,
                    c.data_type,
                    c.is_nullable,
                    c.is_primary_key,
                    c.is_pii,
                    c.description
                )
            ) as columns
        FROM tables_metadata t
        LEFT JOIN columns_metadata c ON t.table_id = c.table_id
        WHERE t.table_id = '{table_id}'
        GROUP BY t.table_id, t.source_system, t.catalog_name, t.database_name,
                 t.schema_name, t.table_name, t.full_table_name, t.table_type,
                 t.description, t.owner, t.created_at, t.last_modified,
                 t.row_count, t.size_bytes, t.storage_location, t.data_format,
                 t.is_partitioned, t.partition_columns, t.tags, t.properties,
                 t.extraction_time
    """)

# COMMAND ----------

def get_access_groups(table_id: str) -> DataFrame:
    """Get AD groups that have access to a table"""
    
    return spark.sql(f"""
        SELECT 
            ag.group_name,
            ag.group_description,
            ram.access_level,
            ag.request_process,
            ag.approval_workflow_url,
            ag.sla_days,
            ag.contact_email
        FROM resource_access_mapping ram
        JOIN ad_groups ag ON ram.ad_group_id = ag.ad_group_id
        WHERE ram.table_id = '{table_id}'
        AND ag.is_active = true
        ORDER BY ram.access_level, ag.group_name
    """)

# COMMAND ----------

def search_columns(column_name: str, 
                   data_type: str = None,
                   is_pii: bool = None,
                   limit: int = 100) -> DataFrame:
    """Search for columns across all tables"""
    
    query = f"""
    SELECT 
        c.column_name,
        c.data_type,
        c.description,
        c.is_pii,
        c.is_primary_key,
        t.full_table_name,
        t.source_system,
        t.database_name,
        t.schema_name,
        t.table_name,
        t.owner
    FROM columns_metadata c
    JOIN tables_metadata t ON c.table_id = t.table_id
    WHERE LOWER(c.column_name) LIKE LOWER('%{column_name}%')
    """
    
    if data_type:
        query += f" AND LOWER(c.data_type) = LOWER('{data_type}')"
    
    if is_pii is not None:
        query += f" AND c.is_pii = {str(is_pii).lower()}"
    
    query += f" ORDER BY c.column_name LIMIT {limit}"
    
    return spark.sql(query)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Example Searches

# COMMAND ----------

# MAGIC %md
# MAGIC ### Search for tables containing "customer"

# COMMAND ----------

results = search_tables("customer", limit=10)
display(results)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Search for tables with PII

# COMMAND ----------

pii_tables = search_tables("", has_pii=True, limit=20)
display(pii_tables)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Search for specific column name

# COMMAND ----------

email_columns = search_columns("email", is_pii=True, limit=50)
display(email_columns)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Direct SQL Queries

# COMMAND ----------

# MAGIC %sql
# MAGIC -- View all data sources
# MAGIC SELECT * FROM data_sources WHERE is_active = true

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Summary statistics by source
# MAGIC SELECT 
# MAGIC   source_system,
# MAGIC   COUNT(DISTINCT table_id) as table_count,
# MAGIC   COUNT(DISTINCT database_name) as database_count,
# MAGIC   SUM(row_count) as total_rows,
# MAGIC   SUM(size_bytes) / 1024 / 1024 / 1024 as total_size_gb
# MAGIC FROM tables_metadata
# MAGIC GROUP BY source_system
# MAGIC ORDER BY table_count DESC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Tables with most columns
# MAGIC SELECT 
# MAGIC   t.full_table_name,
# MAGIC   t.source_system,
# MAGIC   COUNT(c.column_id) as column_count,
# MAGIC   t.row_count,
# MAGIC   t.owner
# MAGIC FROM tables_metadata t
# MAGIC JOIN columns_metadata c ON t.table_id = c.table_id
# MAGIC GROUP BY t.table_id, t.full_table_name, t.source_system, t.row_count, t.owner
# MAGIC ORDER BY column_count DESC
# MAGIC LIMIT 20

# COMMAND ----------

# MAGIC %sql
# MAGIC -- PII columns by table
# MAGIC SELECT 
# MAGIC   t.full_table_name,
# MAGIC   t.source_system,
# MAGIC   COUNT(c.column_id) as pii_column_count,
# MAGIC   COLLECT_LIST(c.column_name) as pii_columns
# MAGIC FROM tables_metadata t
# MAGIC JOIN columns_metadata c ON t.table_id = c.table_id
# MAGIC WHERE c.is_pii = true
# MAGIC GROUP BY t.table_id, t.full_table_name, t.source_system
# MAGIC ORDER BY pii_column_count DESC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Tables by owner
# MAGIC SELECT 
# MAGIC   owner,
# MAGIC   source_system,
# MAGIC   COUNT(*) as table_count,
# MAGIC   SUM(row_count) as total_rows
# MAGIC FROM tables_metadata
# MAGIC WHERE owner IS NOT NULL
# MAGIC GROUP BY owner, source_system
# MAGIC ORDER BY table_count DESC
# MAGIC LIMIT 20

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Most common data types
# MAGIC SELECT 
# MAGIC   data_type,
# MAGIC   COUNT(*) as usage_count,
# MAGIC   COUNT(DISTINCT table_id) as table_count
# MAGIC FROM columns_metadata
# MAGIC GROUP BY data_type
# MAGIC ORDER BY usage_count DESC
# MAGIC LIMIT 20

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Tables with access groups
# MAGIC SELECT 
# MAGIC   t.full_table_name,
# MAGIC   t.source_system,
# MAGIC   ag.group_name,
# MAGIC   ram.access_level,
# MAGIC   ag.request_process
# MAGIC FROM tables_metadata t
# MAGIC JOIN resource_access_mapping ram ON t.table_id = ram.table_id
# MAGIC JOIN ad_groups ag ON ram.ad_group_id = ag.ad_group_id
# MAGIC WHERE ag.is_active = true
# MAGIC ORDER BY t.full_table_name, ram.access_level

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Search history analytics
# MAGIC SELECT 
# MAGIC   user_id,
# MAGIC   COUNT(*) as search_count,
# MAGIC   COUNT(DISTINCT clicked_table_id) as unique_tables_viewed,
# MAGIC   MAX(search_timestamp) as last_search
# MAGIC FROM search_history
# MAGIC WHERE search_timestamp >= CURRENT_DATE - INTERVAL 30 DAYS
# MAGIC GROUP BY user_id
# MAGIC ORDER BY search_count DESC
# MAGIC LIMIT 20

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Popular tables (most searched)
# MAGIC SELECT 
# MAGIC   t.full_table_name,
# MAGIC   t.source_system,
# MAGIC   t.description,
# MAGIC   COUNT(DISTINCT sh.search_id) as search_count,
# MAGIC   COUNT(DISTINCT sh.user_id) as unique_users,
# MAGIC   MAX(sh.search_timestamp) as last_searched
# MAGIC FROM tables_metadata t
# MAGIC JOIN search_history sh ON t.table_id = sh.clicked_table_id
# MAGIC WHERE sh.search_timestamp >= CURRENT_DATE - INTERVAL 30 DAYS
# MAGIC GROUP BY t.table_id, t.full_table_name, t.source_system, t.description
# MAGIC ORDER BY search_count DESC
# MAGIC LIMIT 20

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Access request statistics
# MAGIC SELECT 
# MAGIC   request_status,
# MAGIC   access_level,
# MAGIC   COUNT(*) as request_count,
# MAGIC   COUNT(DISTINCT user_id) as unique_users,
# MAGIC   COUNT(DISTINCT table_id) as unique_tables
# MAGIC FROM access_requests
# MAGIC WHERE requested_at >= CURRENT_DATE - INTERVAL 30 DAYS
# MAGIC GROUP BY request_status, access_level
# MAGIC ORDER BY request_count DESC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Create Dashboards

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Metadata Coverage Dashboard
# MAGIC SELECT 
# MAGIC   source_system,
# MAGIC   COUNT(*) as total_tables,
# MAGIC   SUM(CASE WHEN description IS NOT NULL AND description != '' THEN 1 ELSE 0 END) as tables_with_description,
# MAGIC   ROUND(100.0 * SUM(CASE WHEN description IS NOT NULL AND description != '' THEN 1 ELSE 0 END) / COUNT(*), 2) as description_coverage_pct,
# MAGIC   SUM(CASE WHEN owner IS NOT NULL AND owner != '' THEN 1 ELSE 0 END) as tables_with_owner,
# MAGIC   ROUND(100.0 * SUM(CASE WHEN owner IS NOT NULL AND owner != '' THEN 1 ELSE 0 END) / COUNT(*), 2) as owner_coverage_pct
# MAGIC FROM tables_metadata
# MAGIC GROUP BY source_system

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Data Growth Over Time
# MAGIC SELECT 
# MAGIC   DATE_TRUNC('month', extraction_time) as month,
# MAGIC   source_system,
# MAGIC   COUNT(DISTINCT table_id) as table_count,
# MAGIC   SUM(row_count) as total_rows,
# MAGIC   SUM(size_bytes) / 1024 / 1024 / 1024 as size_gb
# MAGIC FROM tables_metadata
# MAGIC WHERE extraction_time IS NOT NULL
# MAGIC GROUP BY DATE_TRUNC('month', extraction_time), source_system
# MAGIC ORDER BY month DESC, source_system

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Export Functions

# COMMAND ----------

def export_metadata_to_json(table_id: str, output_path: str):
    """Export complete table metadata to JSON"""
    
    # Get table details
    table_df = get_table_details(table_id)
    table_dict = table_df.first().asDict()
    
    # Get access groups
    access_df = get_access_groups(table_id)
    table_dict['access_groups'] = [row.asDict() for row in access_df.collect()]
    
    # Save to JSON
    import json
    with open(output_path, 'w') as f:
        json.dump(table_dict, f, indent=2, default=str)
    
    print(f"Metadata exported to {output_path}")

# COMMAND ----------

def create_metadata_report(source_system: str = None) -> DataFrame:
    """Create comprehensive metadata quality report"""
    
    query = """
    SELECT 
        source_system,
        database_name,
        COUNT(*) as total_tables,
        SUM(CASE WHEN description IS NOT NULL THEN 1 ELSE 0 END) as documented_tables,
        SUM(CASE WHEN owner IS NOT NULL THEN 1 ELSE 0 END) as owned_tables,
        AVG(CASE WHEN row_count > 0 THEN row_count END) as avg_row_count,
        COUNT(DISTINCT 
            CASE WHEN EXISTS(
                SELECT 1 FROM columns_metadata c 
                WHERE c.table_id = t.table_id AND c.is_pii = true
            ) THEN t.table_id END
        ) as tables_with_pii,
        COUNT(DISTINCT
            CASE WHEN EXISTS(
                SELECT 1 FROM resource_access_mapping ram
                WHERE ram.table_id = t.table_id
            ) THEN t.table_id END
        ) as tables_with_access_groups
    FROM tables_metadata t
    """
    
    if source_system:
        query += f" WHERE source_system = '{source_system}'"
    
    query += """
    GROUP BY source_system, database_name
    ORDER BY source_system, database_name
    """
    
    return spark.sql(query)

# COMMAND ----------

# Generate metadata quality report
report = create_metadata_report()
display(report)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. REST API Endpoints (for serving)

# COMMAND ----------

from pyspark.sql.functions import to_json, struct

def create_api_response(table_id: str) -> str:
    """Create JSON API response for a table"""
    
    table_details = get_table_details(table_id).first()
    access_groups = get_access_groups(table_id).collect()
    
    response = {
        "table_id": table_details.table_id,
        "source_system": table_details.source_system,
        "full_table_name": table_details.full_table_name,
        "description": table_details.description,
        "owner": table_details.owner,
        "row_count": table_details.row_count,
        "columns": [col.asDict() for col in table_details.columns],
        "access_groups": [ag.asDict() for ag in access_groups]
    }
    
    return json.dumps(response, default=str)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Refresh Metadata

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Check last extraction time
# MAGIC SELECT 
# MAGIC   source_system,
# MAGIC   MAX(extraction_time) as last_extraction,
# MAGIC   DATEDIFF(CURRENT_TIMESTAMP(), MAX(extraction_time)) as days_since_last_extraction
# MAGIC FROM tables_metadata
# MAGIC GROUP BY source_system

# COMMAND ----------

# MAGIC %md
# MAGIC ## Summary
# MAGIC 
# MAGIC This notebook provides:
# MAGIC 1. Search functions for tables and columns
# MAGIC 2. Detailed metadata retrieval
# MAGIC 3. Access group information
# MAGIC 4. SQL queries for analysis
# MAGIC 5. Dashboard queries
# MAGIC 6. Export capabilities
# MAGIC 
# MAGIC **Next Steps:**
# MAGIC - Schedule regular metadata refreshes using Jobs
# MAGIC - Create Databricks SQL dashboards
# MAGIC - Set up alerts for metadata quality
# MAGIC - Integrate with BI tools
