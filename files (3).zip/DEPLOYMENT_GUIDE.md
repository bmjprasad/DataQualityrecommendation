# Metadata Management Solution - Deployment Guide

## Overview
This guide walks through deploying the complete metadata management solution that integrates Databricks, Hive, DB2, and Erwin with search capabilities and Active Directory group mapping.

## Architecture Components

1. **Metadata Extractors** (Python)
   - Databricks extractor
   - Hive extractor
   - DB2 extractor
   - Erwin extractor

2. **Central Repository** (PostgreSQL)
   - Metadata storage
   - AD group mappings
   - Search indexes

3. **API Layer** (FastAPI)
   - RESTful search API
   - Access request handling

4. **Frontend** (React)
   - Search interface
   - Table details view
   - Access request forms

5. **Orchestration** (Airflow/Python)
   - Scheduled extraction
   - ETL pipeline

## Prerequisites

### Required Software
- Python 3.9+
- PostgreSQL 14+
- Node.js 16+ (for frontend)
- Docker & Docker Compose (recommended)

### Required Access
- Databricks workspace access token
- Hive server credentials
- DB2 database credentials
- Erwin model XML export
- LDAP/Active Directory read access

## Installation Steps

### 1. Database Setup

```bash
# Install PostgreSQL
sudo apt-get update
sudo apt-get install postgresql postgresql-contrib

# Create database
sudo -u postgres createdb metadata_catalog
sudo -u postgres createuser metadata_user -P

# Grant privileges
sudo -u postgres psql
GRANT ALL PRIVILEGES ON DATABASE metadata_catalog TO metadata_user;
\q

# Run schema creation
psql -U metadata_user -d metadata_catalog -f metadata_repository_schema.sql
```

### 2. Python Backend Setup

```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set environment variables
export DATABASE_URL="postgresql://metadata_user:password@localhost:5432/metadata_catalog"
export DATABRICKS_WORKSPACE_URL="https://your-workspace.azuredatabricks.net"
export DATABRICKS_TOKEN="your-token"
export HIVE_HOST="hive-server.company.com"
export HIVE_PORT="10000"
export HIVE_USERNAME="your-username"
export HIVE_PASSWORD="your-password"
export DB2_DATABASE="MYDB"
export DB2_HOST="db2-server.company.com"
export DB2_PORT="50000"
export DB2_USERNAME="your-username"
export DB2_PASSWORD="your-password"
export ERWIN_XML_PATH="/path/to/erwin_export.xml"
```

### 3. Initial Metadata Extraction

```bash
# Run initial metadata extraction
python metadata_orchestrator.py

# This will:
# - Connect to all data sources
# - Extract table and column metadata
# - Load into central repository
# - Create search indexes
```

### 4. Start API Server

```bash
# Start FastAPI server
uvicorn metadata_search_api:app --host 0.0.0.0 --port 8000 --reload

# API will be available at:
# http://localhost:8000
# API docs at: http://localhost:8000/docs
```

### 5. Frontend Setup

```bash
# Navigate to frontend directory
cd frontend

# Install dependencies
npm install

# Create .env file
cat > .env << EOF
REACT_APP_API_URL=http://localhost:8000
EOF

# Start development server
npm start

# Production build
npm run build
```

## Docker Deployment

### Using Docker Compose

```yaml
# docker-compose.yml
version: '3.8'

services:
  postgres:
    image: postgres:14
    environment:
      POSTGRES_DB: metadata_catalog
      POSTGRES_USER: metadata_user
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./metadata_repository_schema.sql:/docker-entrypoint-initdb.d/init.sql
    ports:
      - "5432:5432"

  api:
    build: 
      context: .
      dockerfile: Dockerfile.api
    environment:
      DATABASE_URL: postgresql://metadata_user:${DB_PASSWORD}@postgres:5432/metadata_catalog
      DATABRICKS_WORKSPACE_URL: ${DATABRICKS_WORKSPACE_URL}
      DATABRICKS_TOKEN: ${DATABRICKS_TOKEN}
      HIVE_HOST: ${HIVE_HOST}
      HIVE_PORT: ${HIVE_PORT}
      HIVE_USERNAME: ${HIVE_USERNAME}
      HIVE_PASSWORD: ${HIVE_PASSWORD}
      DB2_DATABASE: ${DB2_DATABASE}
      DB2_HOST: ${DB2_HOST}
      DB2_PORT: ${DB2_PORT}
      DB2_USERNAME: ${DB2_USERNAME}
      DB2_PASSWORD: ${DB2_PASSWORD}
    ports:
      - "8000:8000"
    depends_on:
      - postgres

  frontend:
    build:
      context: .
      dockerfile: Dockerfile.frontend
    ports:
      - "3000:80"
    depends_on:
      - api

  airflow:
    image: apache/airflow:2.7.0
    environment:
      AIRFLOW__CORE__EXECUTOR: LocalExecutor
      AIRFLOW__DATABASE__SQL_ALCHEMY_CONN: postgresql+psycopg2://metadata_user:${DB_PASSWORD}@postgres/airflow
    volumes:
      - ./dags:/opt/airflow/dags
      - ./logs:/opt/airflow/logs
    ports:
      - "8080:8080"
    depends_on:
      - postgres

volumes:
  postgres_data:
```

### Dockerfile for API

```dockerfile
# Dockerfile.api
FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY *.py ./

EXPOSE 8000

CMD ["uvicorn", "metadata_search_api:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Dockerfile for Frontend

```dockerfile
# Dockerfile.frontend
FROM node:16 AS build

WORKDIR /app

COPY package*.json ./
RUN npm install

COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/build /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

## Active Directory Integration

### Configure AD Group Sync

```python
# ad_sync.py
import ldap
from sqlalchemy import create_engine, text
import os

def sync_ad_groups():
    """Sync AD groups to metadata repository"""
    
    # Connect to LDAP
    ldap_server = os.getenv('LDAP_SERVER', 'ldap://dc.company.com')
    ldap_user = os.getenv('LDAP_USER')
    ldap_password = os.getenv('LDAP_PASSWORD')
    search_base = 'OU=DataAccessGroups,DC=company,DC=com'
    
    conn = ldap.initialize(ldap_server)
    conn.simple_bind_s(ldap_user, ldap_password)
    
    # Search for data access groups
    search_filter = '(&(objectClass=group)(cn=AD_DATA_*))'
    attributes = ['cn', 'description', 'distinguishedName', 'mail']
    
    results = conn.search_s(search_base, ldap.SCOPE_SUBTREE, search_filter, attributes)
    
    # Connect to metadata DB
    db_url = os.getenv('DATABASE_URL')
    engine = create_engine(db_url)
    
    with engine.connect() as db:
        for dn, attrs in results:
            group_name = attrs['cn'][0].decode('utf-8')
            description = attrs.get('description', [b''])[0].decode('utf-8')
            email = attrs.get('mail', [b''])[0].decode('utf-8')
            
            # Upsert AD group
            query = text("""
                INSERT INTO ad_groups (group_name, group_dn, group_description, contact_email)
                VALUES (:name, :dn, :desc, :email)
                ON CONFLICT (group_name) 
                DO UPDATE SET 
                    group_dn = EXCLUDED.group_dn,
                    group_description = EXCLUDED.group_description,
                    contact_email = EXCLUDED.contact_email,
                    last_synced = CURRENT_TIMESTAMP
            """)
            
            db.execute(query, {
                'name': group_name,
                'dn': dn,
                'desc': description,
                'email': email
            })
        
        db.commit()
    
    conn.unbind_s()
    print(f"Synced {len(results)} AD groups")

if __name__ == "__main__":
    sync_ad_groups()
```

### Map Tables to AD Groups

```sql
-- Example: Map finance tables to AD groups
INSERT INTO resource_access_mapping (resource_type, resource_id, ad_group_id, access_level)
SELECT 
    'table',
    t.table_id,
    ag.ad_group_id,
    'READ'
FROM tables t
JOIN schemas s ON t.schema_id = s.schema_id
JOIN ad_groups ag ON ag.group_name = 'AD_DATA_Finance_Readers'
WHERE s.schema_name = 'finance';

-- Map write access
INSERT INTO resource_access_mapping (resource_type, resource_id, ad_group_id, access_level)
SELECT 
    'table',
    t.table_id,
    ag.ad_group_id,
    'WRITE'
FROM tables t
JOIN schemas s ON t.schema_id = s.schema_id
JOIN ad_groups ag ON ag.group_name = 'AD_DATA_Finance_Writers'
WHERE s.schema_name = 'finance';
```

## Airflow DAG for Scheduled Extraction

```python
# dags/metadata_extraction_dag.py
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import sys
sys.path.append('/opt/airflow/dags/scripts')

from metadata_orchestrator import MetadataOrchestrator, get_config

default_args = {
    'owner': 'data-engineering',
    'depends_on_past': False,
    'start_date': datetime(2025, 1, 1),
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'metadata_extraction',
    default_args=default_args,
    description='Extract metadata from all data sources',
    schedule_interval='0 2 * * *',  # Daily at 2 AM
    catchup=False,
)

def run_extraction():
    config = get_config()
    orchestrator = MetadataOrchestrator(
        db_url=os.getenv('DATABASE_URL'),
        config=config
    )
    orchestrator.run_full_extraction()

extract_task = PythonOperator(
    task_id='extract_all_metadata',
    python_callable=run_extraction,
    dag=dag,
)
```

## Monitoring and Maintenance

### Health Checks

```bash
# Check API health
curl http://localhost:8000/

# Check database connection
psql -U metadata_user -d metadata_catalog -c "SELECT COUNT(*) FROM tables;"

# Check extraction logs
tail -f /var/log/metadata-extraction.log
```

### Performance Optimization

```sql
-- Analyze tables for query optimization
ANALYZE tables;
ANALYZE columns;

-- Rebuild indexes
REINDEX TABLE tables;
REINDEX TABLE columns;

-- Update statistics
VACUUM ANALYZE;
```

## Security Considerations

1. **Credentials Management**
   - Use environment variables or secrets management (HashiCorp Vault, AWS Secrets Manager)
   - Never commit credentials to version control
   - Rotate tokens and passwords regularly

2. **Network Security**
   - Use SSL/TLS for all connections
   - Implement firewall rules
   - Use VPN for on-premise connections

3. **Access Control**
   - Implement role-based access control (RBAC)
   - Enable audit logging
   - Regular security reviews

4. **Data Protection**
   - Encrypt sensitive data at rest
   - Mask PII in search results
   - Implement data retention policies

## Troubleshooting

### Common Issues

1. **Connection Timeouts**
   - Check network connectivity
   - Verify firewall rules
   - Increase connection timeout settings

2. **Slow Searches**
   - Rebuild full-text indexes
   - Add more specific filters
   - Consider using Elasticsearch for large datasets

3. **Missing Metadata**
   - Check extraction logs
   - Verify source system permissions
   - Re-run extraction for specific sources

## Next Steps

1. Customize AD group mapping rules
2. Add data quality metrics
3. Implement data lineage tracking
4. Set up alerts and notifications
5. Create user documentation
6. Train data stewards and users

## Support

For issues or questions:
- Check logs in `/var/log/`
- Review API documentation at `/docs`
- Contact: data-platform-team@company.com
