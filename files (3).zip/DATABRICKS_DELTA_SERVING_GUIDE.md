# Serving Metadata from Databricks Delta Tables

This guide explains how to load and serve metadata from Databricks Delta tables, leveraging the performance and reliability of Delta Lake.

## 🎯 Benefits of Delta Lake for Metadata

1. **ACID Transactions**: Reliable metadata updates
2. **Time Travel**: Query historical metadata states
3. **Performance**: Optimized for analytical queries
4. **Scalability**: Handle millions of tables and columns
5. **Unity Catalog Integration**: Leverage data governance features
6. **Change Data Feed**: Track metadata changes over time
7. **Auto-Optimize**: Automatic file compaction and optimization

## 📋 Architecture

```
┌─────────────────────────────────────────────┐
│         Data Sources                        │
│  Databricks | Hive | DB2 | Erwin           │
└────────────────┬────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────────┐
│      Metadata Extractors                    │
│      (Python Scripts)                       │
└────────────────┬────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────────┐
│     Databricks Delta Tables                │
│                                             │
│  • tables_metadata (partitioned)           │
│  • columns_metadata (partitioned)          │
│  • ad_groups                                │
│  • resource_access_mapping                  │
│  • business_terms                           │
│  • search_history                           │
│  • access_requests                          │
└────────────────┬────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────────┐
│         Serving Layer                       │
│                                             │
│  • Databricks SQL Warehouse (SQL queries)  │
│  • FastAPI (REST API)                       │
│  • Notebooks (Interactive analysis)         │
│  • BI Tools (Tableau, Power BI)            │
└─────────────────────────────────────────────┘
```

## 🚀 Quick Start

### Step 1: Create Unity Catalog and Schema

```sql
-- Create catalog
CREATE CATALOG IF NOT EXISTS metadata_catalog
COMMENT 'Centralized technical metadata repository';

-- Create schema
CREATE SCHEMA IF NOT EXISTS metadata_catalog.technical_metadata
COMMENT 'Technical metadata from all data sources';

-- Use the schema
USE CATALOG metadata_catalog;
USE SCHEMA technical_metadata;
```

### Step 2: Load Metadata into Delta

```python
# Run the Delta loader script
python load_metadata_to_delta.py
```

This will:
1. Extract metadata from all sources
2. Create Delta tables
3. Load data with MERGE operations (upsert)
4. Create optimized views for searching
5. Optimize tables with Z-ordering

### Step 3: Verify the Data

```sql
-- Check table counts
SELECT source_system, COUNT(*) as table_count
FROM tables_metadata
GROUP BY source_system;

-- Check column counts
SELECT COUNT(*) as total_columns
FROM columns_metadata;

-- View sample data
SELECT * FROM v_searchable_metadata LIMIT 10;
```

## 📊 Delta Table Schemas

### tables_metadata

Stores table-level metadata from all sources.

```sql
CREATE TABLE tables_metadata (
    table_id STRING,                    -- Unique identifier
    source_system STRING,                -- databricks, hive, db2, erwin
    catalog_name STRING,                 -- Unity Catalog name (if applicable)
    database_name STRING,                -- Database/catalog name
    schema_name STRING,                  -- Schema name
    table_name STRING,                   -- Table name
    full_table_name STRING,              -- Fully qualified name
    table_type STRING,                   -- TABLE, VIEW, EXTERNAL, etc.
    description STRING,                  -- Table description
    owner STRING,                        -- Table owner
    created_at TIMESTAMP,               -- Creation timestamp
    last_modified TIMESTAMP,            -- Last modification timestamp
    row_count BIGINT,                   -- Number of rows
    size_bytes BIGINT,                  -- Storage size in bytes
    storage_location STRING,            -- Physical storage path
    data_format STRING,                 -- DELTA, PARQUET, CSV, etc.
    is_partitioned BOOLEAN,             -- Partition status
    partition_columns ARRAY<STRING>,    -- Partition column names
    tags ARRAY<STRING>,                 -- User-defined tags
    properties MAP<STRING, STRING>,     -- Additional properties
    extraction_time TIMESTAMP           -- When metadata was extracted
)
USING DELTA
PARTITIONED BY (source_system)
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);
```

### columns_metadata

Stores column-level metadata.

```sql
CREATE TABLE columns_metadata (
    column_id STRING,                   -- Unique identifier
    table_id STRING,                    -- Foreign key to tables_metadata
    source_system STRING,               -- Source system
    full_table_name STRING,             -- Fully qualified table name
    column_name STRING,                 -- Column name
    ordinal_position INT,               -- Position in table
    data_type STRING,                   -- Data type
    is_nullable BOOLEAN,                -- Nullable flag
    is_primary_key BOOLEAN,             -- Primary key flag
    is_pii BOOLEAN,                     -- Contains PII
    description STRING                  -- Column description
)
USING DELTA
PARTITIONED BY (source_system);
```

## 🔍 Searching Metadata

### SQL Queries

#### 1. Search for Tables by Name

```sql
SELECT 
    source_system,
    full_table_name,
    description,
    owner,
    row_count
FROM tables_metadata
WHERE LOWER(table_name) LIKE '%customer%'
ORDER BY table_name;
```

#### 2. Find Tables with PII

```sql
SELECT DISTINCT
    t.full_table_name,
    t.source_system,
    t.owner,
    COUNT(c.column_id) as pii_column_count,
    COLLECT_LIST(c.column_name) as pii_columns
FROM tables_metadata t
JOIN columns_metadata c ON t.table_id = c.table_id
WHERE c.is_pii = true
GROUP BY t.full_table_name, t.source_system, t.owner
ORDER BY pii_column_count DESC;
```

#### 3. Search Columns Across All Tables

```sql
SELECT 
    full_table_name,
    column_name,
    data_type,
    is_pii,
    description
FROM columns_metadata
WHERE LOWER(column_name) LIKE '%email%'
ORDER BY full_table_name;
```

#### 4. Get Table with Access Groups

```sql
SELECT 
    t.full_table_name,
    t.description,
    ag.group_name,
    ram.access_level,
    ag.request_process
FROM tables_metadata t
JOIN resource_access_mapping ram ON t.table_id = ram.table_id
JOIN ad_groups ag ON ram.ad_group_id = ag.ad_group_id
WHERE t.table_name = 'customers'
AND ag.is_active = true;
```

### Python API

```python
from databricks import sql

# Connect to SQL Warehouse
connection = sql.connect(
    server_hostname="your-workspace.cloud.databricks.com",
    http_path="/sql/1.0/warehouses/...",
    access_token="your-token"
)

# Search for tables
cursor = connection.cursor()
cursor.execute("""
    SELECT * FROM metadata_catalog.technical_metadata.v_searchable_metadata
    WHERE LOWER(table_name) LIKE '%sales%'
    LIMIT 10
""")

results = cursor.fetchall()
for row in results:
    print(row)
```

### REST API

Start the FastAPI server:

```bash
export DATABRICKS_SERVER_HOSTNAME="your-workspace.cloud.databricks.com"
export DATABRICKS_HTTP_PATH="/sql/1.0/warehouses/..."
export DATABRICKS_TOKEN="your-token"

uvicorn databricks_delta_api:app --reload
```

Search via REST API:

```bash
# Search for tables
curl "http://localhost:8000/api/v1/search?q=customer&source_system=databricks"

# Get table details
curl "http://localhost:8000/api/v1/tables/databricks_prod_sales_customers"

# Get statistics
curl "http://localhost:8000/api/v1/stats"
```

## 📈 Dashboards with Databricks SQL

### 1. Create SQL Warehouse

1. Go to Databricks SQL
2. Create a new SQL Warehouse
3. Choose the appropriate size (Small for testing, Medium+ for production)

### 2. Create Dashboard Queries

#### Metadata Coverage

```sql
SELECT 
    source_system,
    COUNT(*) as total_tables,
    SUM(CASE WHEN description IS NOT NULL THEN 1 ELSE 0 END) as documented_tables,
    ROUND(100.0 * SUM(CASE WHEN description IS NOT NULL THEN 1 ELSE 0 END) / COUNT(*), 2) as coverage_pct
FROM metadata_catalog.technical_metadata.tables_metadata
GROUP BY source_system;
```

#### Popular Tables

```sql
SELECT 
    t.full_table_name,
    t.source_system,
    COUNT(DISTINCT sh.search_id) as search_count,
    COUNT(DISTINCT sh.user_id) as unique_users,
    MAX(sh.search_timestamp) as last_searched
FROM metadata_catalog.technical_metadata.tables_metadata t
JOIN metadata_catalog.technical_metadata.search_history sh 
    ON t.table_id = sh.clicked_table_id
WHERE sh.search_timestamp >= CURRENT_DATE - INTERVAL 30 DAYS
GROUP BY t.full_table_name, t.source_system
ORDER BY search_count DESC
LIMIT 20;
```

#### PII Distribution

```sql
SELECT 
    t.source_system,
    t.database_name,
    COUNT(DISTINCT t.table_id) as tables_with_pii,
    SUM(
        (SELECT COUNT(*) FROM metadata_catalog.technical_metadata.columns_metadata c
         WHERE c.table_id = t.table_id AND c.is_pii = true)
    ) as total_pii_columns
FROM metadata_catalog.technical_metadata.tables_metadata t
WHERE EXISTS (
    SELECT 1 FROM metadata_catalog.technical_metadata.columns_metadata c
    WHERE c.table_id = t.table_id AND c.is_pii = true
)
GROUP BY t.source_system, t.database_name
ORDER BY total_pii_columns DESC;
```

## 🔄 Scheduled Metadata Refresh

### Using Databricks Jobs

Create a job to refresh metadata daily:

```python
# Job configuration
{
    "name": "Metadata Extraction - Daily",
    "schedule": {
        "quartz_cron_expression": "0 0 2 * * ?",  # 2 AM daily
        "timezone_id": "America/New_York"
    },
    "tasks": [{
        "task_key": "extract_metadata",
        "notebook_task": {
            "notebook_path": "/Shared/metadata/load_metadata_to_delta",
            "base_parameters": {}
        },
        "existing_cluster_id": "your-cluster-id"
    }],
    "email_notifications": {
        "on_failure": ["data-team@company.com"]
    }
}
```

### Using Databricks Workflows

```python
# Create workflow in notebooks/load_metadata_to_delta.py
from load_metadata_to_delta import MetadataToDeltaLoader, get_config

# Initialize
loader = MetadataToDeltaLoader(
    catalog_name="metadata_catalog",
    schema_name="technical_metadata"
)

# Run extraction
config = get_config()
loader.run_full_load(config)
```

## 🎨 Integration with BI Tools

### Tableau

1. Connect to Databricks SQL Warehouse
2. Select the `metadata_catalog` database
3. Use tables or views as data sources
4. Create visualizations

### Power BI

1. Get Data → More → Databricks
2. Enter server hostname and HTTP path
3. Choose `metadata_catalog.technical_metadata` schema
4. Import views for better performance

### Looker

```lookml
connection: "databricks_metadata"

explore: tables_metadata {
  join: columns_metadata {
    sql_on: ${tables_metadata.table_id} = ${columns_metadata.table_id} ;;
    relationship: one_to_many
  }
  
  join: resource_access_mapping {
    sql_on: ${tables_metadata.table_id} = ${resource_access_mapping.table_id} ;;
    relationship: one_to_many
  }
}
```

## ⚡ Performance Optimization

### 1. Z-Ordering

Optimize tables for common query patterns:

```sql
-- Optimize tables_metadata
OPTIMIZE metadata_catalog.technical_metadata.tables_metadata
ZORDER BY (source_system, database_name, schema_name);

-- Optimize columns_metadata
OPTIMIZE metadata_catalog.technical_metadata.columns_metadata
ZORDER BY (source_system, table_id);
```

### 2. Liquid Clustering (Databricks Runtime 13.3+)

```sql
ALTER TABLE metadata_catalog.technical_metadata.tables_metadata
CLUSTER BY (source_system, database_name);
```

### 3. Caching

Enable result caching in SQL Warehouse settings for frequently run queries.

### 4. Materialized Views

```sql
CREATE MATERIALIZED VIEW mv_table_summary AS
SELECT 
    source_system,
    database_name,
    COUNT(*) as table_count,
    SUM(row_count) as total_rows,
    SUM(size_bytes) as total_size
FROM metadata_catalog.technical_metadata.tables_metadata
GROUP BY source_system, database_name;

-- Refresh periodically
REFRESH MATERIALIZED VIEW mv_table_summary;
```

## 🔐 Access Control

### Grant Permissions

```sql
-- Grant usage on catalog
GRANT USAGE ON CATALOG metadata_catalog TO `data_consumers`;

-- Grant select on schema
GRANT USAGE, SELECT ON SCHEMA metadata_catalog.technical_metadata TO `data_consumers`;

-- Grant select on specific tables
GRANT SELECT ON TABLE metadata_catalog.technical_metadata.tables_metadata TO `data_consumers`;
GRANT SELECT ON TABLE metadata_catalog.technical_metadata.columns_metadata TO `data_consumers`;
```

### Row-Level Security

```sql
-- Create secure view with row filtering
CREATE VIEW metadata_catalog.technical_metadata.tables_metadata_secure AS
SELECT *
FROM metadata_catalog.technical_metadata.tables_metadata
WHERE 
    owner = current_user() 
    OR source_system IN (
        SELECT source_system 
        FROM user_permissions 
        WHERE user_id = current_user()
    );
```

## 📊 Monitoring

### Query History

```sql
SELECT 
    query_text,
    user_name,
    execution_time,
    rows_produced
FROM system.query.history
WHERE query_text LIKE '%metadata_catalog%'
ORDER BY start_time DESC
LIMIT 100;
```

### Table Usage

```sql
SELECT 
    table_catalog,
    table_schema,
    table_name,
    COUNT(*) as query_count,
    SUM(rows_produced) as total_rows_read
FROM system.query.history
WHERE table_catalog = 'metadata_catalog'
AND start_time >= CURRENT_DATE - INTERVAL 7 DAYS
GROUP BY table_catalog, table_schema, table_name
ORDER BY query_count DESC;
```

## 🔄 Time Travel

Query historical metadata:

```sql
-- View metadata as it was 7 days ago
SELECT * 
FROM metadata_catalog.technical_metadata.tables_metadata
VERSION AS OF 7 DAYS AGO
WHERE table_name = 'customers';

-- View metadata at specific timestamp
SELECT *
FROM metadata_catalog.technical_metadata.tables_metadata
TIMESTAMP AS OF '2025-01-01 00:00:00'
WHERE source_system = 'databricks';

-- Track changes over time
SELECT *
FROM table_changes('metadata_catalog.technical_metadata.tables_metadata', 1)
WHERE table_name = 'customers';
```

## 📝 Best Practices

1. **Partitioning**: Partition by source_system for better query performance
2. **Regular Optimization**: Run OPTIMIZE weekly
3. **Monitoring**: Track query performance and adjust Z-ordering
4. **Incremental Updates**: Use MERGE for upserts instead of full rewrites
5. **Validation**: Add data quality checks after extraction
6. **Documentation**: Keep README updated with schema changes
7. **Backup**: Enable Delta table history and time travel
8. **Security**: Use Unity Catalog for fine-grained access control

## 🎯 Summary

You now have metadata served from Databricks Delta tables with:

✅ High-performance storage with Delta Lake
✅ SQL and API access to metadata
✅ Integration with BI tools
✅ Scheduled refresh capabilities
✅ Time travel for historical analysis
✅ Optimized for analytical queries

**Next Steps:**
- Set up automated extraction jobs
- Create Databricks SQL dashboards
- Configure alerts for metadata quality
- Integrate with data catalog tools
