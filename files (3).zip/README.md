# Technical Metadata Management Solution

A comprehensive metadata management platform that integrates **Databricks**, **On-Premise Hive**, **DB2**, and **Erwin Data Modeler** with powerful search capabilities and Active Directory group-based access control.

## 🎯 Features

- **Multi-Source Metadata Extraction**: Automated extraction from Databricks, Hive, DB2, and Erwin
- **Advanced Search**: Full-text search across tables, columns, and descriptions with fuzzy matching
- **Access Management**: Integration with Active Directory groups for access control
- **Self-Service Access Requests**: Users can request access with automated workflow routing
- **Rich Metadata**: Capture table descriptions, column details, data types, relationships, and more
- **Data Classification**: Track PII and sensitive data classifications
- **Business Glossary**: Integrate logical model entities and business terms from Erwin
- **API-First Design**: RESTful API for integration with other tools
- **Modern UI**: React-based search interface with detailed table views

## 📋 Table of Contents

- [Architecture](#architecture)
- [Quick Start](#quick-start)
- [Components](#components)
- [Configuration](#configuration)
- [Usage Examples](#usage-examples)
- [API Documentation](#api-documentation)
- [Contributing](#contributing)
- [License](#license)

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Data Sources Layer                        │
├──────────────┬──────────────┬──────────────┬────────────────┤
│  Databricks  │     Hive     │     DB2      │     Erwin      │
│  (Unity Cat) │  (Metastore) │  (Sys Cat)   │  (XML Export)  │
└──────┬───────┴──────┬───────┴──────┬───────┴──────┬─────────┘
       │              │              │              │
       └──────────────┴──────────────┴──────────────┘
                      │
       ┌──────────────▼──────────────────┐
       │   Metadata Extractors (Python)   │
       │  - Scheduled/On-demand ETL       │
       │  - Transformation & Normalization│
       └──────────────┬──────────────────┘
                      │
       ┌──────────────▼──────────────────┐
       │  Central Metadata Repository     │
       │       (PostgreSQL)               │
       │  - Tables & Columns              │
       │  - AD Group Mappings             │
       │  - Search Indexes                │
       └──────────────┬──────────────────┘
                      │
       ┌──────────────▼──────────────────┐
       │      Search API (FastAPI)        │
       │  - RESTful Endpoints             │
       │  - Full-text Search              │
       │  - Access Request Handling       │
       └──────────────┬──────────────────┘
                      │
       ┌──────────────▼──────────────────┐
       │    Web UI (React)                │
       │  - Search Interface              │
       │  - Table Details                 │
       │  - Access Request Forms          │
       └──────────────────────────────────┘
```

## 🚀 Quick Start

### Prerequisites

- Python 3.9+
- PostgreSQL 14+
- Node.js 16+ (for frontend)
- Access credentials for data sources

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/yourorg/metadata-management.git
cd metadata-management
```

2. **Set up the database**
```bash
# Create PostgreSQL database
createdb metadata_catalog

# Run schema
psql -d metadata_catalog -f metadata_repository_schema.sql
```

3. **Install Python dependencies**
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

4. **Configure environment variables**
```bash
cp .env.example .env
# Edit .env with your credentials
```

5. **Run initial metadata extraction**
```bash
python metadata_orchestrator.py
```

6. **Start the API server**
```bash
uvicorn metadata_search_api:app --reload
```

7. **Start the frontend** (in a new terminal)
```bash
cd frontend
npm install
npm start
```

8. **Access the application**
- Frontend: http://localhost:3000
- API Docs: http://localhost:8000/docs

## 📦 Components

### 1. Metadata Extractors

Extract metadata from various data sources:

- **`databricks_extractor.py`**: Extracts from Databricks Unity Catalog or Hive Metastore
- **`hive_extractor.py`**: Extracts from on-premise Hive via HiveServer2
- **`db2_extractor.py`**: Extracts from IBM DB2 system catalogs
- **`erwin_extractor.py`**: Parses Erwin XML exports

### 2. Central Repository

**`metadata_repository_schema.sql`**: PostgreSQL schema with:
- Tables, columns, and relationships
- AD group mappings
- Business glossary terms
- Search indexes
- Access request tracking

### 3. Search API

**`metadata_search_api.py`**: FastAPI application providing:
- `/api/v1/search` - Full-text search with filters
- `/api/v1/tables/{id}` - Detailed table metadata
- `/api/v1/access-requests` - Submit access requests
- `/api/v1/filters` - Available filter options

### 4. Frontend

**`MetadataSearch.jsx`**: React component with:
- Search interface with faceted filters
- Table detail modal with column information
- AD group display with access request buttons
- Responsive design

### 5. Orchestration

**`metadata_orchestrator.py`**: Coordinates:
- Metadata extraction from all sources
- Data transformation and normalization
- Loading into central repository
- Error handling and logging

## ⚙️ Configuration

### Environment Variables

Create a `.env` file with:

```bash
# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/metadata_catalog

# Databricks
DATABRICKS_WORKSPACE_URL=https://adb-xxxxx.azuredatabricks.net
DATABRICKS_TOKEN=your-token

# Hive
HIVE_HOST=hive-server.company.com
HIVE_PORT=10000
HIVE_USERNAME=your-username
HIVE_PASSWORD=your-password
HIVE_AUTH=LDAP

# DB2
DB2_DATABASE=MYDB
DB2_HOST=db2-server.company.com
DB2_PORT=50000
DB2_USERNAME=your-username
DB2_PASSWORD=your-password

# Erwin
ERWIN_XML_PATH=/path/to/erwin_export.xml

# LDAP (for AD sync)
LDAP_SERVER=ldap://dc.company.com
LDAP_USER=cn=service_account,ou=users,dc=company,dc=com
LDAP_PASSWORD=your-password
```

### AD Group Mapping

Map tables to AD groups:

```sql
-- Map schema to AD group
INSERT INTO resource_access_mapping (resource_type, resource_id, ad_group_id, access_level)
SELECT 'table', table_id, 
       (SELECT ad_group_id FROM ad_groups WHERE group_name = 'AD_DATA_Finance_Readers'),
       'READ'
FROM tables t
JOIN schemas s ON t.schema_id = s.schema_id
WHERE s.schema_name = 'finance';
```

## 📖 Usage Examples

### Search for Tables

```bash
# Search via API
curl "http://localhost:8000/api/v1/search?q=customer&source_type=databricks"

# With filters
curl "http://localhost:8000/api/v1/search?q=sales&database=prod&has_pii=true"
```

### Get Table Details

```bash
curl "http://localhost:8000/api/v1/tables/123"
```

### Request Access

```bash
curl -X POST "http://localhost:8000/api/v1/access-requests" \
  -H "Content-Type: application/json" \
  -d '{
    "table_id": 123,
    "ad_group_id": 5,
    "access_level": "READ",
    "business_justification": "Need access for quarterly reporting"
  }' \
  --url-query "user_id=jdoe&user_email=jdoe@company.com"
```

### Extract Metadata Programmatically

```python
from databricks_extractor import DatabricksMetadataExtractor

# Initialize extractor
extractor = DatabricksMetadataExtractor(
    workspace_url="https://adb-xxxxx.azuredatabricks.net",
    token="your-token",
    use_unity_catalog=True
)

# Extract all metadata
metadata = extractor.extract_all_metadata()

# Process results
for table in metadata:
    print(f"Found table: {table['full_table_name']}")
    print(f"  Columns: {len(table['columns'])}")
    print(f"  Owner: {table['owner']}")
```

## 🔍 API Documentation

Full API documentation is available at `/docs` when running the FastAPI server:

```bash
# Start server
uvicorn metadata_search_api:app --reload

# View docs
open http://localhost:8000/docs
```

### Key Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/v1/search` | GET | Search tables with filters |
| `/api/v1/tables/{id}` | GET | Get detailed table metadata |
| `/api/v1/filters` | GET | Get available filter options |
| `/api/v1/access-requests` | POST | Submit access request |
| `/api/v1/popular-tables` | GET | Get frequently accessed tables |

## 🧪 Testing

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=. --cov-report=html

# Test specific component
pytest test_databricks_extractor.py -v
```

## 📈 Monitoring

### Metrics

The API exposes Prometheus metrics at `/metrics`:

- Request count and latency
- Search query performance
- Extraction job status
- Database connection pool

### Logs

```bash
# View API logs
tail -f logs/api.log

# View extraction logs
tail -f logs/extraction.log
```

## 🔐 Security

- All credentials stored in environment variables or secrets manager
- SSL/TLS for all connections
- Role-based access control (RBAC)
- Audit logging of all searches and access requests
- PII masking in search results

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📞 Support

For issues and questions:
- 📧 Email: data-platform@company.com
- 💬 Slack: #data-catalog
- 📖 Wiki: https://wiki.company.com/data-catalog

## 🗺️ Roadmap

- [ ] Elasticsearch integration for advanced search
- [ ] Data lineage visualization
- [ ] Column-level lineage tracking
- [ ] Data quality metrics integration
- [ ] Usage analytics dashboard
- [ ] ML-based data discovery recommendations
- [ ] Slack/Teams notifications for access requests
- [ ] Self-service data profiling

## 📚 Additional Documentation

- [Deployment Guide](DEPLOYMENT_GUIDE.md)
- [Architecture Document](metadata_solution_architecture.md)
- [API Reference](http://localhost:8000/docs)
- [User Guide](docs/USER_GUIDE.md)

---

**Built with ❤️ by the Data Platform Team**
