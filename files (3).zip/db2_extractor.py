"""
DB2 Metadata Extractor
Extracts table and column metadata from IBM DB2 database
"""

import ibm_db
import ibm_db_dbi
from typing import List, Dict, Any
from datetime import datetime
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DB2MetadataExtractor:
    """Extract metadata from IBM DB2 using system catalog tables"""
    
    def __init__(self, database: str, hostname: str, port: int, 
                 uid: str, pwd: str, schema: str = None):
        """
        Initialize DB2 extractor
        
        Args:
            database: Database name
            hostname: DB2 server hostname
            port: DB2 port (typically 50000)
            uid: Username
            pwd: Password
            schema: Optional schema to filter (None = all schemas)
        """
        self.database = database
        self.hostname = hostname
        self.port = port
        self.uid = uid
        self.pwd = pwd
        self.schema_filter = schema
        self.conn = None
        self.conn_str = (
            f"DATABASE={database};"
            f"HOSTNAME={hostname};"
            f"PORT={port};"
            f"PROTOCOL=TCPIP;"
            f"UID={uid};"
            f"PWD={pwd};"
        )
    
    def connect(self):
        """Establish connection to DB2"""
        try:
            self.conn = ibm_db.connect(self.conn_str, "", "")
            logger.info(f"Connected to DB2 database {self.database}")
        except Exception as e:
            logger.error(f"Failed to connect to DB2: {e}")
            raise
    
    def close(self):
        """Close connection to DB2"""
        if self.conn:
            ibm_db.close(self.conn)
            logger.info("DB2 connection closed")
    
    def get_schemas(self) -> List[str]:
        """Get all schemas in the database"""
        query = """
        SELECT DISTINCT SCHEMANAME 
        FROM SYSCAT.TABLES 
        WHERE TYPE IN ('T', 'V')
        AND SCHEMANAME NOT LIKE 'SYS%'
        ORDER BY SCHEMANAME
        """
        
        if self.schema_filter:
            query = query.replace(
                "ORDER BY SCHEMANAME",
                f"AND SCHEMANAME = '{self.schema_filter}' ORDER BY SCHEMANAME"
            )
        
        stmt = ibm_db.exec_immediate(self.conn, query)
        schemas = []
        result = ibm_db.fetch_assoc(stmt)
        while result:
            schemas.append(result['SCHEMANAME'])
            result = ibm_db.fetch_assoc(stmt)
        
        logger.info(f"Found {len(schemas)} schemas")
        return schemas
    
    def get_tables(self, schema: str) -> List[Dict[str, Any]]:
        """Get all tables and views in a schema"""
        query = """
        SELECT 
            TABNAME,
            TYPE,
            OWNER,
            CREATED,
            STATS_TIME,
            CARD as ROW_COUNT,
            NPAGES,
            FPAGES,
            REMARKS
        FROM SYSCAT.TABLES
        WHERE TABSCHEMA = ?
        AND TYPE IN ('T', 'V')
        ORDER BY TABNAME
        """
        
        stmt = ibm_db.prepare(self.conn, query)
        ibm_db.bind_param(stmt, 1, schema)
        ibm_db.execute(stmt)
        
        tables = []
        result = ibm_db.fetch_assoc(stmt)
        while result:
            tables.append({
                'table_name': result['TABNAME'],
                'table_type': 'TABLE' if result['TYPE'] == 'T' else 'VIEW',
                'owner': result['OWNER'],
                'created': str(result['CREATED']) if result['CREATED'] else None,
                'stats_time': str(result['STATS_TIME']) if result['STATS_TIME'] else None,
                'row_count': result['ROW_COUNT'],
                'num_pages': result['NPAGES'],
                'fpages': result['FPAGES'],
                'remarks': result['REMARKS']
            })
            result = ibm_db.fetch_assoc(stmt)
        
        logger.info(f"Found {len(tables)} tables in schema {schema}")
        return tables
    
    def get_columns(self, schema: str, table: str) -> List[Dict[str, Any]]:
        """Get all columns for a table"""
        query = """
        SELECT 
            COLNAME,
            COLNO,
            TYPENAME,
            LENGTH,
            SCALE,
            NULLS,
            DEFAULT,
            IDENTITY,
            KEYSEQ,
            REMARKS
        FROM SYSCAT.COLUMNS
        WHERE TABSCHEMA = ?
        AND TABNAME = ?
        ORDER BY COLNO
        """
        
        stmt = ibm_db.prepare(self.conn, query)
        ibm_db.bind_param(stmt, 1, schema)
        ibm_db.bind_param(stmt, 2, table)
        ibm_db.execute(stmt)
        
        columns = []
        result = ibm_db.fetch_assoc(stmt)
        while result:
            # Construct full data type
            data_type = result['TYPENAME']
            if result['LENGTH']:
                if result['TYPENAME'] in ('VARCHAR', 'CHAR', 'VARGRAPHIC', 'GRAPHIC'):
                    data_type = f"{data_type}({result['LENGTH']})"
                elif result['TYPENAME'] in ('DECIMAL', 'NUMERIC'):
                    if result['SCALE']:
                        data_type = f"{data_type}({result['LENGTH']},{result['SCALE']})"
                    else:
                        data_type = f"{data_type}({result['LENGTH']})"
            
            columns.append({
                'column_name': result['COLNAME'],
                'ordinal_position': result['COLNO'] + 1,  # DB2 is 0-based
                'data_type': data_type,
                'base_type': result['TYPENAME'],
                'length': result['LENGTH'],
                'scale': result['SCALE'],
                'is_nullable': result['NULLS'] == 'Y',
                'default_value': result['DEFAULT'],
                'is_identity': result['IDENTITY'] == 'Y',
                'is_primary_key': result['KEYSEQ'] is not None,
                'key_sequence': result['KEYSEQ'],
                'comment': result['REMARKS']
            })
            result = ibm_db.fetch_assoc(stmt)
        
        return columns
    
    def get_indexes(self, schema: str, table: str) -> List[Dict[str, Any]]:
        """Get indexes for a table"""
        query = """
        SELECT 
            i.INDNAME,
            i.UNIQUERULE,
            i.INDEXTYPE,
            ic.COLNAME,
            ic.COLSEQ
        FROM SYSCAT.INDEXES i
        JOIN SYSCAT.INDEXCOLUSE ic ON i.INDSCHEMA = ic.INDSCHEMA 
                                   AND i.INDNAME = ic.INDNAME
        WHERE i.TABSCHEMA = ?
        AND i.TABNAME = ?
        ORDER BY i.INDNAME, ic.COLSEQ
        """
        
        stmt = ibm_db.prepare(self.conn, query)
        ibm_db.bind_param(stmt, 1, schema)
        ibm_db.bind_param(stmt, 2, table)
        ibm_db.execute(stmt)
        
        indexes = {}
        result = ibm_db.fetch_assoc(stmt)
        while result:
            index_name = result['INDNAME']
            if index_name not in indexes:
                indexes[index_name] = {
                    'index_name': index_name,
                    'is_unique': result['UNIQUERULE'] in ('U', 'P'),
                    'is_primary': result['UNIQUERULE'] == 'P',
                    'index_type': result['INDEXTYPE'],
                    'columns': []
                }
            indexes[index_name]['columns'].append(result['COLNAME'])
            result = ibm_db.fetch_assoc(stmt)
        
        return list(indexes.values())
    
    def get_foreign_keys(self, schema: str, table: str) -> List[Dict[str, Any]]:
        """Get foreign key relationships"""
        query = """
        SELECT 
            r.CONSTNAME,
            r.REFTABSCHEMA,
            r.REFTABNAME,
            r.REFKEYNAME,
            kcu.COLNAME,
            kcu.COLSEQ
        FROM SYSCAT.REFERENCES r
        JOIN SYSCAT.KEYCOLUSE kcu ON r.CONSTNAME = kcu.CONSTNAME
                                   AND r.TABSCHEMA = kcu.TABSCHEMA
        WHERE r.TABSCHEMA = ?
        AND r.TABNAME = ?
        ORDER BY r.CONSTNAME, kcu.COLSEQ
        """
        
        stmt = ibm_db.prepare(self.conn, query)
        ibm_db.bind_param(stmt, 1, schema)
        ibm_db.bind_param(stmt, 2, table)
        ibm_db.execute(stmt)
        
        foreign_keys = {}
        result = ibm_db.fetch_assoc(stmt)
        while result:
            fk_name = result['CONSTNAME']
            if fk_name not in foreign_keys:
                foreign_keys[fk_name] = {
                    'constraint_name': fk_name,
                    'referenced_schema': result['REFTABSCHEMA'],
                    'referenced_table': result['REFTABNAME'],
                    'referenced_key': result['REFKEYNAME'],
                    'columns': []
                }
            foreign_keys[fk_name]['columns'].append(result['COLNAME'])
            result = ibm_db.fetch_assoc(stmt)
        
        return list(foreign_keys.values())
    
    def get_table_metadata(self, schema: str, table_info: Dict[str, Any]) -> Dict[str, Any]:
        """Get complete metadata for a table"""
        table_name = table_info['table_name']
        
        try:
            # Get columns
            columns = self.get_columns(schema, table_name)
            
            # Get indexes
            indexes = self.get_indexes(schema, table_name)
            
            # Get foreign keys
            foreign_keys = self.get_foreign_keys(schema, table_name)
            
            # Build standardized metadata
            metadata = {
                'source_system': 'db2',
                'database_name': self.database,
                'schema_name': schema,
                'table_name': table_name,
                'full_table_name': f"{self.database}.{schema}.{table_name}",
                'table_type': table_info['table_type'],
                'owner': table_info['owner'],
                'created_at': table_info['created'],
                'stats_time': table_info['stats_time'],
                'row_count': table_info['row_count'],
                'num_pages': table_info['num_pages'],
                'comment': table_info['remarks'],
                'columns': columns,
                'indexes': indexes,
                'foreign_keys': foreign_keys,
                'extracted_at': datetime.utcnow().isoformat()
            }
            
            return metadata
        
        except Exception as e:
            logger.error(f"Error extracting metadata for {schema}.{table_name}: {e}")
            raise
    
    def extract_all_metadata(self) -> List[Dict[str, Any]]:
        """
        Extract all metadata from DB2
        
        Returns:
            List of table metadata dictionaries
        """
        all_metadata = []
        
        try:
            if not self.conn:
                self.connect()
            
            schemas = self.get_schemas()
            
            for schema in schemas:
                try:
                    tables = self.get_tables(schema)
                    
                    for table_info in tables:
                        try:
                            metadata = self.get_table_metadata(schema, table_info)
                            all_metadata.append(metadata)
                        except Exception as e:
                            logger.error(f"Error extracting table {schema}.{table_info['table_name']}: {e}")
                            continue
                
                except Exception as e:
                    logger.error(f"Error extracting tables from schema {schema}: {e}")
                    continue
            
            logger.info(f"Successfully extracted metadata for {len(all_metadata)} tables")
            return all_metadata
        
        except Exception as e:
            logger.error(f"Error in metadata extraction: {e}")
            raise


# Example usage
if __name__ == "__main__":
    # Configuration
    DATABASE = "MYDB"
    HOSTNAME = "db2-server.company.com"
    PORT = 50000
    USERNAME = "your-username"
    PASSWORD = "your-password"
    
    # Initialize extractor
    extractor = DB2MetadataExtractor(
        database=DATABASE,
        hostname=HOSTNAME,
        port=PORT,
        uid=USERNAME,
        pwd=PASSWORD
    )
    
    try:
        # Extract metadata
        metadata = extractor.extract_all_metadata()
        
        # Print sample
        if metadata:
            print(f"Extracted {len(metadata)} tables")
            print("\nSample table metadata:")
            import json
            print(json.dumps(metadata[0], indent=2))
    finally:
        extractor.close()
