"""
Databricks Metadata Extractor
Extracts table and column metadata from Databricks Unity Catalog or Hive Metastore
"""

import requests
from typing import List, Dict, Any
from datetime import datetime
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DatabricksMetadataExtractor:
    """Extract metadata from Databricks using SQL API and REST API"""
    
    def __init__(self, workspace_url: str, token: str, use_unity_catalog: bool = True):
        """
        Initialize Databricks extractor
        
        Args:
            workspace_url: Databricks workspace URL (e.g., https://adb-xxxxx.azuredatabricks.net)
            token: Personal access token or service principal token
            use_unity_catalog: True for Unity Catalog, False for Hive Metastore
        """
        self.workspace_url = workspace_url.rstrip('/')
        self.token = token
        self.use_unity_catalog = use_unity_catalog
        self.headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
    
    def get_catalogs(self) -> List[Dict[str, Any]]:
        """Get all catalogs (Unity Catalog only)"""
        if not self.use_unity_catalog:
            return [{'name': 'hive_metastore', 'owner': 'system'}]
        
        url = f"{self.workspace_url}/api/2.1/unity-catalog/catalogs"
        response = requests.get(url, headers=self.headers)
        response.raise_for_status()
        
        catalogs = response.json().get('catalogs', [])
        logger.info(f"Found {len(catalogs)} catalogs")
        return catalogs
    
    def get_schemas(self, catalog_name: str) -> List[Dict[str, Any]]:
        """Get all schemas in a catalog"""
        url = f"{self.workspace_url}/api/2.1/unity-catalog/schemas"
        params = {'catalog_name': catalog_name}
        response = requests.get(url, headers=self.headers, params=params)
        response.raise_for_status()
        
        schemas = response.json().get('schemas', [])
        logger.info(f"Found {len(schemas)} schemas in catalog {catalog_name}")
        return schemas
    
    def get_tables(self, catalog_name: str, schema_name: str) -> List[Dict[str, Any]]:
        """Get all tables in a schema"""
        url = f"{self.workspace_url}/api/2.1/unity-catalog/tables"
        params = {
            'catalog_name': catalog_name,
            'schema_name': schema_name
        }
        response = requests.get(url, headers=self.headers, params=params)
        response.raise_for_status()
        
        tables = response.json().get('tables', [])
        logger.info(f"Found {len(tables)} tables in {catalog_name}.{schema_name}")
        return tables
    
    def get_table_details(self, full_table_name: str) -> Dict[str, Any]:
        """
        Get detailed information about a table including columns
        
        Args:
            full_table_name: Format catalog.schema.table or schema.table
        """
        url = f"{self.workspace_url}/api/2.1/unity-catalog/tables/{full_table_name}"
        response = requests.get(url, headers=self.headers)
        response.raise_for_status()
        
        return response.json()
    
    def extract_all_metadata(self) -> List[Dict[str, Any]]:
        """
        Extract all metadata from Databricks
        
        Returns:
            List of table metadata dictionaries with standardized format
        """
        all_metadata = []
        
        try:
            catalogs = self.get_catalogs()
            
            for catalog in catalogs:
                catalog_name = catalog['name']
                
                try:
                    schemas = self.get_schemas(catalog_name)
                    
                    for schema in schemas:
                        schema_name = schema['name']
                        
                        try:
                            tables = self.get_tables(catalog_name, schema_name)
                            
                            for table in tables:
                                try:
                                    # Get detailed table information
                                    full_name = table['full_name']
                                    table_details = self.get_table_details(full_name)
                                    
                                    # Transform to standardized format
                                    metadata = self._transform_to_standard_format(
                                        table_details, 
                                        catalog_name, 
                                        schema_name
                                    )
                                    all_metadata.append(metadata)
                                    
                                except Exception as e:
                                    logger.error(f"Error extracting table {table.get('name')}: {e}")
                                    continue
                        
                        except Exception as e:
                            logger.error(f"Error extracting tables from {schema_name}: {e}")
                            continue
                
                except Exception as e:
                    logger.error(f"Error extracting schemas from {catalog_name}: {e}")
                    continue
            
            logger.info(f"Successfully extracted metadata for {len(all_metadata)} tables")
            return all_metadata
        
        except Exception as e:
            logger.error(f"Error in metadata extraction: {e}")
            raise
    
    def _transform_to_standard_format(
        self, 
        table_details: Dict[str, Any],
        catalog_name: str,
        schema_name: str
    ) -> Dict[str, Any]:
        """Transform Databricks metadata to standardized format"""
        
        table_name = table_details.get('name')
        columns = table_details.get('columns', [])
        
        # Extract column information
        column_list = []
        for idx, col in enumerate(columns):
            column_list.append({
                'column_name': col.get('name'),
                'ordinal_position': idx + 1,
                'data_type': col.get('type_name'),
                'type_text': col.get('type_text'),
                'is_nullable': col.get('nullable', True),
                'comment': col.get('comment', ''),
                'is_partition_column': col.get('partition_index') is not None
            })
        
        # Build standardized metadata
        metadata = {
            'source_system': 'databricks',
            'catalog_name': catalog_name,
            'schema_name': schema_name,
            'table_name': table_name,
            'full_table_name': f"{catalog_name}.{schema_name}.{table_name}",
            'table_type': table_details.get('table_type', 'MANAGED'),
            'data_source_format': table_details.get('data_source_format'),
            'storage_location': table_details.get('storage_location'),
            'owner': table_details.get('owner'),
            'comment': table_details.get('comment', ''),
            'created_at': table_details.get('created_at'),
            'created_by': table_details.get('created_by'),
            'updated_at': table_details.get('updated_at'),
            'updated_by': table_details.get('updated_by'),
            'table_id': table_details.get('table_id'),
            'columns': column_list,
            'properties': table_details.get('properties', {}),
            'extracted_at': datetime.utcnow().isoformat()
        }
        
        return metadata


# Example usage
if __name__ == "__main__":
    # Configuration
    WORKSPACE_URL = "https://adb-xxxxx.azuredatabricks.net"
    TOKEN = "your-databricks-token"
    
    # Initialize extractor
    extractor = DatabricksMetadataExtractor(
        workspace_url=WORKSPACE_URL,
        token=TOKEN,
        use_unity_catalog=True
    )
    
    # Extract metadata
    metadata = extractor.extract_all_metadata()
    
    # Print sample
    if metadata:
        print(f"Extracted {len(metadata)} tables")
        print("\nSample table metadata:")
        import json
        print(json.dumps(metadata[0], indent=2))
