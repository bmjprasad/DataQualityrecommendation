# Technical Metadata Management Solution Architecture

## Executive Summary
This document outlines the architecture for building a centralized metadata management platform that integrates Databricks, On-Premise Hive, DB2, and Erwin with search capabilities and Active Directory group mapping for access requests.

## Solution Components

### 1. Data Sources Integration

#### A. Databricks
- **Connection Method**: Databricks REST API / SQL Connector
- **Metadata to Extract**:
  - Catalogs, Schemas, Tables, Views
  - Column names, data types, comments
  - Table properties, location, format
  - Partition information
  - Last modified timestamps

#### B. On-Premise Hive
- **Connection Method**: HiveServer2 JDBC/Thrift
- **Metadata to Extract**:
  - Databases, Tables, Views
  - Column definitions, data types
  - Partition schemes
  - Storage location
  - Table statistics

#### C. DB2
- **Connection Method**: DB2 JDBC Driver
- **Metadata to Extract**:
  - Schemas, Tables, Views
  - Column definitions, constraints
  - Indexes, foreign keys
  - Table spaces
  - System catalog information

#### D. Erwin Data Modeler
- **Connection Method**: Erwin API / XML Export
- **Metadata to Extract**:
  - Logical and Physical models
  - Entity definitions
  - Attribute mappings
  - Relationships
  - Business definitions and glossary

### 2. Central Metadata Repository

#### Database Schema Design

```
METADATA_CATALOG
├── data_sources (Databricks, Hive, DB2, Erwin)
├── databases/schemas
├── tables
│   ├── table_id (PK)
│   ├── source_system
│   ├── database_name
│   ├── schema_name
│   ├── table_name
│   ├── table_type (TABLE, VIEW, EXTERNAL)
│   ├── description
│   ├── owner
│   ├── created_date
│   ├── last_modified_date
│   ├── row_count
│   ├── storage_location
│   ├── ad_group_read
│   ├── ad_group_write
│   └── tags
│
├── columns
│   ├── column_id (PK)
│   ├── table_id (FK)
│   ├── column_name
│   ├── ordinal_position
│   ├── data_type
│   ├── length
│   ├── precision
│   ├── scale
│   ├── is_nullable
│   ├── default_value
│   ├── description
│   ├── is_pii
│   └── tags
│
├── ad_group_mapping
│   ├── mapping_id (PK)
│   ├── resource_type (database, schema, table)
│   ├── resource_id
│   ├── ad_group_name
│   ├── access_level (READ, WRITE, ADMIN)
│   ├── group_description
│   └── request_process
│
└── search_index
    ├── Full-text index on table names, descriptions
    └── Full-text index on column names, descriptions
```

#### Technology Recommendations
- **Database**: PostgreSQL with full-text search OR Elasticsearch
- **Alternative**: Microsoft SQL Server (better AD integration)
- **Graph Option**: Neo4j for relationship-heavy queries

### 3. Metadata Extraction ETL Pipeline

#### Pipeline Architecture
```
Source Systems → Extractors → Transform → Load → Metadata DB → Index
```

#### Extraction Schedule
- **Full Refresh**: Weekly (complete metadata rebuild)
- **Incremental**: Daily (capture changes only)
- **Real-time**: Event-driven for critical changes

#### Implementation Tools
- **Orchestration**: Apache Airflow / Azure Data Factory
- **Processing**: Python with SQLAlchemy
- **API Integration**: REST clients for Databricks
- **JDBC**: For Hive and DB2

### 4. Search & Discovery Interface

#### Search Capabilities

##### A. Basic Search
- Table name search (fuzzy matching)
- Column name search
- Description search
- Tag-based filtering

##### B. Advanced Search
- Multi-field search (table + column + description)
- Faceted search by:
  - Data source
  - Database/Schema
  - Owner
  - Last modified date
  - Data classification (PII, Confidential)
- Boolean operators (AND, OR, NOT)

##### C. Search Results Display
```
Search Result Card:
├── Table Full Name (source.database.schema.table)
├── Description
├── Data Source Icon
├── Owner
├── Last Modified
├── Row Count
├── AD Groups (Read/Write)
├── Tags
└── Actions (View Details, Request Access)
```

#### Frontend Technology Options
- **Option 1**: React + Elasticsearch (best search performance)
- **Option 2**: Angular + PostgreSQL full-text search
- **Option 3**: Streamlit (rapid prototyping)

### 5. Active Directory Integration

#### AD Group Mapping Strategy

##### Mapping Levels
1. **Database Level**: AD_DATA_DBName_Read/Write
2. **Schema Level**: AD_DATA_DBName_SchemaName_Read/Write
3. **Table Level**: AD_DATA_DBName_SchemaName_TableName_Read/Write

##### Implementation Approach
```python
# Example mapping structure
ad_mapping = {
    "databricks.prod.finance.transactions": {
        "read_group": "AD_DATA_Finance_Readers",
        "write_group": "AD_DATA_Finance_Writers",
        "description": "Financial transaction data access",
        "request_process": "Submit ServiceNow ticket to Finance-DataAccess"
    }
}
```

#### Access Request Workflow
1. User searches and finds table
2. System displays required AD groups
3. User clicks "Request Access"
4. System shows:
   - AD Group name
   - Group description
   - Request process/link
   - Approver information
   - SLA for approval

#### Integration Methods
- **LDAP Query**: Retrieve AD group information
- **Microsoft Graph API**: Modern approach for Azure AD
- **ServiceNow/JIRA Integration**: Direct access request creation

### 6. API Layer

#### RESTful API Endpoints

```
GET  /api/v1/tables/search?q={query}&filters={filters}
GET  /api/v1/tables/{table_id}
GET  /api/v1/tables/{table_id}/columns
GET  /api/v1/tables/{table_id}/access-groups
POST /api/v1/access-requests
GET  /api/v1/sources
GET  /api/v1/databases?source={source}
```

#### Authentication
- OAuth 2.0 / SAML integration
- Corporate SSO integration
- API keys for service accounts

## Implementation Roadmap

### Phase 1: Foundation (Weeks 1-4)
- Set up metadata repository database
- Implement extractors for one source (Databricks)
- Basic search functionality
- Simple UI prototype

### Phase 2: Multi-Source Integration (Weeks 5-8)
- Add Hive, DB2, Erwin extractors
- Implement incremental refresh logic
- Enhanced search with filters
- AD group mapping framework

### Phase 3: Production Features (Weeks 9-12)
- Full-text search optimization
- Access request workflow
- User interface refinement
- Monitoring and alerting
- Documentation

### Phase 4: Advanced Features (Ongoing)
- Data lineage visualization
- Impact analysis
- Data quality metrics integration
- Usage analytics
- ML-based recommendations

## Technology Stack Recommendation

### Backend
- **Language**: Python 3.9+
- **Framework**: FastAPI / Flask
- **ORM**: SQLAlchemy
- **Task Queue**: Celery with Redis
- **Scheduler**: Apache Airflow

### Database
- **Primary**: PostgreSQL 14+ with pg_trgm extension
- **Search**: Elasticsearch 8+ (optional but recommended)
- **Cache**: Redis

### Frontend
- **Framework**: React with TypeScript
- **UI Library**: Material-UI or Ant Design
- **State Management**: Redux Toolkit
- **Search**: React-Instantsearch (if using Elasticsearch)

### Infrastructure
- **Container**: Docker
- **Orchestration**: Kubernetes (production) / Docker Compose (dev)
- **CI/CD**: Jenkins / GitLab CI / GitHub Actions
- **Monitoring**: Prometheus + Grafana

## Security Considerations

1. **Encryption**: All connections use TLS/SSL
2. **Credentials**: Store in HashiCorp Vault or Azure Key Vault
3. **Authentication**: Corporate SSO mandatory
4. **Authorization**: Role-based access control (RBAC)
5. **Audit Logging**: Track all searches and access requests
6. **Data Masking**: PII columns flagged and masked in preview

## Key Success Metrics

- **Coverage**: % of tables/columns with metadata
- **Search Performance**: < 500ms average query time
- **User Adoption**: Daily active users
- **Access Request Time**: Reduction in time to get access
- **Data Discovery**: Time to find relevant datasets

## Next Steps

1. Review and approve architecture
2. Provision infrastructure
3. Begin Phase 1 development
4. Set up development environment
5. Create detailed technical specifications
