"""
Metadata Orchestration Pipeline
Coordinates extraction from all sources and loads into central repository
"""

import logging
from datetime import datetime
from typing import List, Dict, Any
import json
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
import os

# Import extractors
from databricks_extractor import DatabricksMetadataExtractor
from hive_extractor import HiveMetadataExtractor
from db2_extractor import DB2MetadataExtractor
from erwin_extractor import ErwinMetadataExtractor

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class MetadataOrchestrator:
    """Orchestrates metadata extraction and loading"""
    
    def __init__(self, db_url: str, config: Dict[str, Any]):
        """
        Initialize orchestrator
        
        Args:
            db_url: Database connection string for metadata repository
            config: Configuration dict with connection info for all sources
        """
        self.db_url = db_url
        self.config = config
        self.engine = create_engine(db_url)
        self.Session = sessionmaker(bind=self.engine)
    
    def extract_databricks(self) -> List[Dict[str, Any]]:
        """Extract metadata from Databricks"""
        logger.info("Starting Databricks extraction...")
        
        try:
            extractor = DatabricksMetadataExtractor(
                workspace_url=self.config['databricks']['workspace_url'],
                token=self.config['databricks']['token'],
                use_unity_catalog=self.config['databricks'].get('use_unity_catalog', True)
            )
            
            metadata = extractor.extract_all_metadata()
            logger.info(f"Extracted {len(metadata)} tables from Databricks")
            return metadata
        
        except Exception as e:
            logger.error(f"Databricks extraction failed: {e}")
            return []
    
    def extract_hive(self) -> List[Dict[str, Any]]:
        """Extract metadata from Hive"""
        logger.info("Starting Hive extraction...")
        
        try:
            extractor = HiveMetadataExtractor(
                host=self.config['hive']['host'],
                port=self.config['hive']['port'],
                username=self.config['hive']['username'],
                password=self.config['hive']['password'],
                auth=self.config['hive'].get('auth', 'NONE')
            )
            
            metadata = extractor.extract_all_metadata()
            extractor.close()
            logger.info(f"Extracted {len(metadata)} tables from Hive")
            return metadata
        
        except Exception as e:
            logger.error(f"Hive extraction failed: {e}")
            return []
    
    def extract_db2(self) -> List[Dict[str, Any]]:
        """Extract metadata from DB2"""
        logger.info("Starting DB2 extraction...")
        
        try:
            extractor = DB2MetadataExtractor(
                database=self.config['db2']['database'],
                hostname=self.config['db2']['hostname'],
                port=self.config['db2']['port'],
                uid=self.config['db2']['username'],
                pwd=self.config['db2']['password']
            )
            
            metadata = extractor.extract_all_metadata()
            extractor.close()
            logger.info(f"Extracted {len(metadata)} tables from DB2")
            return metadata
        
        except Exception as e:
            logger.error(f"DB2 extraction failed: {e}")
            return []
    
    def extract_erwin(self) -> Dict[str, Any]:
        """Extract metadata from Erwin"""
        logger.info("Starting Erwin extraction...")
        
        try:
            extractor = ErwinMetadataExtractor(
                xml_file_path=self.config['erwin']['xml_file_path']
            )
            
            metadata = extractor.extract_all_metadata()
            logger.info(f"Extracted {len(metadata['physical_tables'])} tables from Erwin")
            return metadata
        
        except Exception as e:
            logger.error(f"Erwin extraction failed: {e}")
            return {'physical_tables': [], 'logical_model': {'entities': []}}
    
    def load_table_metadata(self, metadata: Dict[str, Any], source_id: int):
        """Load table metadata into repository"""
        session = self.Session()
        
        try:
            # Get or create database
            db_query = text("""
                INSERT INTO databases (source_id, database_name, catalog_name, owner)
                VALUES (:source_id, :database_name, :catalog_name, :owner)
                ON CONFLICT (source_id, catalog_name, database_name) 
                DO UPDATE SET owner = EXCLUDED.owner, last_modified = CURRENT_TIMESTAMP
                RETURNING database_id
            """)
            
            db_result = session.execute(db_query, {
                'source_id': source_id,
                'database_name': metadata.get('database_name') or metadata.get('schema_name', 'default'),
                'catalog_name': metadata.get('catalog_name'),
                'owner': metadata.get('owner')
            })
            database_id = db_result.fetchone()[0]
            
            # Get or create schema
            schema_query = text("""
                INSERT INTO schemas (database_id, schema_name, owner)
                VALUES (:database_id, :schema_name, :owner)
                ON CONFLICT (database_id, schema_name)
                DO UPDATE SET owner = EXCLUDED.owner, last_modified = CURRENT_TIMESTAMP
                RETURNING schema_id
            """)
            
            schema_result = session.execute(schema_query, {
                'database_id': database_id,
                'schema_name': metadata.get('schema_name', 'default'),
                'owner': metadata.get('owner')
            })
            schema_id = schema_result.fetchone()[0]
            
            # Insert or update table
            table_query = text("""
                INSERT INTO tables (
                    schema_id, table_name, table_type, description, owner,
                    row_count, size_bytes, storage_location, data_format,
                    is_partitioned, partition_columns, tags, properties,
                    created_at, last_modified
                )
                VALUES (
                    :schema_id, :table_name, :table_type, :description, :owner,
                    :row_count, :size_bytes, :storage_location, :data_format,
                    :is_partitioned, :partition_columns, :tags, :properties,
                    :created_at, :last_modified
                )
                ON CONFLICT (schema_id, table_name)
                DO UPDATE SET
                    table_type = EXCLUDED.table_type,
                    description = EXCLUDED.description,
                    owner = EXCLUDED.owner,
                    row_count = EXCLUDED.row_count,
                    size_bytes = EXCLUDED.size_bytes,
                    storage_location = EXCLUDED.storage_location,
                    data_format = EXCLUDED.data_format,
                    is_partitioned = EXCLUDED.is_partitioned,
                    partition_columns = EXCLUDED.partition_columns,
                    tags = EXCLUDED.tags,
                    properties = EXCLUDED.properties,
                    last_modified = EXCLUDED.last_modified,
                    extraction_time = CURRENT_TIMESTAMP
                RETURNING table_id
            """)
            
            table_result = session.execute(table_query, {
                'schema_id': schema_id,
                'table_name': metadata['table_name'],
                'table_type': metadata.get('table_type', 'TABLE'),
                'description': metadata.get('description') or metadata.get('comment'),
                'owner': metadata.get('owner'),
                'row_count': metadata.get('row_count') or metadata.get('num_rows'),
                'size_bytes': metadata.get('size_bytes') or metadata.get('total_size'),
                'storage_location': metadata.get('storage_location') or metadata.get('location'),
                'data_format': metadata.get('data_format') or metadata.get('data_source_format'),
                'is_partitioned': len(metadata.get('partition_columns', [])) > 0,
                'partition_columns': metadata.get('partition_columns', []),
                'tags': metadata.get('tags', []),
                'properties': json.dumps(metadata.get('properties', {})),
                'created_at': metadata.get('created_at') or metadata.get('created_time'),
                'last_modified': metadata.get('updated_at') or metadata.get('last_modified')
            })
            table_id = table_result.fetchone()[0]
            
            # Delete existing columns for this table (for full refresh)
            session.execute(
                text("DELETE FROM columns WHERE table_id = :table_id"),
                {'table_id': table_id}
            )
            
            # Insert columns
            for column in metadata.get('columns', []):
                column_query = text("""
                    INSERT INTO columns (
                        table_id, column_name, ordinal_position, data_type,
                        type_text, max_length, numeric_precision, numeric_scale,
                        is_nullable, default_value, description, is_primary_key,
                        is_foreign_key, is_partition_column, is_identity, tags
                    )
                    VALUES (
                        :table_id, :column_name, :ordinal_position, :data_type,
                        :type_text, :max_length, :numeric_precision, :numeric_scale,
                        :is_nullable, :default_value, :description, :is_primary_key,
                        :is_foreign_key, :is_partition_column, :is_identity, :tags
                    )
                """)
                
                session.execute(column_query, {
                    'table_id': table_id,
                    'column_name': column['column_name'],
                    'ordinal_position': column.get('ordinal_position', 0),
                    'data_type': column.get('data_type') or column.get('base_type', 'UNKNOWN'),
                    'type_text': column.get('type_text'),
                    'max_length': column.get('length'),
                    'numeric_precision': column.get('precision'),
                    'numeric_scale': column.get('scale'),
                    'is_nullable': column.get('is_nullable', True),
                    'default_value': column.get('default_value'),
                    'description': column.get('description') or column.get('comment'),
                    'is_primary_key': column.get('is_primary_key', False),
                    'is_foreign_key': column.get('is_foreign_key', False),
                    'is_partition_column': column.get('is_partition_column', False),
                    'is_identity': column.get('is_identity', False),
                    'tags': column.get('tags', [])
                })
            
            session.commit()
            logger.info(f"Loaded table {metadata['table_name']} with {len(metadata.get('columns', []))} columns")
            
        except Exception as e:
            session.rollback()
            logger.error(f"Failed to load table {metadata.get('table_name')}: {e}")
            raise
        finally:
            session.close()
    
    def run_full_extraction(self):
        """Run full metadata extraction from all sources"""
        logger.info("=" * 80)
        logger.info("Starting full metadata extraction pipeline")
        logger.info("=" * 80)
        
        # Get source IDs
        session = self.Session()
        sources = session.execute(
            text("SELECT source_id, source_name, source_type FROM data_sources WHERE is_active = true")
        ).fetchall()
        
        source_map = {row.source_type: row.source_id for row in sources}
        session.close()
        
        total_tables = 0
        
        # Extract from Databricks
        if 'databricks' in self.config and 'databricks' in source_map:
            databricks_metadata = self.extract_databricks()
            for table_meta in databricks_metadata:
                try:
                    self.load_table_metadata(table_meta, source_map['databricks'])
                    total_tables += 1
                except Exception as e:
                    logger.error(f"Failed to load Databricks table: {e}")
        
        # Extract from Hive
        if 'hive' in self.config and 'hive' in source_map:
            hive_metadata = self.extract_hive()
            for table_meta in hive_metadata:
                try:
                    self.load_table_metadata(table_meta, source_map['hive'])
                    total_tables += 1
                except Exception as e:
                    logger.error(f"Failed to load Hive table: {e}")
        
        # Extract from DB2
        if 'db2' in self.config and 'db2' in source_map:
            db2_metadata = self.extract_db2()
            for table_meta in db2_metadata:
                try:
                    self.load_table_metadata(table_meta, source_map['db2'])
                    total_tables += 1
                except Exception as e:
                    logger.error(f"Failed to load DB2 table: {e}")
        
        # Extract from Erwin
        if 'erwin' in self.config and 'erwin' in source_map:
            erwin_metadata = self.extract_erwin()
            for table_meta in erwin_metadata.get('physical_tables', []):
                try:
                    self.load_table_metadata(table_meta, source_map['erwin'])
                    total_tables += 1
                except Exception as e:
                    logger.error(f"Failed to load Erwin table: {e}")
        
        logger.info("=" * 80)
        logger.info(f"Extraction complete! Loaded {total_tables} tables total")
        logger.info("=" * 80)


# Example configuration
def get_config():
    """Load configuration from environment or config file"""
    return {
        'databricks': {
            'workspace_url': os.getenv('DATABRICKS_WORKSPACE_URL'),
            'token': os.getenv('DATABRICKS_TOKEN'),
            'use_unity_catalog': True
        },
        'hive': {
            'host': os.getenv('HIVE_HOST'),
            'port': int(os.getenv('HIVE_PORT', 10000)),
            'username': os.getenv('HIVE_USERNAME'),
            'password': os.getenv('HIVE_PASSWORD'),
            'auth': 'LDAP'
        },
        'db2': {
            'database': os.getenv('DB2_DATABASE'),
            'hostname': os.getenv('DB2_HOST'),
            'port': int(os.getenv('DB2_PORT', 50000)),
            'username': os.getenv('DB2_USERNAME'),
            'password': os.getenv('DB2_PASSWORD')
        },
        'erwin': {
            'xml_file_path': os.getenv('ERWIN_XML_PATH', '/path/to/erwin_export.xml')
        }
    }


if __name__ == "__main__":
    # Load configuration
    config = get_config()
    
    # Database connection for metadata repository
    DB_URL = os.getenv(
        'METADATA_DB_URL',
        'postgresql://user:password@localhost:5432/metadata_catalog'
    )
    
    # Create orchestrator
    orchestrator = MetadataOrchestrator(DB_URL, config)
    
    # Run extraction
    orchestrator.run_full_extraction()
