"""
Load Metadata to Databricks Delta Tables
Loads metadata from all sources into Databricks Delta tables for serving
"""

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.sql import StatementState
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import json
import logging
from datetime import datetime
from typing import List, Dict, Any
import os

# Import extractors
from databricks_extractor import DatabricksMetadataExtractor
from hive_extractor import HiveMetadataExtractor
from db2_extractor import DB2MetadataExtractor
from erwin_extractor import ErwinMetadataExtractor

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class MetadataToDeltaLoader:
    """Load metadata from all sources into Databricks Delta tables"""
    
    def __init__(self, 
                 catalog_name: str = "metadata_catalog",
                 schema_name: str = "technical_metadata",
                 workspace_url: str = None,
                 token: str = None):
        """
        Initialize Delta loader
        
        Args:
            catalog_name: Unity Catalog name
            schema_name: Schema name for metadata tables
            workspace_url: Databricks workspace URL
            token: Databricks access token
        """
        self.catalog_name = catalog_name
        self.schema_name = schema_name
        self.workspace_url = workspace_url or os.getenv('DATABRICKS_WORKSPACE_URL')
        self.token = token or os.getenv('DATABRICKS_TOKEN')
        
        # Initialize Spark session
        self.spark = SparkSession.builder \
            .appName("Metadata to Delta Loader") \
            .getOrCreate()
        
        # Initialize Databricks client
        self.workspace_client = WorkspaceClient(
            host=self.workspace_url,
            token=self.token
        )
    
    def create_catalog_and_schema(self):
        """Create catalog and schema if they don't exist"""
        logger.info(f"Creating catalog {self.catalog_name} and schema {self.schema_name}")
        
        # Create catalog
        self.spark.sql(f"""
            CREATE CATALOG IF NOT EXISTS {self.catalog_name}
            COMMENT 'Centralized technical metadata repository'
        """)
        
        # Create schema
        self.spark.sql(f"""
            CREATE SCHEMA IF NOT EXISTS {self.catalog_name}.{self.schema_name}
            COMMENT 'Technical metadata from all data sources'
        """)
        
        # Set current catalog and schema
        self.spark.sql(f"USE CATALOG {self.catalog_name}")
        self.spark.sql(f"USE SCHEMA {self.schema_name}")
    
    def create_delta_tables(self):
        """Create Delta tables for metadata storage"""
        logger.info("Creating Delta tables...")
        
        # Data Sources table
        self.spark.sql(f"""
            CREATE TABLE IF NOT EXISTS data_sources (
                source_id STRING,
                source_name STRING,
                source_type STRING,
                connection_info STRING,
                is_active BOOLEAN,
                last_sync_time TIMESTAMP,
                created_at TIMESTAMP,
                updated_at TIMESTAMP
            )
            USING DELTA
            COMMENT 'Data source registry'
            TBLPROPERTIES (
                'delta.enableChangeDataFeed' = 'true',
                'delta.minReaderVersion' = '1',
                'delta.minWriterVersion' = '2'
            )
        """)
        
        # Tables metadata
        self.spark.sql(f"""
            CREATE TABLE IF NOT EXISTS tables_metadata (
                table_id STRING,
                source_system STRING,
                catalog_name STRING,
                database_name STRING,
                schema_name STRING,
                table_name STRING,
                full_table_name STRING,
                table_type STRING,
                description STRING,
                owner STRING,
                created_at TIMESTAMP,
                last_modified TIMESTAMP,
                row_count BIGINT,
                size_bytes BIGINT,
                storage_location STRING,
                data_format STRING,
                is_partitioned BOOLEAN,
                partition_columns ARRAY<STRING>,
                tags ARRAY<STRING>,
                properties MAP<STRING, STRING>,
                extraction_time TIMESTAMP
            )
            USING DELTA
            PARTITIONED BY (source_system)
            COMMENT 'Table metadata from all sources'
            TBLPROPERTIES (
                'delta.enableChangeDataFeed' = 'true',
                'delta.autoOptimize.optimizeWrite' = 'true',
                'delta.autoOptimize.autoCompact' = 'true'
            )
        """)
        
        # Columns metadata
        self.spark.sql(f"""
            CREATE TABLE IF NOT EXISTS columns_metadata (
                column_id STRING,
                table_id STRING,
                source_system STRING,
                full_table_name STRING,
                column_name STRING,
                ordinal_position INT,
                data_type STRING,
                type_text STRING,
                max_length INT,
                numeric_precision INT,
                numeric_scale INT,
                is_nullable BOOLEAN,
                default_value STRING,
                description STRING,
                is_primary_key BOOLEAN,
                is_foreign_key BOOLEAN,
                is_partition_column BOOLEAN,
                is_identity BOOLEAN,
                is_pii BOOLEAN,
                data_classification STRING,
                tags ARRAY<STRING>,
                extraction_time TIMESTAMP
            )
            USING DELTA
            PARTITIONED BY (source_system)
            COMMENT 'Column metadata from all sources'
            TBLPROPERTIES (
                'delta.enableChangeDataFeed' = 'true',
                'delta.autoOptimize.optimizeWrite' = 'true'
            )
        """)
        
        # AD Groups
        self.spark.sql(f"""
            CREATE TABLE IF NOT EXISTS ad_groups (
                ad_group_id STRING,
                group_name STRING,
                group_dn STRING,
                group_description STRING,
                group_type STRING,
                group_scope STRING,
                owner STRING,
                contact_email STRING,
                request_process STRING,
                approval_workflow_url STRING,
                sla_days INT,
                is_active BOOLEAN,
                last_synced TIMESTAMP,
                created_at TIMESTAMP
            )
            USING DELTA
            COMMENT 'Active Directory security groups'
            TBLPROPERTIES (
                'delta.enableChangeDataFeed' = 'true'
            )
        """)
        
        # Resource Access Mapping
        self.spark.sql(f"""
            CREATE TABLE IF NOT EXISTS resource_access_mapping (
                mapping_id STRING,
                resource_type STRING,
                resource_id STRING,
                table_id STRING,
                ad_group_id STRING,
                access_level STRING,
                is_inherited BOOLEAN,
                effective_from DATE,
                effective_to DATE,
                notes STRING,
                created_at TIMESTAMP,
                updated_at TIMESTAMP
            )
            USING DELTA
            PARTITIONED BY (resource_type)
            COMMENT 'Resource to AD group access mappings'
            TBLPROPERTIES (
                'delta.enableChangeDataFeed' = 'true'
            )
        """)
        
        # Business Terms
        self.spark.sql(f"""
            CREATE TABLE IF NOT EXISTS business_terms (
                term_id STRING,
                term_name STRING,
                definition STRING,
                synonyms ARRAY<STRING>,
                related_terms ARRAY<STRING>,
                category STRING,
                data_steward STRING,
                status STRING,
                approved_by STRING,
                approved_date DATE,
                created_at TIMESTAMP,
                updated_at TIMESTAMP
            )
            USING DELTA
            COMMENT 'Business glossary terms'
            TBLPROPERTIES (
                'delta.enableChangeDataFeed' = 'true'
            )
        """)
        
        # Search History
        self.spark.sql(f"""
            CREATE TABLE IF NOT EXISTS search_history (
                search_id STRING,
                user_id STRING,
                search_query STRING,
                filters MAP<STRING, STRING>,
                results_count INT,
                clicked_table_id STRING,
                search_timestamp TIMESTAMP
            )
            USING DELTA
            PARTITIONED BY (DATE(search_timestamp))
            COMMENT 'User search history for analytics'
            TBLPROPERTIES (
                'delta.enableChangeDataFeed' = 'true',
                'delta.logRetentionDuration' = 'interval 90 days'
            )
        """)
        
        # Access Requests
        self.spark.sql(f"""
            CREATE TABLE IF NOT EXISTS access_requests (
                request_id STRING,
                user_id STRING,
                user_email STRING,
                table_id STRING,
                ad_group_id STRING,
                access_level STRING,
                business_justification STRING,
                request_status STRING,
                requested_at TIMESTAMP,
                approved_by STRING,
                approved_at TIMESTAMP,
                rejection_reason STRING,
                ticket_number STRING,
                ticket_url STRING
            )
            USING DELTA
            PARTITIONED BY (request_status)
            COMMENT 'Access request tracking'
            TBLPROPERTIES (
                'delta.enableChangeDataFeed' = 'true'
            )
        """)
        
        logger.info("Delta tables created successfully")
    
    def load_tables_metadata(self, metadata_list: List[Dict[str, Any]]):
        """Load table metadata into Delta table"""
        if not metadata_list:
            logger.warning("No metadata to load")
            return
        
        logger.info(f"Loading {len(metadata_list)} tables into Delta...")
        
        # Define schema
        schema = StructType([
            StructField("table_id", StringType(), True),
            StructField("source_system", StringType(), True),
            StructField("catalog_name", StringType(), True),
            StructField("database_name", StringType(), True),
            StructField("schema_name", StringType(), True),
            StructField("table_name", StringType(), True),
            StructField("full_table_name", StringType(), True),
            StructField("table_type", StringType(), True),
            StructField("description", StringType(), True),
            StructField("owner", StringType(), True),
            StructField("created_at", TimestampType(), True),
            StructField("last_modified", TimestampType(), True),
            StructField("row_count", LongType(), True),
            StructField("size_bytes", LongType(), True),
            StructField("storage_location", StringType(), True),
            StructField("data_format", StringType(), True),
            StructField("is_partitioned", BooleanType(), True),
            StructField("partition_columns", ArrayType(StringType()), True),
            StructField("tags", ArrayType(StringType()), True),
            StructField("properties", MapType(StringType(), StringType()), True),
            StructField("extraction_time", TimestampType(), True)
        ])
        
        # Transform metadata for DataFrame
        records = []
        for meta in metadata_list:
            # Generate table_id if not present
            table_id = meta.get('table_id') or f"{meta['source_system']}_{meta.get('database_name', '')}_{meta.get('schema_name', '')}_{meta['table_name']}"
            
            record = {
                'table_id': table_id,
                'source_system': meta['source_system'],
                'catalog_name': meta.get('catalog_name'),
                'database_name': meta.get('database_name') or meta.get('schema_name'),
                'schema_name': meta.get('schema_name', 'default'),
                'table_name': meta['table_name'],
                'full_table_name': meta.get('full_table_name'),
                'table_type': meta.get('table_type', 'TABLE'),
                'description': meta.get('description') or meta.get('comment'),
                'owner': meta.get('owner'),
                'created_at': meta.get('created_at') or meta.get('created_time'),
                'last_modified': meta.get('updated_at') or meta.get('last_modified'),
                'row_count': meta.get('row_count') or meta.get('num_rows'),
                'size_bytes': meta.get('size_bytes') or meta.get('total_size'),
                'storage_location': meta.get('storage_location') or meta.get('location'),
                'data_format': meta.get('data_format') or meta.get('data_source_format'),
                'is_partitioned': len(meta.get('partition_columns', [])) > 0,
                'partition_columns': meta.get('partition_columns', []),
                'tags': meta.get('tags', []),
                'properties': meta.get('properties', {}),
                'extraction_time': datetime.utcnow()
            }
            records.append(record)
        
        # Create DataFrame
        df = self.spark.createDataFrame(records, schema=schema)
        
        # Write to Delta with merge
        df.createOrReplaceTempView("source_tables")
        
        self.spark.sql(f"""
            MERGE INTO tables_metadata AS target
            USING source_tables AS source
            ON target.table_id = source.table_id
            WHEN MATCHED THEN UPDATE SET *
            WHEN NOT MATCHED THEN INSERT *
        """)
        
        logger.info(f"Successfully loaded {len(records)} tables")
    
    def load_columns_metadata(self, metadata_list: List[Dict[str, Any]]):
        """Load column metadata into Delta table"""
        if not metadata_list:
            return
        
        logger.info("Loading column metadata into Delta...")
        
        # Flatten columns from all tables
        all_columns = []
        for table_meta in metadata_list:
            table_id = table_meta.get('table_id') or f"{table_meta['source_system']}_{table_meta.get('database_name', '')}_{table_meta.get('schema_name', '')}_{table_meta['table_name']}"
            
            for col in table_meta.get('columns', []):
                column_record = {
                    'column_id': f"{table_id}_{col['column_name']}",
                    'table_id': table_id,
                    'source_system': table_meta['source_system'],
                    'full_table_name': table_meta.get('full_table_name'),
                    'column_name': col['column_name'],
                    'ordinal_position': col.get('ordinal_position', 0),
                    'data_type': col.get('data_type') or col.get('base_type', 'UNKNOWN'),
                    'type_text': col.get('type_text'),
                    'max_length': col.get('length'),
                    'numeric_precision': col.get('precision'),
                    'numeric_scale': col.get('scale'),
                    'is_nullable': col.get('is_nullable', True),
                    'default_value': col.get('default_value'),
                    'description': col.get('description') or col.get('comment'),
                    'is_primary_key': col.get('is_primary_key', False),
                    'is_foreign_key': col.get('is_foreign_key', False),
                    'is_partition_column': col.get('is_partition_column', False),
                    'is_identity': col.get('is_identity', False),
                    'is_pii': col.get('is_pii', False),
                    'data_classification': col.get('data_classification'),
                    'tags': col.get('tags', []),
                    'extraction_time': datetime.utcnow()
                }
                all_columns.append(column_record)
        
        if not all_columns:
            return
        
        # Create DataFrame
        df = self.spark.createDataFrame(all_columns)
        
        # Write to Delta with merge
        df.createOrReplaceTempView("source_columns")
        
        self.spark.sql(f"""
            MERGE INTO columns_metadata AS target
            USING source_columns AS source
            ON target.column_id = source.column_id
            WHEN MATCHED THEN UPDATE SET *
            WHEN NOT MATCHED THEN INSERT *
        """)
        
        logger.info(f"Successfully loaded {len(all_columns)} columns")
    
    def create_search_views(self):
        """Create optimized views for searching"""
        logger.info("Creating search views...")
        
        # Unified metadata view
        self.spark.sql(f"""
            CREATE OR REPLACE VIEW v_searchable_metadata AS
            SELECT 
                t.table_id,
                t.source_system,
                t.catalog_name,
                t.database_name,
                t.schema_name,
                t.table_name,
                t.full_table_name,
                t.table_type,
                t.description,
                t.owner,
                t.row_count,
                t.size_bytes,
                t.created_at,
                t.last_modified,
                t.tags,
                COLLECT_LIST(DISTINCT c.column_name) as column_names,
                COLLECT_LIST(DISTINCT c.data_type) as data_types,
                MAX(CASE WHEN c.is_pii = true THEN 1 ELSE 0 END) as has_pii,
                COUNT(DISTINCT c.column_id) as column_count,
                COLLECT_LIST(DISTINCT ram.ad_group_id) FILTER (WHERE ram.access_level = 'READ') as read_groups,
                COLLECT_LIST(DISTINCT ram.ad_group_id) FILTER (WHERE ram.access_level = 'WRITE') as write_groups
            FROM tables_metadata t
            LEFT JOIN columns_metadata c ON t.table_id = c.table_id
            LEFT JOIN resource_access_mapping ram ON ram.table_id = t.table_id
            GROUP BY t.table_id, t.source_system, t.catalog_name, t.database_name, 
                     t.schema_name, t.table_name, t.full_table_name, t.table_type,
                     t.description, t.owner, t.row_count, t.size_bytes,
                     t.created_at, t.last_modified, t.tags
        """)
        
        # Column search view
        self.spark.sql(f"""
            CREATE OR REPLACE VIEW v_column_search AS
            SELECT 
                c.*,
                t.full_table_name as table_full_name,
                t.source_system,
                t.database_name,
                t.schema_name,
                t.owner as table_owner
            FROM columns_metadata c
            JOIN tables_metadata t ON c.table_id = t.table_id
        """)
        
        # Popular tables view
        self.spark.sql(f"""
            CREATE OR REPLACE VIEW v_popular_tables AS
            SELECT 
                t.*,
                COUNT(DISTINCT sh.search_id) as search_count,
                COUNT(DISTINCT ar.request_id) as access_request_count,
                MAX(sh.search_timestamp) as last_searched
            FROM tables_metadata t
            LEFT JOIN search_history sh ON t.table_id = sh.clicked_table_id
            LEFT JOIN access_requests ar ON t.table_id = ar.table_id
            GROUP BY t.table_id, t.source_system, t.catalog_name, t.database_name,
                     t.schema_name, t.table_name, t.full_table_name, t.table_type,
                     t.description, t.owner, t.row_count, t.size_bytes, t.storage_location,
                     t.data_format, t.is_partitioned, t.partition_columns, t.tags,
                     t.properties, t.created_at, t.last_modified, t.extraction_time
            HAVING search_count > 0 OR access_request_count > 0
            ORDER BY search_count DESC, access_request_count DESC
        """)
        
        logger.info("Search views created successfully")
    
    def optimize_tables(self):
        """Optimize Delta tables for better query performance"""
        logger.info("Optimizing Delta tables...")
        
        tables = ['tables_metadata', 'columns_metadata', 'ad_groups', 
                  'resource_access_mapping', 'business_terms']
        
        for table in tables:
            logger.info(f"Optimizing {table}...")
            self.spark.sql(f"OPTIMIZE {table}")
            
            # Create Z-order for common query patterns
            if table == 'tables_metadata':
                self.spark.sql(f"OPTIMIZE {table} ZORDER BY (source_system, database_name, schema_name)")
            elif table == 'columns_metadata':
                self.spark.sql(f"OPTIMIZE {table} ZORDER BY (source_system, table_id)")
        
        logger.info("Optimization complete")
    
    def run_full_load(self, config: Dict[str, Any]):
        """Run full metadata load from all sources"""
        logger.info("="*80)
        logger.info("Starting full metadata load to Databricks Delta")
        logger.info("="*80)
        
        # Create catalog and schema
        self.create_catalog_and_schema()
        
        # Create Delta tables
        self.create_delta_tables()
        
        all_metadata = []
        
        # Extract from Databricks
        if 'databricks' in config:
            try:
                logger.info("Extracting from Databricks...")
                extractor = DatabricksMetadataExtractor(
                    workspace_url=config['databricks']['workspace_url'],
                    token=config['databricks']['token'],
                    use_unity_catalog=config['databricks'].get('use_unity_catalog', True)
                )
                databricks_meta = extractor.extract_all_metadata()
                all_metadata.extend(databricks_meta)
            except Exception as e:
                logger.error(f"Databricks extraction failed: {e}")
        
        # Extract from Hive
        if 'hive' in config:
            try:
                logger.info("Extracting from Hive...")
                extractor = HiveMetadataExtractor(
                    host=config['hive']['host'],
                    port=config['hive']['port'],
                    username=config['hive']['username'],
                    password=config['hive']['password'],
                    auth=config['hive'].get('auth', 'NONE')
                )
                hive_meta = extractor.extract_all_metadata()
                extractor.close()
                all_metadata.extend(hive_meta)
            except Exception as e:
                logger.error(f"Hive extraction failed: {e}")
        
        # Extract from DB2
        if 'db2' in config:
            try:
                logger.info("Extracting from DB2...")
                extractor = DB2MetadataExtractor(
                    database=config['db2']['database'],
                    hostname=config['db2']['hostname'],
                    port=config['db2']['port'],
                    uid=config['db2']['username'],
                    pwd=config['db2']['password']
                )
                db2_meta = extractor.extract_all_metadata()
                extractor.close()
                all_metadata.extend(db2_meta)
            except Exception as e:
                logger.error(f"DB2 extraction failed: {e}")
        
        # Extract from Erwin
        if 'erwin' in config:
            try:
                logger.info("Extracting from Erwin...")
                extractor = ErwinMetadataExtractor(
                    xml_file_path=config['erwin']['xml_file_path']
                )
                erwin_meta = extractor.extract_all_metadata()
                all_metadata.extend(erwin_meta.get('physical_tables', []))
            except Exception as e:
                logger.error(f"Erwin extraction failed: {e}")
        
        # Load into Delta tables
        if all_metadata:
            self.load_tables_metadata(all_metadata)
            self.load_columns_metadata(all_metadata)
        
        # Create search views
        self.create_search_views()
        
        # Optimize tables
        self.optimize_tables()
        
        logger.info("="*80)
        logger.info(f"Load complete! Loaded {len(all_metadata)} tables into Delta")
        logger.info(f"Access at: {self.catalog_name}.{self.schema_name}")
        logger.info("="*80)


def get_config():
    """Load configuration from environment"""
    return {
        'databricks': {
            'workspace_url': os.getenv('DATABRICKS_WORKSPACE_URL'),
            'token': os.getenv('DATABRICKS_TOKEN'),
            'use_unity_catalog': True
        },
        'hive': {
            'host': os.getenv('HIVE_HOST'),
            'port': int(os.getenv('HIVE_PORT', 10000)),
            'username': os.getenv('HIVE_USERNAME'),
            'password': os.getenv('HIVE_PASSWORD'),
            'auth': 'LDAP'
        },
        'db2': {
            'database': os.getenv('DB2_DATABASE'),
            'hostname': os.getenv('DB2_HOST'),
            'port': int(os.getenv('DB2_PORT', 50000)),
            'username': os.getenv('DB2_USERNAME'),
            'password': os.getenv('DB2_PASSWORD')
        },
        'erwin': {
            'xml_file_path': os.getenv('ERWIN_XML_PATH', '/dbfs/mnt/metadata/erwin_export.xml')
        }
    }


if __name__ == "__main__":
    # Configuration
    config = get_config()
    
    # Create loader
    loader = MetadataToDeltaLoader(
        catalog_name="metadata_catalog",
        schema_name="technical_metadata"
    )
    
    # Run full load
    loader.run_full_load(config)
