"""
Databricks Delta-based Metadata Search API
Serves metadata directly from Databricks Delta tables using Databricks SQL
"""

from fastapi import FastAPI, Query, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from databricks import sql
import os
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration
DATABRICKS_SERVER_HOSTNAME = os.getenv('DATABRICKS_SERVER_HOSTNAME')
DATABRICKS_HTTP_PATH = os.getenv('DATABRICKS_HTTP_PATH')
DATABRICKS_TOKEN = os.getenv('DATABRICKS_TOKEN')
METADATA_CATALOG = os.getenv('METADATA_CATALOG', 'metadata_catalog')
METADATA_SCHEMA = os.getenv('METADATA_SCHEMA', 'technical_metadata')

# FastAPI app
app = FastAPI(
    title="Databricks Metadata Search API",
    description="Search and discover data assets from Databricks Delta tables",
    version="2.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic models
class ADGroupInfo(BaseModel):
    group_name: str
    group_description: Optional[str]
    access_level: str
    request_process: Optional[str]
    approval_workflow_url: Optional[str]
    sla_days: Optional[int]
    contact_email: Optional[str]

class ColumnInfo(BaseModel):
    column_name: str
    ordinal_position: int
    data_type: str
    is_nullable: bool
    is_primary_key: bool
    is_pii: bool
    description: Optional[str]

class TableSearchResult(BaseModel):
    table_id: str
    source_system: str
    database_name: str
    schema_name: str
    table_name: str
    full_table_name: str
    table_type: str
    description: Optional[str]
    owner: Optional[str]
    row_count: Optional[int]
    size_bytes: Optional[int]
    created_at: Optional[datetime]
    last_modified: Optional[datetime]
    tags: List[str] = []
    column_count: int = 0
    has_pii: bool = False

class TableDetail(TableSearchResult):
    storage_location: Optional[str]
    data_format: Optional[str]
    is_partitioned: bool
    partition_columns: List[str] = []
    columns: List[ColumnInfo] = []
    access_groups: List[ADGroupInfo] = []

class SearchStats(BaseModel):
    total_tables: int
    total_columns: int
    sources: Dict[str, int]
    last_updated: Optional[datetime]

# Database connection
def get_db_connection():
    """Create Databricks SQL connection"""
    try:
        connection = sql.connect(
            server_hostname=DATABRICKS_SERVER_HOSTNAME,
            http_path=DATABRICKS_HTTP_PATH,
            access_token=DATABRICKS_TOKEN
        )
        return connection
    except Exception as e:
        logger.error(f"Failed to connect to Databricks: {e}")
        raise HTTPException(status_code=500, detail="Database connection failed")

def execute_query(query: str, params: Dict = None) -> List[Dict]:
    """Execute SQL query and return results"""
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(query, params or {})
        
        # Get column names
        columns = [desc[0] for desc in cursor.description]
        
        # Fetch results
        results = []
        for row in cursor.fetchall():
            results.append(dict(zip(columns, row)))
        
        return results
    finally:
        conn.close()

# API Endpoints

@app.get("/")
def root():
    return {
        "service": "Databricks Metadata Search API",
        "version": "2.0.0",
        "storage": "Databricks Delta Tables",
        "catalog": METADATA_CATALOG,
        "schema": METADATA_SCHEMA,
        "endpoints": {
            "search": "/api/v1/search",
            "table_detail": "/api/v1/tables/{table_id}",
            "stats": "/api/v1/stats",
            "popular": "/api/v1/popular-tables"
        }
    }

@app.get("/api/v1/search", response_model=List[TableSearchResult])
def search_tables(
    q: str = Query(..., description="Search query"),
    source_system: Optional[str] = Query(None, description="Filter by source type"),
    database: Optional[str] = Query(None, description="Filter by database"),
    schema: Optional[str] = Query(None, description="Filter by schema"),
    has_pii: Optional[bool] = Query(None, description="Filter by PII presence"),
    limit: int = Query(50, ge=1, le=500, description="Max results"),
    offset: int = Query(0, ge=0, description="Offset for pagination")
):
    """
    Search for tables using keyword search across Delta tables
    """
    
    # Build search query
    query = f"""
    SELECT DISTINCT
        t.table_id,
        t.source_system,
        t.database_name,
        t.schema_name,
        t.table_name,
        t.full_table_name,
        t.table_type,
        t.description,
        t.owner,
        t.row_count,
        t.size_bytes,
        t.created_at,
        t.last_modified,
        t.tags,
        COUNT(DISTINCT c.column_id) as column_count,
        MAX(CASE WHEN c.is_pii = true THEN 1 ELSE 0 END) as has_pii
    FROM {METADATA_CATALOG}.{METADATA_SCHEMA}.tables_metadata t
    LEFT JOIN {METADATA_CATALOG}.{METADATA_SCHEMA}.columns_metadata c ON t.table_id = c.table_id
    WHERE (
        LOWER(t.table_name) LIKE LOWER('%{q}%')
        OR LOWER(t.description) LIKE LOWER('%{q}%')
        OR LOWER(t.database_name) LIKE LOWER('%{q}%')
        OR LOWER(t.schema_name) LIKE LOWER('%{q}%')
        OR EXISTS (
            SELECT 1 FROM {METADATA_CATALOG}.{METADATA_SCHEMA}.columns_metadata c2
            WHERE c2.table_id = t.table_id 
            AND (LOWER(c2.column_name) LIKE LOWER('%{q}%')
                 OR LOWER(c2.description) LIKE LOWER('%{q}%'))
        )
    )
    """
    
    # Add filters
    if source_system:
        query += f" AND t.source_system = '{source_system}'"
    
    if database:
        query += f" AND t.database_name = '{database}'"
    
    if schema:
        query += f" AND t.schema_name = '{schema}'"
    
    query += """
    GROUP BY t.table_id, t.source_system, t.database_name, t.schema_name,
             t.table_name, t.full_table_name, t.table_type, t.description,
             t.owner, t.row_count, t.size_bytes, t.created_at, t.last_modified, t.tags
    """
    
    # Filter by PII
    if has_pii is not None:
        if has_pii:
            query += " HAVING has_pii = 1"
        else:
            query += " HAVING has_pii = 0"
    
    query += f" ORDER BY t.table_name LIMIT {limit} OFFSET {offset}"
    
    # Execute query
    try:
        results = execute_query(query)
        
        # Convert to response model
        search_results = []
        for row in results:
            search_results.append(TableSearchResult(
                table_id=row['table_id'],
                source_system=row['source_system'],
                database_name=row['database_name'],
                schema_name=row['schema_name'],
                table_name=row['table_name'],
                full_table_name=row['full_table_name'],
                table_type=row['table_type'],
                description=row.get('description'),
                owner=row.get('owner'),
                row_count=row.get('row_count'),
                size_bytes=row.get('size_bytes'),
                created_at=row.get('created_at'),
                last_modified=row.get('last_modified'),
                tags=row.get('tags') or [],
                column_count=row.get('column_count', 0),
                has_pii=bool(row.get('has_pii', 0))
            ))
        
        return search_results
    
    except Exception as e:
        logger.error(f"Search failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/tables/{table_id}", response_model=TableDetail)
def get_table_detail(table_id: str):
    """Get detailed information about a specific table"""
    
    # Get table info
    table_query = f"""
    SELECT 
        t.*
    FROM {METADATA_CATALOG}.{METADATA_SCHEMA}.tables_metadata t
    WHERE t.table_id = '{table_id}'
    """
    
    try:
        table_results = execute_query(table_query)
        
        if not table_results:
            raise HTTPException(status_code=404, detail="Table not found")
        
        table = table_results[0]
        
        # Get columns
        columns_query = f"""
        SELECT 
            column_name,
            ordinal_position,
            data_type,
            is_nullable,
            is_primary_key,
            is_pii,
            description
        FROM {METADATA_CATALOG}.{METADATA_SCHEMA}.columns_metadata
        WHERE table_id = '{table_id}'
        ORDER BY ordinal_position
        """
        
        columns_results = execute_query(columns_query)
        columns = [ColumnInfo(**col) for col in columns_results]
        
        # Get access groups
        access_query = f"""
        SELECT 
            ag.group_name,
            ag.group_description,
            ram.access_level,
            ag.request_process,
            ag.approval_workflow_url,
            ag.sla_days,
            ag.contact_email
        FROM {METADATA_CATALOG}.{METADATA_SCHEMA}.resource_access_mapping ram
        JOIN {METADATA_CATALOG}.{METADATA_SCHEMA}.ad_groups ag ON ram.ad_group_id = ag.ad_group_id
        WHERE ram.table_id = '{table_id}'
        AND ag.is_active = true
        ORDER BY ram.access_level, ag.group_name
        """
        
        access_results = execute_query(access_query)
        access_groups = [ADGroupInfo(**ag) for ag in access_results]
        
        # Build response
        return TableDetail(
            table_id=table['table_id'],
            source_system=table['source_system'],
            database_name=table['database_name'],
            schema_name=table['schema_name'],
            table_name=table['table_name'],
            full_table_name=table['full_table_name'],
            table_type=table['table_type'],
            description=table.get('description'),
            owner=table.get('owner'),
            row_count=table.get('row_count'),
            size_bytes=table.get('size_bytes'),
            storage_location=table.get('storage_location'),
            data_format=table.get('data_format'),
            is_partitioned=table.get('is_partitioned', False),
            partition_columns=table.get('partition_columns') or [],
            created_at=table.get('created_at'),
            last_modified=table.get('last_modified'),
            tags=table.get('tags') or [],
            columns=columns,
            access_groups=access_groups,
            column_count=len(columns),
            has_pii=any(col.is_pii for col in columns)
        )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get table details: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/stats", response_model=SearchStats)
def get_stats():
    """Get overall metadata statistics"""
    
    query = f"""
    SELECT 
        COUNT(DISTINCT t.table_id) as total_tables,
        SUM(
            (SELECT COUNT(*) FROM {METADATA_CATALOG}.{METADATA_SCHEMA}.columns_metadata c 
             WHERE c.table_id = t.table_id)
        ) as total_columns,
        t.source_system,
        COUNT(*) as source_count,
        MAX(t.extraction_time) as last_updated
    FROM {METADATA_CATALOG}.{METADATA_SCHEMA}.tables_metadata t
    GROUP BY t.source_system
    """
    
    try:
        results = execute_query(query)
        
        total_tables = sum(r['source_count'] for r in results)
        total_columns = sum(r.get('total_columns', 0) for r in results)
        sources = {r['source_system']: r['source_count'] for r in results}
        last_updated = max((r.get('last_updated') for r in results if r.get('last_updated')), default=None)
        
        return SearchStats(
            total_tables=total_tables,
            total_columns=total_columns,
            sources=sources,
            last_updated=last_updated
        )
    
    except Exception as e:
        logger.error(f"Failed to get stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/popular-tables", response_model=List[TableSearchResult])
def get_popular_tables(limit: int = Query(10, ge=1, le=100)):
    """Get most popular/frequently accessed tables"""
    
    query = f"""
    SELECT 
        t.table_id,
        t.source_system,
        t.database_name,
        t.schema_name,
        t.table_name,
        t.full_table_name,
        t.table_type,
        t.description,
        t.owner,
        t.row_count,
        t.size_bytes,
        t.created_at,
        t.last_modified,
        t.tags,
        COUNT(DISTINCT c.column_id) as column_count,
        MAX(CASE WHEN c.is_pii = true THEN 1 ELSE 0 END) as has_pii,
        COUNT(DISTINCT sh.search_id) as search_count
    FROM {METADATA_CATALOG}.{METADATA_SCHEMA}.tables_metadata t
    LEFT JOIN {METADATA_CATALOG}.{METADATA_SCHEMA}.columns_metadata c ON t.table_id = c.table_id
    LEFT JOIN {METADATA_CATALOG}.{METADATA_SCHEMA}.search_history sh ON t.table_id = sh.clicked_table_id
    GROUP BY t.table_id, t.source_system, t.database_name, t.schema_name,
             t.table_name, t.full_table_name, t.table_type, t.description,
             t.owner, t.row_count, t.size_bytes, t.created_at, t.last_modified, t.tags
    HAVING search_count > 0
    ORDER BY search_count DESC
    LIMIT {limit}
    """
    
    try:
        results = execute_query(query)
        
        return [TableSearchResult(
            table_id=row['table_id'],
            source_system=row['source_system'],
            database_name=row['database_name'],
            schema_name=row['schema_name'],
            table_name=row['table_name'],
            full_table_name=row['full_table_name'],
            table_type=row['table_type'],
            description=row.get('description'),
            owner=row.get('owner'),
            row_count=row.get('row_count'),
            size_bytes=row.get('size_bytes'),
            created_at=row.get('created_at'),
            last_modified=row.get('last_modified'),
            tags=row.get('tags') or [],
            column_count=row.get('column_count', 0),
            has_pii=bool(row.get('has_pii', 0))
        ) for row in results]
    
    except Exception as e:
        logger.error(f"Failed to get popular tables: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
def health_check():
    """Health check endpoint"""
    try:
        # Test database connection
        conn = get_db_connection()
        conn.close()
        return {"status": "healthy", "database": "connected"}
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
