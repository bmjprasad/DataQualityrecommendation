"""
Hive Metadata Extractor
Extracts table and column metadata from On-Premise Hive Metastore
"""

from pyhive import hive
from typing import List, Dict, Any
from datetime import datetime
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class HiveMetadataExtractor:
    """Extract metadata from Hive Metastore using HiveServer2"""
    
    def __init__(self, host: str, port: int = 10000, username: str = None, 
                 password: str = None, auth: str = 'NONE', database: str = 'default'):
        """
        Initialize Hive extractor
        
        Args:
            host: Hive server hostname
            port: HiveServer2 port (default 10000)
            username: Username for authentication
            password: Password for authentication
            auth: Authentication method ('NONE', 'LDAP', 'KERBEROS')
            database: Default database to connect to
        """
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.auth = auth
        self.database = database
        self.connection = None
    
    def connect(self):
        """Establish connection to Hive"""
        try:
            self.connection = hive.Connection(
                host=self.host,
                port=self.port,
                username=self.username,
                password=self.password,
                auth=self.auth,
                database=self.database
            )
            logger.info(f"Connected to Hive at {self.host}:{self.port}")
        except Exception as e:
            logger.error(f"Failed to connect to Hive: {e}")
            raise
    
    def close(self):
        """Close connection to Hive"""
        if self.connection:
            self.connection.close()
            logger.info("Hive connection closed")
    
    def get_databases(self) -> List[str]:
        """Get all databases in Hive"""
        cursor = self.connection.cursor()
        cursor.execute("SHOW DATABASES")
        databases = [row[0] for row in cursor.fetchall()]
        cursor.close()
        logger.info(f"Found {len(databases)} databases")
        return databases
    
    def get_tables(self, database: str) -> List[str]:
        """Get all tables in a database"""
        cursor = self.connection.cursor()
        cursor.execute(f"SHOW TABLES IN {database}")
        tables = [row[0] for row in cursor.fetchall()]
        cursor.close()
        logger.info(f"Found {len(tables)} tables in database {database}")
        return tables
    
    def get_table_metadata(self, database: str, table: str) -> Dict[str, Any]:
        """Get detailed metadata for a table"""
        cursor = self.connection.cursor()
        
        try:
            # Get table description
            cursor.execute(f"DESCRIBE FORMATTED {database}.{table}")
            desc_results = cursor.fetchall()
            
            # Parse DESCRIBE FORMATTED output
            metadata = {
                'source_system': 'hive',
                'database_name': database,
                'table_name': table,
                'full_table_name': f"{database}.{table}",
                'columns': [],
                'partition_columns': [],
                'table_type': None,
                'location': None,
                'owner': None,
                'created_time': None,
                'last_access_time': None,
                'input_format': None,
                'output_format': None,
                'serde_library': None,
                'num_rows': None,
                'total_size': None,
                'extracted_at': datetime.utcnow().isoformat()
            }
            
            # Parse the description output
            section = 'columns'
            for row in desc_results:
                col_name = row[0].strip() if row[0] else ''
                data_type = row[1].strip() if row[1] else ''
                comment = row[2].strip() if row[2] else ''
                
                # Detect sections
                if col_name.startswith('#'):
                    if 'Partition Information' in col_name:
                        section = 'partitions'
                    elif 'Detailed Table Information' in col_name:
                        section = 'details'
                    continue
                
                if not col_name:
                    continue
                
                # Process columns
                if section == 'columns' and col_name and data_type:
                    metadata['columns'].append({
                        'column_name': col_name,
                        'data_type': data_type,
                        'comment': comment
                    })
                
                # Process partition columns
                elif section == 'partitions' and col_name and data_type:
                    if col_name != 'col_name':  # Skip header
                        metadata['partition_columns'].append({
                            'column_name': col_name,
                            'data_type': data_type,
                            'comment': comment
                        })
                
                # Process table details
                elif section == 'details':
                    if col_name.startswith('Owner:'):
                        metadata['owner'] = data_type
                    elif col_name.startswith('Table Type:'):
                        metadata['table_type'] = data_type
                    elif col_name.startswith('Location:'):
                        metadata['location'] = data_type
                    elif col_name.startswith('CreateTime:'):
                        metadata['created_time'] = data_type
                    elif col_name.startswith('LastAccessTime:'):
                        metadata['last_access_time'] = data_type
                    elif col_name.startswith('InputFormat:'):
                        metadata['input_format'] = data_type
                    elif col_name.startswith('OutputFormat:'):
                        metadata['output_format'] = data_type
                    elif col_name.startswith('SerDe Library:'):
                        metadata['serde_library'] = data_type
            
            # Get table statistics
            try:
                cursor.execute(f"ANALYZE TABLE {database}.{table} COMPUTE STATISTICS")
                cursor.execute(f"DESCRIBE EXTENDED {database}.{table}")
                stats = cursor.fetchall()
                for row in stats:
                    if row[0] and 'numRows' in row[0]:
                        metadata['num_rows'] = row[1]
                    elif row[0] and 'totalSize' in row[0]:
                        metadata['total_size'] = row[1]
            except:
                pass  # Statistics might not be available
            
            # Add ordinal positions to columns
            for idx, col in enumerate(metadata['columns']):
                col['ordinal_position'] = idx + 1
            
            return metadata
        
        except Exception as e:
            logger.error(f"Error extracting metadata for {database}.{table}: {e}")
            raise
        finally:
            cursor.close()
    
    def extract_all_metadata(self) -> List[Dict[str, Any]]:
        """
        Extract all metadata from Hive
        
        Returns:
            List of table metadata dictionaries
        """
        all_metadata = []
        
        try:
            if not self.connection:
                self.connect()
            
            databases = self.get_databases()
            
            for database in databases:
                # Skip system databases
                if database in ['information_schema', 'sys']:
                    continue
                
                try:
                    tables = self.get_tables(database)
                    
                    for table in tables:
                        try:
                            metadata = self.get_table_metadata(database, table)
                            all_metadata.append(metadata)
                        except Exception as e:
                            logger.error(f"Error extracting table {database}.{table}: {e}")
                            continue
                
                except Exception as e:
                    logger.error(f"Error extracting tables from database {database}: {e}")
                    continue
            
            logger.info(f"Successfully extracted metadata for {len(all_metadata)} tables")
            return all_metadata
        
        except Exception as e:
            logger.error(f"Error in metadata extraction: {e}")
            raise


# Alternative implementation using direct metastore DB access
class HiveMetastoreDBExtractor:
    """
    Extract metadata directly from Hive Metastore database
    This is faster for large catalogs but requires direct DB access
    """
    
    def __init__(self, metastore_db_url: str):
        """
        Initialize with metastore database connection
        
        Args:
            metastore_db_url: SQLAlchemy connection string
                             e.g., 'mysql+pymysql://user:pass@host/metastore'
        """
        from sqlalchemy import create_engine
        self.engine = create_engine(metastore_db_url)
    
    def extract_all_metadata(self) -> List[Dict[str, Any]]:
        """Extract metadata directly from metastore DB"""
        query = """
        SELECT 
            d.NAME as database_name,
            t.TBL_NAME as table_name,
            t.TBL_TYPE as table_type,
            t.OWNER as owner,
            t.CREATE_TIME as created_time,
            sd.LOCATION as location,
            sd.INPUT_FORMAT as input_format,
            sd.OUTPUT_FORMAT as output_format,
            s.SLIB as serde_library,
            c.COLUMN_NAME as column_name,
            c.TYPE_NAME as data_type,
            c.INTEGER_IDX as ordinal_position,
            c.COMMENT as comment
        FROM TBLS t
        JOIN DBS d ON t.DB_ID = d.DB_ID
        JOIN SDS sd ON t.SD_ID = sd.SD_ID
        LEFT JOIN SERDES s ON sd.SERDE_ID = s.SERDE_ID
        LEFT JOIN COLUMNS_V2 c ON sd.CD_ID = c.CD_ID
        ORDER BY d.NAME, t.TBL_NAME, c.INTEGER_IDX
        """
        
        import pandas as pd
        df = pd.read_sql(query, self.engine)
        
        # Group by table and aggregate columns
        all_metadata = []
        for (db, table), group in df.groupby(['database_name', 'table_name']):
            columns = []
            for _, row in group.iterrows():
                if pd.notna(row['column_name']):
                    columns.append({
                        'column_name': row['column_name'],
                        'data_type': row['data_type'],
                        'ordinal_position': row['ordinal_position'],
                        'comment': row['comment'] if pd.notna(row['comment']) else ''
                    })
            
            metadata = {
                'source_system': 'hive',
                'database_name': db,
                'table_name': table,
                'full_table_name': f"{db}.{table}",
                'table_type': group.iloc[0]['table_type'],
                'owner': group.iloc[0]['owner'],
                'location': group.iloc[0]['location'],
                'created_time': str(group.iloc[0]['created_time']),
                'input_format': group.iloc[0]['input_format'],
                'output_format': group.iloc[0]['output_format'],
                'serde_library': group.iloc[0]['serde_library'],
                'columns': columns,
                'extracted_at': datetime.utcnow().isoformat()
            }
            all_metadata.append(metadata)
        
        return all_metadata


# Example usage
if __name__ == "__main__":
    # Configuration
    HIVE_HOST = "hive-server.company.com"
    HIVE_PORT = 10000
    USERNAME = "your-username"
    PASSWORD = "your-password"
    
    # Initialize extractor
    extractor = HiveMetadataExtractor(
        host=HIVE_HOST,
        port=HIVE_PORT,
        username=USERNAME,
        password=PASSWORD,
        auth='LDAP'
    )
    
    try:
        # Extract metadata
        metadata = extractor.extract_all_metadata()
        
        # Print sample
        if metadata:
            print(f"Extracted {len(metadata)} tables")
            print("\nSample table metadata:")
            import json
            print(json.dumps(metadata[0], indent=2))
    finally:
        extractor.close()
