# Quick Reference: Metadata Management with Databricks Delta

## 📁 Complete Solution Overview

This solution provides a comprehensive technical metadata management platform that:
- Extracts metadata from **Databricks, Hive, DB2, and Erwin**
- Stores metadata in **Databricks Delta Tables** 
- Provides **search capabilities** via SQL, API, and UI
- Integrates **Active Directory groups** for access management
- Enables **self-service access requests**

## 🗂️ File Structure

```
metadata-management/
├── Extraction Scripts
│   ├── databricks_extractor.py          # Extract from Databricks
│   ├── hive_extractor.py                # Extract from Hive
│   ├── db2_extractor.py                 # Extract from DB2
│   └── erwin_extractor.py               # Extract from Erwin
│
├── Delta Loading
│   ├── load_metadata_to_delta.py        # Load to Databricks Delta ⭐
│   └── MetadataSearchNotebook.py        # Databricks notebook for queries ⭐
│
├── Serving Layer
│   ├── databricks_delta_api.py          # FastAPI for Delta tables ⭐
│   ├── metadata_search_api.py           # FastAPI for PostgreSQL
│   └── metadata_orchestrator.py         # Orchestration pipeline
│
├── Frontend
│   ├── MetadataSearch.jsx               # React search component
│   └── MetadataSearch.css               # Styling
│
├── Database
│   └── metadata_repository_schema.sql   # PostgreSQL schema (alternative)
│
├── Documentation
│   ├── DATABRICKS_DELTA_SERVING_GUIDE.md  # Delta serving guide ⭐
│   ├── DEPLOYMENT_GUIDE.md                 # Deployment instructions
│   ├── README.md                            # Main documentation
│   ├── metadata_solution_architecture.md   # Architecture details
│   └── requirements.txt                    # Python dependencies
│
└── ⭐ = Files for Databricks Delta serving
```

## 🚀 Quick Start - Databricks Delta Serving

### Step 1: Set Up Environment

```bash
# Set environment variables
export DATABRICKS_WORKSPACE_URL="https://your-workspace.cloud.databricks.com"
export DATABRICKS_TOKEN="your-token"
export DATABRICKS_SERVER_HOSTNAME="your-workspace.cloud.databricks.com"
export DATABRICKS_HTTP_PATH="/sql/1.0/warehouses/your-warehouse-id"

# For source systems
export HIVE_HOST="hive-server.company.com"
export HIVE_USERNAME="your-username"
export HIVE_PASSWORD="your-password"
export DB2_HOST="db2-server.company.com"
export DB2_DATABASE="MYDB"
```

### Step 2: Load Metadata to Delta

```python
# Run the loader
python load_metadata_to_delta.py

# This creates:
# - metadata_catalog.technical_metadata.tables_metadata
# - metadata_catalog.technical_metadata.columns_metadata
# - metadata_catalog.technical_metadata.ad_groups
# - metadata_catalog.technical_metadata.resource_access_mapping
```

### Step 3: Query Metadata

**Option A: SQL (Databricks SQL)**

```sql
USE CATALOG metadata_catalog;
USE SCHEMA technical_metadata;

-- Search for tables
SELECT * FROM v_searchable_metadata 
WHERE LOWER(table_name) LIKE '%customer%';
```

**Option B: Python (Databricks Notebook)**

Upload `MetadataSearchNotebook.py` to Databricks and run interactively.

**Option C: REST API**

```bash
# Start API server
uvicorn databricks_delta_api:app --port 8000

# Search
curl "http://localhost:8000/api/v1/search?q=customer"
```

**Option D: Web UI**

Open `MetadataSearch.jsx` in your React app pointing to the API.

## 📊 Common SQL Queries

### Search Tables by Name

```sql
SELECT * FROM metadata_catalog.technical_metadata.tables_metadata
WHERE LOWER(table_name) LIKE '%sales%';
```

### Find Tables with PII

```sql
SELECT DISTINCT t.full_table_name, t.owner
FROM metadata_catalog.technical_metadata.tables_metadata t
JOIN metadata_catalog.technical_metadata.columns_metadata c ON t.table_id = c.table_id
WHERE c.is_pii = true;
```

### Get Table with Columns

```sql
SELECT 
    t.full_table_name,
    t.description,
    c.column_name,
    c.data_type,
    c.is_pii
FROM metadata_catalog.technical_metadata.tables_metadata t
LEFT JOIN metadata_catalog.technical_metadata.columns_metadata c ON t.table_id = c.table_id
WHERE t.table_name = 'customers'
ORDER BY c.ordinal_position;
```

### Get Access Groups for Table

```sql
SELECT 
    t.full_table_name,
    ag.group_name,
    ram.access_level,
    ag.request_process
FROM metadata_catalog.technical_metadata.tables_metadata t
JOIN metadata_catalog.technical_metadata.resource_access_mapping ram ON t.table_id = ram.table_id
JOIN metadata_catalog.technical_metadata.ad_groups ag ON ram.ad_group_id = ag.ad_group_id
WHERE t.table_id = 'your-table-id';
```

## 🔄 Scheduled Refresh

### Using Databricks Jobs

```python
# Create a job that runs daily at 2 AM
# Task type: Notebook
# Notebook: load_metadata_to_delta.py
# Schedule: 0 0 2 * * ?
```

### Manual Refresh

```python
from load_metadata_to_delta import MetadataToDeltaLoader, get_config

loader = MetadataToDeltaLoader()
loader.run_full_load(get_config())
```

## 🎯 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/v1/search` | GET | Search tables with filters |
| `/api/v1/tables/{id}` | GET | Get detailed table metadata |
| `/api/v1/stats` | GET | Get overall statistics |
| `/api/v1/popular-tables` | GET | Get most accessed tables |
| `/health` | GET | Health check |

### Example API Calls

```bash
# Search
curl "http://localhost:8000/api/v1/search?q=customer&source_system=databricks&limit=10"

# Get table details
curl "http://localhost:8000/api/v1/tables/databricks_prod_sales_customers"

# Get statistics
curl "http://localhost:8000/api/v1/stats"

# Popular tables
curl "http://localhost:8000/api/v1/popular-tables?limit=20"
```

## 🏗️ Delta Table Architecture

```
metadata_catalog.technical_metadata
│
├── tables_metadata               (Partitioned by source_system)
│   ├── table_id
│   ├── source_system
│   ├── full_table_name
│   ├── description
│   ├── row_count
│   └── ... (20+ columns)
│
├── columns_metadata             (Partitioned by source_system)
│   ├── column_id
│   ├── table_id
│   ├── column_name
│   ├── data_type
│   ├── is_pii
│   └── ... (15+ columns)
│
├── ad_groups
│   ├── ad_group_id
│   ├── group_name
│   ├── request_process
│   └── approval_workflow_url
│
├── resource_access_mapping      (Partitioned by resource_type)
│   ├── table_id
│   ├── ad_group_id
│   └── access_level
│
└── Views
    ├── v_searchable_metadata    (Optimized for search)
    ├── v_column_search
    └── v_popular_tables
```

## ⚡ Performance Tips

1. **Use Partitioning**: Tables partitioned by `source_system`
2. **Z-Ordering**: Run `OPTIMIZE ... ZORDER BY (source_system, database_name)`
3. **Caching**: Enable result caching in SQL Warehouse
4. **Materialized Views**: Create for common aggregations
5. **Delta Optimization**: Enable `autoOptimize` properties

```sql
-- Optimize tables
OPTIMIZE metadata_catalog.technical_metadata.tables_metadata
ZORDER BY (source_system, database_name, schema_name);

-- Enable auto-optimization
ALTER TABLE metadata_catalog.technical_metadata.tables_metadata
SET TBLPROPERTIES ('delta.autoOptimize.autoCompact' = 'true');
```

## 🔐 Security Configuration

### Grant Access to Users

```sql
-- Grant catalog usage
GRANT USAGE ON CATALOG metadata_catalog TO `data_consumers`;

-- Grant schema access
GRANT USAGE, SELECT ON SCHEMA metadata_catalog.technical_metadata TO `data_consumers`;

-- Grant table access
GRANT SELECT ON TABLE metadata_catalog.technical_metadata.tables_metadata TO `data_consumers`;
```

### Row-Level Security

```sql
CREATE VIEW tables_metadata_secure AS
SELECT * FROM metadata_catalog.technical_metadata.tables_metadata
WHERE owner = current_user();
```

## 📈 Monitoring Queries

### Check Data Freshness

```sql
SELECT 
    source_system,
    MAX(extraction_time) as last_extraction,
    DATEDIFF(NOW(), MAX(extraction_time)) as days_old
FROM metadata_catalog.technical_metadata.tables_metadata
GROUP BY source_system;
```

### Metadata Coverage

```sql
SELECT 
    source_system,
    COUNT(*) as total_tables,
    SUM(CASE WHEN description IS NOT NULL THEN 1 ELSE 0 END) as documented,
    ROUND(100.0 * SUM(CASE WHEN description IS NOT NULL THEN 1 ELSE 0 END) / COUNT(*), 1) as coverage_pct
FROM metadata_catalog.technical_metadata.tables_metadata
GROUP BY source_system;
```

### Search Activity

```sql
SELECT 
    DATE(search_timestamp) as date,
    COUNT(*) as search_count,
    COUNT(DISTINCT user_id) as unique_users
FROM metadata_catalog.technical_metadata.search_history
WHERE search_timestamp >= CURRENT_DATE - INTERVAL 30 DAYS
GROUP BY DATE(search_timestamp)
ORDER BY date DESC;
```

## 🔍 Troubleshooting

### Issue: Slow Queries

**Solution:**
```sql
-- Analyze tables
ANALYZE TABLE metadata_catalog.technical_metadata.tables_metadata COMPUTE STATISTICS;

-- Optimize
OPTIMIZE metadata_catalog.technical_metadata.tables_metadata;
```

### Issue: Stale Metadata

**Solution:**
```python
# Re-run extraction
python load_metadata_to_delta.py
```

### Issue: Missing Tables

**Solution:**
```sql
-- Check source systems
SELECT DISTINCT source_system FROM metadata_catalog.technical_metadata.tables_metadata;

-- Verify extraction logs
```

## 🎓 Key Concepts

**Delta Lake Features:**
- **ACID Transactions**: Reliable concurrent reads/writes
- **Time Travel**: Query historical versions
- **Schema Evolution**: Add columns without breaking queries
- **Change Data Feed**: Track what changed
- **Merge Operations**: Efficient upserts

**Unity Catalog:**
- **Three-level Namespace**: catalog.schema.table
- **Fine-grained ACLs**: Column, row, table-level security
- **Data Lineage**: Track data flow
- **Audit Logs**: Track all access

## 📚 Additional Resources

- [Databricks Delta Guide](DATABRICKS_DELTA_SERVING_GUIDE.md) - Complete Delta serving guide
- [Deployment Guide](DEPLOYMENT_GUIDE.md) - Full deployment instructions
- [Architecture](metadata_solution_architecture.md) - Solution architecture
- [README](README.md) - Main documentation

## 🆘 Support

- API Documentation: http://localhost:8000/docs
- Databricks SQL: https://your-workspace.cloud.databricks.com/sql
- Unity Catalog: https://your-workspace.cloud.databricks.com/explore/data

## ✅ Checklist

- [ ] Environment variables configured
- [ ] Databricks workspace access confirmed
- [ ] Source system credentials validated
- [ ] Delta tables created in Unity Catalog
- [ ] Initial metadata load completed
- [ ] SQL queries tested
- [ ] API server running
- [ ] Scheduled refresh configured
- [ ] Access controls configured
- [ ] Dashboards created

---

**You now have a production-ready metadata management solution powered by Databricks Delta! 🎉**
