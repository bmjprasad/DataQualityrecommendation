"""
Erwin Data Modeler Metadata Extractor
Extracts logical and physical model metadata from Erwin
"""

import xml.etree.ElementTree as ET
from typing import List, Dict, Any
from datetime import datetime
import logging
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ErwinMetadataExtractor:
    """
    Extract metadata from Erwin Data Modeler
    Supports XML export format from Erwin
    """
    
    def __init__(self, xml_file_path: str = None, xml_content: str = None):
        """
        Initialize Erwin extractor
        
        Args:
            xml_file_path: Path to Erwin XML export file
            xml_content: Raw XML content string
        """
        self.xml_file_path = xml_file_path
        self.xml_content = xml_content
        self.tree = None
        self.root = None
    
    def load_xml(self):
        """Load and parse XML file"""
        try:
            if self.xml_file_path:
                self.tree = ET.parse(self.xml_file_path)
                self.root = self.tree.getroot()
                logger.info(f"Loaded Erwin XML from {self.xml_file_path}")
            elif self.xml_content:
                self.root = ET.fromstring(self.xml_content)
                logger.info("Loaded Erwin XML from content string")
            else:
                raise ValueError("Either xml_file_path or xml_content must be provided")
        except Exception as e:
            logger.error(f"Failed to load Erwin XML: {e}")
            raise
    
    def extract_logical_model(self) -> Dict[str, Any]:
        """Extract logical data model entities and attributes"""
        logical_model = {
            'entities': [],
            'relationships': [],
            'subject_areas': []
        }
        
        # Find all logical entities
        for entity in self.root.findall(".//Entity"):
            entity_data = {
                'entity_id': entity.get('Id'),
                'entity_name': entity.findtext('Name'),
                'definition': entity.findtext('Definition'),
                'subject_area': entity.findtext('SubjectArea'),
                'attributes': []
            }
            
            # Extract attributes
            for attribute in entity.findall('.//Attribute'):
                attr_data = {
                    'attribute_id': attribute.get('Id'),
                    'attribute_name': attribute.findtext('Name'),
                    'definition': attribute.findtext('Definition'),
                    'data_type': attribute.findtext('DataType'),
                    'is_primary_key': attribute.findtext('PrimaryKey') == 'true',
                    'is_foreign_key': attribute.findtext('ForeignKey') == 'true',
                    'is_mandatory': attribute.findtext('Mandatory') == 'true',
                    'parent_entity': attribute.findtext('ParentEntity')
                }
                entity_data['attributes'].append(attr_data)
            
            logical_model['entities'].append(entity_data)
        
        # Extract relationships
        for relationship in self.root.findall(".//Relationship"):
            rel_data = {
                'relationship_id': relationship.get('Id'),
                'relationship_name': relationship.findtext('Name'),
                'parent_entity': relationship.findtext('ParentEntity'),
                'child_entity': relationship.findtext('ChildEntity'),
                'relationship_type': relationship.findtext('Type'),
                'cardinality': relationship.findtext('Cardinality'),
                'verb_phrase': relationship.findtext('VerbPhrase')
            }
            logical_model['relationships'].append(rel_data)
        
        return logical_model
    
    def extract_physical_model(self) -> List[Dict[str, Any]]:
        """Extract physical data model tables and columns"""
        physical_tables = []
        
        # Find all physical tables
        for table in self.root.findall(".//Table"):
            table_data = {
                'source_system': 'erwin',
                'schema_name': table.findtext('Schema'),
                'table_name': table.findtext('Name'),
                'physical_name': table.findtext('PhysicalName'),
                'table_type': table.findtext('TableType', 'TABLE'),
                'definition': table.findtext('Definition'),
                'owner': table.findtext('Owner'),
                'tablespace': table.findtext('Tablespace'),
                'logical_entity': table.findtext('LogicalEntity'),
                'columns': [],
                'indexes': [],
                'foreign_keys': [],
                'extracted_at': datetime.utcnow().isoformat()
            }
            
            # Extract columns
            ordinal = 1
            for column in table.findall('.//Column'):
                col_data = {
                    'column_name': column.findtext('Name'),
                    'physical_name': column.findtext('PhysicalName'),
                    'ordinal_position': ordinal,
                    'data_type': column.findtext('DataType'),
                    'length': column.findtext('Length'),
                    'precision': column.findtext('Precision'),
                    'scale': column.findtext('Scale'),
                    'is_nullable': column.findtext('Nullable') == 'true',
                    'is_primary_key': column.findtext('PrimaryKey') == 'true',
                    'is_foreign_key': column.findtext('ForeignKey') == 'true',
                    'default_value': column.findtext('DefaultValue'),
                    'definition': column.findtext('Definition'),
                    'logical_attribute': column.findtext('LogicalAttribute')
                }
                table_data['columns'].append(col_data)
                ordinal += 1
            
            # Extract indexes
            for index in table.findall('.//Index'):
                index_data = {
                    'index_name': index.findtext('Name'),
                    'is_unique': index.findtext('Unique') == 'true',
                    'is_primary': index.findtext('Primary') == 'true',
                    'index_type': index.findtext('Type'),
                    'columns': []
                }
                for idx_col in index.findall('.//IndexColumn'):
                    index_data['columns'].append(idx_col.findtext('ColumnName'))
                table_data['indexes'].append(index_data)
            
            # Extract foreign keys
            for fk in table.findall('.//ForeignKey'):
                fk_data = {
                    'constraint_name': fk.findtext('Name'),
                    'referenced_schema': fk.findtext('ReferencedSchema'),
                    'referenced_table': fk.findtext('ReferencedTable'),
                    'columns': [],
                    'referenced_columns': []
                }
                for fk_col in fk.findall('.//FKColumn'):
                    fk_data['columns'].append(fk_col.findtext('ColumnName'))
                    fk_data['referenced_columns'].append(fk_col.findtext('ReferencedColumn'))
                table_data['foreign_keys'].append(fk_data)
            
            physical_tables.append(table_data)
        
        return physical_tables
    
    def extract_data_dictionary(self) -> Dict[str, Any]:
        """Extract business glossary and data dictionary"""
        data_dictionary = {
            'business_terms': [],
            'domains': [],
            'standards': []
        }
        
        # Extract business terms
        for term in self.root.findall(".//BusinessTerm"):
            term_data = {
                'term_id': term.get('Id'),
                'term_name': term.findtext('Name'),
                'definition': term.findtext('Definition'),
                'synonyms': term.findtext('Synonyms'),
                'related_terms': term.findtext('RelatedTerms'),
                'category': term.findtext('Category'),
                'steward': term.findtext('DataSteward')
            }
            data_dictionary['business_terms'].append(term_data)
        
        # Extract domains
        for domain in self.root.findall(".//Domain"):
            domain_data = {
                'domain_id': domain.get('Id'),
                'domain_name': domain.findtext('Name'),
                'data_type': domain.findtext('DataType'),
                'valid_values': domain.findtext('ValidValues'),
                'description': domain.findtext('Description')
            }
            data_dictionary['domains'].append(domain_data)
        
        return data_dictionary
    
    def extract_all_metadata(self) -> Dict[str, Any]:
        """
        Extract all metadata from Erwin
        
        Returns:
            Dictionary containing logical model, physical model, and data dictionary
        """
        try:
            if not self.root:
                self.load_xml()
            
            metadata = {
                'source_system': 'erwin',
                'extracted_at': datetime.utcnow().isoformat(),
                'logical_model': self.extract_logical_model(),
                'physical_tables': self.extract_physical_model(),
                'data_dictionary': self.extract_data_dictionary()
            }
            
            logger.info(
                f"Extracted metadata: "
                f"{len(metadata['logical_model']['entities'])} logical entities, "
                f"{len(metadata['physical_tables'])} physical tables, "
                f"{len(metadata['data_dictionary']['business_terms'])} business terms"
            )
            
            return metadata
        
        except Exception as e:
            logger.error(f"Error in metadata extraction: {e}")
            raise


class ErwinAPIExtractor:
    """
    Alternative extractor using Erwin Mart / Metadata SDK
    This requires Erwin SDK installation and access to Erwin Mart
    """
    
    def __init__(self, mart_connection_string: str):
        """
        Initialize Erwin API extractor
        
        Args:
            mart_connection_string: Connection string to Erwin Mart database
        """
        try:
            # This requires erwin SDK (win32com on Windows)
            import win32com.client
            self.erwin_app = win32com.client.Dispatch("erwin.SCAPI")
            self.mart_connection = mart_connection_string
            logger.info("Initialized Erwin API extractor")
        except ImportError:
            logger.error("Erwin SDK not available. Install pywin32 on Windows with Erwin installed.")
            raise
    
    def connect_to_mart(self):
        """Connect to Erwin Mart"""
        try:
            self.erwin_app.ConnectToMart(self.mart_connection)
            logger.info("Connected to Erwin Mart")
        except Exception as e:
            logger.error(f"Failed to connect to Erwin Mart: {e}")
            raise
    
    def extract_from_mart(self) -> List[Dict[str, Any]]:
        """Extract metadata from Erwin Mart using API"""
        # Implementation depends on specific Erwin Mart schema
        # This is a skeleton that would need to be customized
        pass


# Example usage
if __name__ == "__main__":
    # Example 1: Extract from XML export
    XML_FILE_PATH = "erwin_export.xml"
    
    if os.path.exists(XML_FILE_PATH):
        extractor = ErwinMetadataExtractor(xml_file_path=XML_FILE_PATH)
        metadata = extractor.extract_all_metadata()
        
        print(f"Logical entities: {len(metadata['logical_model']['entities'])}")
        print(f"Physical tables: {len(metadata['physical_tables'])}")
        print(f"Business terms: {len(metadata['data_dictionary']['business_terms'])}")
        
        # Print sample physical table
        if metadata['physical_tables']:
            print("\nSample physical table:")
            import json
            print(json.dumps(metadata['physical_tables'][0], indent=2))
    else:
        print(f"XML file not found: {XML_FILE_PATH}")
        print("Export your Erwin model to XML format first")
    
    # Example 2: Using Erwin API (Windows only with Erwin installed)
    # extractor = ErwinAPIExtractor(mart_connection_string="...")
    # extractor.connect_to_mart()
    # metadata = extractor.extract_from_mart()
