import streamlit as st
import json
from datetime import datetime
from typing import Dict, List, Optional
import pandas as pd

# Page configuration
st.set_page_config(
    page_title="Pipeline Metadata Builder",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        margin-bottom: 1rem;
    }
    .chat-message {
        padding: 1rem;
        border-radius: 0.5rem;
        margin-bottom: 1rem;
        display: flex;
        flex-direction: column;
    }
    .user-message {
        background-color: #e3f2fd;
        align-self: flex-end;
    }
    .bot-message {
        background-color: #f5f5f5;
        align-self: flex-start;
    }
    .success-box {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        color: #155724;
        margin: 1rem 0;
    }
    .stButton>button {
        width: 100%;
    }
</style>
""", unsafe_allow_html=True)

class MetadataConversationBot:
    """Conversational bot for collecting pipeline metadata"""
    
    def __init__(self):
        self.states = [
            "welcome",
            "pipeline_name",
            "source_name",
            "source_location",
            "file_format",
            "source_columns",
            "data_quality_rules",
            "add_more_dq",
            "transformations",
            "add_more_transformations",
            "target_database",
            "target_table",
            "sync_mode",
            "merge_keys",
            "review",
            "complete"
        ]
        
    def get_prompt(self, state: str, context: Dict = None) -> str:
        """Get the appropriate prompt for each state"""
        prompts = {
            "welcome": "👋 Hi! I'm your Pipeline Metadata Assistant. I'll help you create metadata configuration for your Spark pipeline. Ready to start?",
            
            "pipeline_name": "Great! Let's begin. What would you like to name this pipeline?",
            
            "source_name": "Perfect! Now, what's the name of your source system? (e.g., sales_db, customer_api, etc.)",
            
            "source_location": "Got it! Where is the source data located? Please provide the full path:\n- S3: `s3://bucket-name/path/to/data`\n- DBFS: `/dbfs/mnt/data/...`\n- Azure: `abfss://container@storage.dfs.core.windows.net/path`",
            
            "file_format": "What's the file format of your source data?\n- parquet\n- csv\n- json\n- delta\n- avro\n- orc",
            
            "source_columns": """Now I need to know about your source columns. You have three options:

1. **Type 'infer'** - I'll attempt to infer the schema from the source file
2. **Manual entry** - Enter columns in this format: `col1:string, col2:int, col3:timestamp`
3. **Upload sample** - Upload a CSV file with column names and types

What would you like to do?""",
            
            "data_quality_rules": """Would you like to add data quality rules? These help ensure data integrity.

Type 'yes' to add rules, or 'skip' to move on.""",
            
            "add_more_dq": "Would you like to add another data quality rule? (yes/no)",
            
            "transformations": """Do you need any transformations on the data?

Type 'yes' to add transformations, or 'skip' to continue.""",
            
            "add_more_transformations": "Would you like to add another transformation? (yes/no)",
            
            "target_database": "What's the target database/schema name?",
            
            "target_table": "What's the target table name?",
            
            "sync_mode": """How should data be synced to the target?

- **append**: Add new records to existing data
- **overwrite**: Replace all existing data
- **merge**: Update existing records and insert new ones (requires merge keys)

Choose one:""",
            
            "merge_keys": "You selected 'merge' mode. Please specify the merge key columns (comma-separated):",
            
            "review": """Perfect! Let me show you the complete metadata configuration. Please review it carefully.

If everything looks good, type 'confirm' to save it.
If you need changes, type 'edit' to modify specific sections.""",
            
            "complete": "✅ Metadata saved successfully! Your pipeline configuration is ready to use."
        }
        
        return prompts.get(state, "I'm not sure what to ask next. Please contact support.")
    
    def process_input(self, state: str, user_input: str, metadata: Dict) -> tuple:
        """Process user input and update metadata"""
        
        if state == "welcome":
            return "pipeline_name", metadata, None
        
        elif state == "pipeline_name":
            metadata['pipeline_name'] = user_input.strip()
            metadata['pipeline_id'] = f"pipeline_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            return "source_name", metadata, None
        
        elif state == "source_name":
            if 'source' not in metadata:
                metadata['source'] = {}
            metadata['source']['source_name'] = user_input.strip()
            return "source_location", metadata, None
        
        elif state == "source_location":
            metadata['source']['source_location'] = user_input.strip()
            return "file_format", metadata, None
        
        elif state == "file_format":
            format_input = user_input.strip().lower()
            valid_formats = ['parquet', 'csv', 'json', 'delta', 'avro', 'orc']
            if format_input in valid_formats:
                metadata['source']['file_format'] = format_input
                return "source_columns", metadata, None
            else:
                return state, metadata, f"Invalid format. Please choose from: {', '.join(valid_formats)}"
        
        elif state == "source_columns":
            if user_input.strip().lower() == 'infer':
                return state, metadata, "infer_schema"
            elif user_input.strip().lower() == 'upload':
                return state, metadata, "upload_schema"
            else:
                columns = self.parse_columns(user_input)
                if columns:
                    metadata['source']['source_columns'] = columns
                    return "data_quality_rules", metadata, None
                else:
                    return state, metadata, "Invalid format. Please use: col1:type1, col2:type2"
        
        elif state == "data_quality_rules":
            if user_input.strip().lower() in ['yes', 'y']:
                if 'data_quality_rules' not in metadata:
                    metadata['data_quality_rules'] = []
                return state, metadata, "show_dq_form"
            else:
                return "transformations", metadata, None
        
        elif state == "add_more_dq":
            if user_input.strip().lower() in ['yes', 'y']:
                return "data_quality_rules", metadata, "show_dq_form"
            else:
                return "transformations", metadata, None
        
        elif state == "transformations":
            if user_input.strip().lower() in ['yes', 'y']:
                if 'transformations' not in metadata:
                    metadata['transformations'] = []
                return state, metadata, "show_transform_form"
            else:
                return "target_database", metadata, None
        
        elif state == "add_more_transformations":
            if user_input.strip().lower() in ['yes', 'y']:
                return "transformations", metadata, "show_transform_form"
            else:
                return "target_database", metadata, None
        
        elif state == "target_database":
            if 'target' not in metadata:
                metadata['target'] = {}
            metadata['target']['target_database'] = user_input.strip()
            return "target_table", metadata, None
        
        elif state == "target_table":
            metadata['target']['target_table'] = user_input.strip()
            return "sync_mode", metadata, None
        
        elif state == "sync_mode":
            mode = user_input.strip().lower()
            valid_modes = ['append', 'overwrite', 'merge']
            if mode in valid_modes:
                metadata['target']['sync_mode'] = mode
                if mode == 'merge':
                    return "merge_keys", metadata, None
                else:
                    metadata['target']['merge_keys'] = []
                    return "review", metadata, None
            else:
                return state, metadata, f"Invalid mode. Please choose: {', '.join(valid_modes)}"
        
        elif state == "merge_keys":
            keys = [k.strip() for k in user_input.split(',')]
            metadata['target']['merge_keys'] = keys
            return "review", metadata, None
        
        elif state == "review":
            if user_input.strip().lower() == 'confirm':
                metadata['created_at'] = datetime.now().isoformat()
                metadata['created_by'] = 'streamlit_user'
                metadata['is_active'] = True
                return "complete", metadata, "save_metadata"
            elif user_input.strip().lower() == 'edit':
                return state, metadata, "show_edit_options"
            else:
                return state, metadata, "Please type 'confirm' to save or 'edit' to modify"
        
        return state, metadata, None
    
    def parse_columns(self, col_string: str) -> List[Dict[str, str]]:
        """Parse column string format: 'col1:type1, col2:type2'"""
        try:
            columns = []
            for col in col_string.split(','):
                if ':' in col:
                    name, dtype = col.strip().split(':', 1)
                    columns.append({
                        "name": name.strip(),
                        "type": dtype.strip()
                    })
            return columns if columns else None
        except Exception as e:
            return None


def initialize_session_state():
    """Initialize Streamlit session state"""
    if 'bot' not in st.session_state:
        st.session_state.bot = MetadataConversationBot()
    
    if 'conversation_state' not in st.session_state:
        st.session_state.conversation_state = "welcome"
    
    if 'metadata' not in st.session_state:
        st.session_state.metadata = {}
    
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []
    
    if 'show_dq_form' not in st.session_state:
        st.session_state.show_dq_form = False
    
    if 'show_transform_form' not in st.session_state:
        st.session_state.show_transform_form = False


def display_chat_message(role: str, message: str):
    """Display a chat message"""
    css_class = "user-message" if role == "user" else "bot-message"
    icon = "👤" if role == "user" else "🤖"
    st.markdown(f"""
    <div class="chat-message {css_class}">
        <div><strong>{icon} {role.title()}</strong></div>
        <div>{message}</div>
    </div>
    """, unsafe_allow_html=True)


def render_data_quality_form():
    """Render form for adding data quality rules"""
    st.subheader("Add Data Quality Rule")
    
    with st.form("dq_form", clear_on_submit=True):
        col1, col2 = st.columns(2)
        
        with col1:
            column_name = st.text_input("Column Name", key="dq_column")
            rule_type = st.selectbox(
                "Rule Type",
                ["null_check", "unique_check", "format_validation", "range_check", "value_in_list"],
                key="dq_rule_type"
            )
        
        with col2:
            if rule_type == "range_check":
                min_val = st.text_input("Min Value", key="dq_min")
                max_val = st.text_input("Max Value", key="dq_max")
                rule_config = {"min": min_val, "max": max_val}
            elif rule_type == "format_validation":
                pattern = st.text_input("Regex Pattern", key="dq_pattern")
                rule_config = {"pattern": pattern}
            elif rule_type == "value_in_list":
                allowed_values = st.text_input("Allowed Values (comma-separated)", key="dq_values")
                rule_config = {"allowed_values": allowed_values.split(',')}
            else:
                rule_config = {}
        
        submitted = st.form_submit_button("Add Rule")
        
        if submitted and column_name:
            rule = {
                "column_name": column_name,
                "rule_type": rule_type,
                "rule_config": rule_config
            }
            
            if 'data_quality_rules' not in st.session_state.metadata:
                st.session_state.metadata['data_quality_rules'] = []
            
            st.session_state.metadata['data_quality_rules'].append(rule)
            st.session_state.show_dq_form = False
            st.session_state.conversation_state = "add_more_dq"
            st.success(f"✅ Rule added for column: {column_name}")
            st.rerun()


def render_transformation_form():
    """Render form for adding transformations"""
    st.subheader("Add Transformation")
    
    with st.form("transform_form", clear_on_submit=True):
        col1, col2 = st.columns(2)
        
        with col1:
            transformation_type = st.selectbox(
                "Transformation Type",
                ["cast", "rename", "derive", "filter", "aggregate"],
                key="trans_type"
            )
        
        with col2:
            column_name = st.text_input("Column Name", key="trans_column")
        
        if transformation_type == "cast":
            target_type = st.selectbox(
                "Target Data Type",
                ["string", "int", "bigint", "double", "timestamp", "date", "boolean"],
                key="trans_cast_type"
            )
            logic = f"cast({column_name} as {target_type})"
        
        elif transformation_type == "rename":
            new_name = st.text_input("New Column Name", key="trans_new_name")
            logic = f"{column_name} as {new_name}"
        
        elif transformation_type == "derive":
            expression = st.text_area(
                "SQL Expression",
                placeholder="e.g., col1 + col2, CASE WHEN col1 > 0 THEN 'positive' ELSE 'negative' END",
                key="trans_expression"
            )
            logic = expression
        
        elif transformation_type == "filter":
            condition = st.text_area(
                "Filter Condition",
                placeholder="e.g., status = 'active' AND amount > 100",
                key="trans_filter"
            )
            logic = condition
        
        else:  # aggregate
            agg_func = st.selectbox(
                "Aggregation Function",
                ["sum", "avg", "count", "min", "max"],
                key="trans_agg_func"
            )
            logic = f"{agg_func}({column_name})"
        
        submitted = st.form_submit_button("Add Transformation")
        
        if submitted and column_name:
            transformation = {
                "column_name": column_name,
                "transformation_type": transformation_type,
                "transformation_logic": logic
            }
            
            if 'transformations' not in st.session_state.metadata:
                st.session_state.metadata['transformations'] = []
            
            st.session_state.metadata['transformations'].append(transformation)
            st.session_state.show_transform_form = False
            st.session_state.conversation_state = "add_more_transformations"
            st.success(f"✅ Transformation added: {transformation_type} on {column_name}")
            st.rerun()


def render_schema_upload():
    """Render file upload for schema"""
    st.subheader("Upload Schema CSV")
    st.info("Upload a CSV file with columns: column_name, data_type")
    
    uploaded_file = st.file_uploader("Choose a CSV file", type=['csv'], key="schema_upload")
    
    if uploaded_file is not None:
        try:
            df = pd.read_csv(uploaded_file)
            if 'column_name' in df.columns and 'data_type' in df.columns:
                columns = [
                    {"name": row['column_name'], "type": row['data_type']}
                    for _, row in df.iterrows()
                ]
                st.session_state.metadata['source']['source_columns'] = columns
                st.session_state.conversation_state = "data_quality_rules"
                st.success(f"✅ Schema loaded: {len(columns)} columns")
                st.rerun()
            else:
                st.error("CSV must have 'column_name' and 'data_type' columns")
        except Exception as e:
            st.error(f"Error reading CSV: {str(e)}")


def render_metadata_review():
    """Render metadata review section"""
    st.subheader("📋 Metadata Review")
    
    metadata = st.session_state.metadata
    
    # Display as formatted JSON
    st.json(metadata)
    
    # Show summary
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Source Columns", len(metadata.get('source', {}).get('source_columns', [])))
    
    with col2:
        st.metric("DQ Rules", len(metadata.get('data_quality_rules', [])))
    
    with col3:
        st.metric("Transformations", len(metadata.get('transformations', [])))


def save_metadata_to_file(metadata: Dict, format: str = 'json'):
    """Save metadata to file"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    pipeline_name = metadata.get('pipeline_name', 'pipeline')
    
    if format == 'json':
        filename = f"{pipeline_name}_{timestamp}.json"
        content = json.dumps(metadata, indent=2)
    else:  # excel
        filename = f"{pipeline_name}_{timestamp}.xlsx"
        # Convert to Excel format (placeholder)
        content = "Excel export not implemented yet"
    
    return filename, content


def main():
    """Main application"""
    initialize_session_state()
    
    # Header
    st.markdown('<div class="main-header">🤖 Pipeline Metadata Builder</div>', unsafe_allow_html=True)
    st.markdown("---")
    
    # Sidebar
    with st.sidebar:
        st.header("📊 Progress")
        
        total_states = len(st.session_state.bot.states)
        current_index = st.session_state.bot.states.index(st.session_state.conversation_state) if st.session_state.conversation_state in st.session_state.bot.states else 0
        progress = current_index / total_states
        
        st.progress(progress)
        st.write(f"Step {current_index + 1} of {total_states}")
        st.write(f"**Current:** {st.session_state.conversation_state.replace('_', ' ').title()}")
        
        st.markdown("---")
        
        if st.session_state.metadata:
            st.header("📝 Current Metadata")
            with st.expander("View Metadata", expanded=False):
                st.json(st.session_state.metadata)
        
        st.markdown("---")
        
        if st.button("🔄 Start Over"):
            st.session_state.conversation_state = "welcome"
            st.session_state.metadata = {}
            st.session_state.chat_history = []
            st.rerun()
        
        if st.session_state.metadata and st.button("💾 Export JSON"):
            filename, content = save_metadata_to_file(st.session_state.metadata)
            st.download_button(
                label="Download JSON",
                data=content,
                file_name=filename,
                mime="application/json"
            )
    
    # Main chat area
    chat_container = st.container()
    
    with chat_container:
        # Display chat history
        for message in st.session_state.chat_history:
            display_chat_message(message['role'], message['content'])
        
        # Display current bot prompt
        if st.session_state.conversation_state != "complete":
            current_prompt = st.session_state.bot.get_prompt(
                st.session_state.conversation_state,
                st.session_state.metadata
            )
            display_chat_message("bot", current_prompt)
        
        # Show metadata review
        if st.session_state.conversation_state == "review":
            render_metadata_review()
        
        # Show DQ form if needed
        if st.session_state.show_dq_form:
            render_data_quality_form()
        
        # Show transformation form if needed
        if st.session_state.show_transform_form:
            render_transformation_form()
    
    # Input area
    if st.session_state.conversation_state not in ["complete"]:
        with st.form("user_input_form", clear_on_submit=True):
            col1, col2 = st.columns([4, 1])
            
            with col1:
                user_input = st.text_input(
                    "Your response:",
                    key="user_input",
                    label_visibility="collapsed",
                    placeholder="Type your response here..."
                )
            
            with col2:
                submitted = st.form_submit_button("Send", use_container_width=True)
            
            if submitted and user_input:
                # Add user message to history
                st.session_state.chat_history.append({
                    "role": "user",
                    "content": user_input
                })
                
                # Process input
                new_state, updated_metadata, action = st.session_state.bot.process_input(
                    st.session_state.conversation_state,
                    user_input,
                    st.session_state.metadata
                )
                
                st.session_state.metadata = updated_metadata
                
                # Handle special actions
                if action == "show_dq_form":
                    st.session_state.show_dq_form = True
                elif action == "show_transform_form":
                    st.session_state.show_transform_form = True
                elif action == "upload_schema":
                    render_schema_upload()
                elif action == "save_metadata":
                    st.success("✅ Metadata saved successfully!")
                elif action and action.startswith("Invalid") or action == "Please type":
                    st.session_state.chat_history.append({
                        "role": "bot",
                        "content": action
                    })
                
                st.session_state.conversation_state = new_state
                st.rerun()
    
    else:
        # Completion state
        st.success("✅ Pipeline metadata created successfully!")
        
        col1, col2 = st.columns(2)
        
        with col1:
            filename, content = save_metadata_to_file(st.session_state.metadata)
            st.download_button(
                label="📥 Download JSON",
                data=content,
                file_name=filename,
                mime="application/json",
                use_container_width=True
            )
        
        with col2:
            if st.button("🔄 Create Another Pipeline", use_container_width=True):
                st.session_state.conversation_state = "welcome"
                st.session_state.metadata = {}
                st.session_state.chat_history = []
                st.rerun()


if __name__ == "__main__":
    main()
