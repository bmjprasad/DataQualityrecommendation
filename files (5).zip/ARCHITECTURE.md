# Pipeline Metadata Builder - Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                     USER INTERFACE (Streamlit)                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │   Welcome    │→ │   Pipeline   │→ │    Source    │→  ...    │
│  │    Screen    │  │     Info     │  │    Config    │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                   CONVERSATION BOT ENGINE                        │
│  • State Management                                              │
│  • Validation Logic                                              │
│  • JSON Generation                                               │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                      DATA MODELS                                 │
│  ┌────────────┐  ┌────────────┐  ┌──────────────┐              │
│  │   Source   │  │ DataQuality│  │Transformation│              │
│  │  Metadata  │  │    Rules   │  │              │              │
│  └────────────┘  └────────────┘  └──────────────┘              │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                   JSON CONFIGURATION                             │
│  {                                                               │
│    "pipeline_id": "...",                                         │
│    "source": {...},                                              │
│    "data_quality_rules": [...],                                  │
│    "transformations": [...],                                     │
│    "target": {...}                                               │
│  }                                                               │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│              DATABRICKS DELTA TABLE STORAGE                      │
│                                                                  │
│  ┌────────────────────────────────────────────────────┐         │
│  │  metadata.pipeline_configs (Delta Table)           │         │
│  │  • pipeline_id (PK)                                │         │
│  │  • pipeline_name                                   │         │
│  │  • source (struct)                                 │         │
│  │  • data_quality_rules (array)                      │         │
│  │  • transformations (array)                         │         │
│  │  • target (struct)                                 │         │
│  │  • created_at, updated_at                          │         │
│  └────────────────────────────────────────────────────┘         │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                  SPARK PIPELINE EXECUTION                        │
│  1. Read metadata from Delta table                              │
│  2. Load source data based on config                            │
│  3. Apply data quality checks                                   │
│  4. Execute transformations                                      │
│  5. Write to target table                                       │
└─────────────────────────────────────────────────────────────────┘
```

## Component Flow

### 1. Metadata Collection (Streamlit App)

```
User Input → Conversation Bot → State Management → Validation
                                                        ↓
                                              Data Model Creation
                                                        ↓
                                                JSON Generation
```

### 2. Storage Flow

```
JSON Config → MetadataDeltaStorage → PySpark DataFrame → Delta Table
```

### 3. Pipeline Execution Flow

```
Delta Table → Read Metadata → Build Spark Pipeline → Execute → Monitor
```

## Data Flow Diagram

```
┌─────────────┐
│  Excel      │
│  Template   │──┐
└─────────────┘  │
                 │  REPLACED BY
┌─────────────┐  │
│ Streamlit   │←─┘
│    App      │
└──────┬──────┘
       │ User interactions
       ↓
┌──────────────────────────────────────┐
│   Conversation States:                │
│   1. Welcome                          │
│   2. Pipeline Info                    │
│   3. Source System                    │
│   4. Source Columns                   │
│   5. Data Quality Rules               │
│   6. Transformations                  │
│   7. Target Config                    │
│   8. Review                           │
│   9. Generate JSON                    │
└──────┬───────────────────────────────┘
       │
       ↓
┌──────────────┐
│ JSON Config  │
└──────┬───────┘
       │
       ↓
┌─────────────────────────────────────┐
│  Databricks Delta Table              │
│  (metadata.pipeline_configs)         │
└──────┬──────────────────────────────┘
       │
       ↓
┌─────────────────────────────────────┐
│  Spark Job reads metadata            │
│  and executes pipeline               │
└─────────────────────────────────────┘
```

## Integration Points

### Input Sources
1. **Manual Entry**: Step-by-step form filling
2. **Bulk Import**: Paste from Excel
3. **Schema Inference**: Auto-detect from files
4. **Template Import**: Load predefined templates

### Output Destinations
1. **JSON File**: Download locally
2. **Delta Table**: Direct save to Databricks
3. **API**: REST API integration (future)
4. **Git**: Version control (future)

## Technology Stack

```
┌─────────────────────────────────────────────┐
│              Frontend Layer                  │
│  • Streamlit (Python web framework)         │
│  • Pandas (Data manipulation)               │
└─────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────┐
│            Business Logic Layer              │
│  • Python dataclasses (Data models)         │
│  • JSON (Serialization)                     │
│  • Custom validation logic                  │
└─────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────┐
│             Storage Layer                    │
│  • PySpark (Data processing)                │
│  • Delta Lake (Storage format)              │
│  • Databricks (Platform)                    │
└─────────────────────────────────────────────┘
```

## Deployment Architecture

```
┌──────────────────────────────────────────────────────────┐
│                    Developer Workstation                  │
│                                                           │
│  ┌────────────────┐         ┌──────────────┐            │
│  │  Streamlit     │         │  Python      │            │
│  │  Application   │◄────────┤  Scripts     │            │
│  └───────┬────────┘         └──────────────┘            │
│          │                                                │
└──────────┼────────────────────────────────────────────────┘
           │
           │ HTTPS
           ↓
┌──────────────────────────────────────────────────────────┐
│              Databricks Workspace                         │
│                                                           │
│  ┌────────────────────────────────────────────┐          │
│  │  Unity Catalog                              │          │
│  │  └── metadata (catalog)                     │          │
│  │      └── pipeline_configs (schema)          │          │
│  │          └── pipeline_configs (table)       │          │
│  └────────────────────────────────────────────┘          │
│                                                           │
│  ┌────────────────────────────────────────────┐          │
│  │  Spark Clusters                             │          │
│  │  • Read metadata                            │          │
│  │  • Execute pipelines                        │          │
│  │  • Write results                            │          │
│  └────────────────────────────────────────────┘          │
└──────────────────────────────────────────────────────────┘
```

## Security Considerations

```
┌──────────────────────────────────────────────────────────┐
│                  Security Layers                          │
│                                                           │
│  1. Authentication                                        │
│     • Databricks Personal Access Token                   │
│     • Service Principal (Azure AD)                       │
│     • AWS IAM Roles                                      │
│                                                           │
│  2. Authorization                                         │
│     • Unity Catalog Permissions                          │
│     • Table-level Access Control                         │
│     • Row/Column-level Security                          │
│                                                           │
│  3. Data Protection                                       │
│     • Encryption at Rest (Delta Lake)                    │
│     • Encryption in Transit (TLS/SSL)                    │
│     • Audit Logging                                      │
│                                                           │
│  4. Network Security                                      │
│     • VPC/VNet Integration                               │
│     • Private Link                                       │
│     • IP Whitelisting                                    │
└──────────────────────────────────────────────────────────┘
```

## Scalability & Performance

```
Component               Scalability Strategy
──────────────────────  ───────────────────────────────────
Streamlit App           • Horizontal scaling with load balancer
                        • Session state optimization
                        • Caching of common queries

Delta Storage           • Partitioning by date/category
                        • Z-ordering for query performance
                        • Auto-compaction
                        • Liquid clustering (future)

Spark Execution         • Cluster auto-scaling
                        • Adaptive query execution
                        • Dynamic partition pruning
                        • Photon acceleration
```

## Monitoring & Observability

```
┌────────────────────────────────────────────────────────┐
│                 Monitoring Stack                        │
│                                                         │
│  Application Level:                                     │
│  • Streamlit metrics (session count, response time)    │
│  • Error tracking and logging                          │
│                                                         │
│  Data Level:                                            │
│  • Pipeline execution metrics                          │
│  • Data quality check results                          │
│  • Record counts and data volumes                      │
│                                                         │
│  Infrastructure Level:                                  │
│  • Databricks cluster metrics                          │
│  • Job run history                                     │
│  • Resource utilization                                │
└────────────────────────────────────────────────────────┘
```

## Future Enhancements

```
Phase 2: Enhanced Features
├── AI-powered metadata suggestions
├── Schema drift detection
├── Automated testing of configurations
└── Visual pipeline builder

Phase 3: Collaboration
├── Multi-user editing with conflict resolution
├── Version control and rollback
├── Approval workflows
└── Comments and annotations

Phase 4: Advanced Integration
├── REST API for programmatic access
├── CI/CD pipeline integration
├── Integration with data catalogs (Alation, Collibra)
└── Real-time collaboration features
```
