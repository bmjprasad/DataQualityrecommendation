"""
Example Usage and Test Cases for Pipeline Metadata Builder
"""

import json
from datetime import datetime

# Example 1: Simple Sales Pipeline Metadata
example_sales_pipeline = {
    "pipeline_id": "pipeline_20240101_120000",
    "pipeline_name": "sales_etl_pipeline",
    "source": {
        "source_name": "sales_database",
        "source_location": "s3://company-data-lake/raw/sales/",
        "source_columns": [
            {"name": "order_id", "type": "int"},
            {"name": "customer_id", "type": "int"},
            {"name": "amount", "type": "double"},
            {"name": "order_date", "type": "timestamp"},
            {"name": "status", "type": "string"}
        ],
        "file_format": "parquet"
    },
    "data_quality_rules": [
        {
            "column_name": "order_id",
            "rule_type": "null_check",
            "rule_config": {}
        },
        {
            "column_name": "order_id",
            "rule_type": "unique_check",
            "rule_config": {}
        },
        {
            "column_name": "amount",
            "rule_type": "range_check",
            "rule_config": {"min": "0", "max": "1000000"}
        },
        {
            "column_name": "status",
            "rule_type": "value_in_list",
            "rule_config": {"allowed_values": ["pending", "completed", "cancelled"]}
        }
    ],
    "transformations": [
        {
            "column_name": "order_date",
            "transformation_type": "cast",
            "transformation_logic": "cast(order_date as date)"
        },
        {
            "column_name": "amount_usd",
            "transformation_type": "derive",
            "transformation_logic": "amount * 1.0"
        }
    ],
    "target": {
        "target_table": "sales_fact",
        "target_database": "analytics",
        "sync_mode": "append",
        "merge_keys": []
    },
    "created_at": "2024-01-01T12:00:00",
    "created_by": "data_engineer",
    "is_active": True
}

# Example 2: Customer Dimension with Merge
example_customer_dimension = {
    "pipeline_id": "pipeline_20240101_130000",
    "pipeline_name": "customer_dimension_sync",
    "source": {
        "source_name": "customer_api",
        "source_location": "/dbfs/mnt/data/customers/",
        "source_columns": [
            {"name": "customer_id", "type": "string"},
            {"name": "first_name", "type": "string"},
            {"name": "last_name", "type": "string"},
            {"name": "email", "type": "string"},
            {"name": "phone", "type": "string"},
            {"name": "created_at", "type": "timestamp"},
            {"name": "updated_at", "type": "timestamp"}
        ],
        "file_format": "json"
    },
    "data_quality_rules": [
        {
            "column_name": "customer_id",
            "rule_type": "null_check",
            "rule_config": {}
        },
        {
            "column_name": "email",
            "rule_type": "format_validation",
            "rule_config": {"pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"}
        }
    ],
    "transformations": [
        {
            "column_name": "full_name",
            "transformation_type": "derive",
            "transformation_logic": "CONCAT(first_name, ' ', last_name)"
        },
        {
            "column_name": "phone",
            "transformation_type": "cast",
            "transformation_logic": "cast(phone as string)"
        }
    ],
    "target": {
        "target_table": "dim_customer",
        "target_database": "analytics",
        "sync_mode": "merge",
        "merge_keys": ["customer_id"]
    },
    "created_at": "2024-01-01T13:00:00",
    "created_by": "data_engineer",
    "is_active": True
}

# Example 3: Log Processing Pipeline
example_log_processing = {
    "pipeline_id": "pipeline_20240101_140000",
    "pipeline_name": "application_logs_processing",
    "source": {
        "source_name": "application_logs",
        "source_location": "s3://logs-bucket/application/",
        "source_columns": [
            {"name": "timestamp", "type": "timestamp"},
            {"name": "log_level", "type": "string"},
            {"name": "message", "type": "string"},
            {"name": "user_id", "type": "string"},
            {"name": "session_id", "type": "string"},
            {"name": "ip_address", "type": "string"}
        ],
        "file_format": "csv"
    },
    "data_quality_rules": [
        {
            "column_name": "timestamp",
            "rule_type": "null_check",
            "rule_config": {}
        },
        {
            "column_name": "log_level",
            "rule_type": "value_in_list",
            "rule_config": {"allowed_values": ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]}
        }
    ],
    "transformations": [
        {
            "column_name": "filtered_logs",
            "transformation_type": "filter",
            "transformation_logic": "log_level IN ('ERROR', 'CRITICAL')"
        },
        {
            "column_name": "log_date",
            "transformation_type": "derive",
            "transformation_logic": "DATE(timestamp)"
        }
    ],
    "target": {
        "target_table": "error_logs",
        "target_database": "monitoring",
        "sync_mode": "append",
        "merge_keys": []
    },
    "created_at": "2024-01-01T14:00:00",
    "created_by": "devops_engineer",
    "is_active": True
}


def save_examples_to_files():
    """Save example metadata to JSON files"""
    examples = [
        (example_sales_pipeline, "example_sales_pipeline.json"),
        (example_customer_dimension, "example_customer_dimension.json"),
        (example_log_processing, "example_log_processing.json")
    ]
    
    for example, filename in examples:
        with open(filename, 'w') as f:
            json.dump(example, f, indent=2)
        print(f"✅ Created {filename}")


# Test cases for the bot
def test_column_parsing():
    """Test column string parsing"""
    from metadata_bot_app import MetadataConversationBot
    
    bot = MetadataConversationBot()
    
    # Test valid input
    result = bot.parse_columns("id:int, name:string, amount:double")
    assert len(result) == 3
    assert result[0] == {"name": "id", "type": "int"}
    print("✅ Column parsing test passed")
    
    # Test with spaces
    result = bot.parse_columns("  id : int ,  name : string  ")
    assert len(result) == 2
    print("✅ Column parsing with spaces test passed")


def test_state_transitions():
    """Test conversation state transitions"""
    from metadata_bot_app import MetadataConversationBot
    
    bot = MetadataConversationBot()
    metadata = {}
    
    # Test welcome -> pipeline_name
    new_state, _, _ = bot.process_input("welcome", "yes", metadata)
    assert new_state == "pipeline_name"
    print("✅ Welcome state transition passed")
    
    # Test pipeline_name -> source_name
    new_state, metadata, _ = bot.process_input("pipeline_name", "test_pipeline", metadata)
    assert new_state == "source_name"
    assert metadata["pipeline_name"] == "test_pipeline"
    print("✅ Pipeline name state transition passed")


def generate_sample_schema_csv():
    """Generate a sample schema CSV file for testing"""
    import pandas as pd
    
    schema_data = {
        'column_name': ['order_id', 'customer_id', 'amount', 'order_date', 'status'],
        'data_type': ['int', 'int', 'double', 'timestamp', 'string']
    }
    
    df = pd.DataFrame(schema_data)
    df.to_csv('sample_schema.csv', index=False)
    print("✅ Created sample_schema.csv")


if __name__ == "__main__":
    print("=" * 60)
    print("Pipeline Metadata Builder - Examples and Tests")
    print("=" * 60)
    
    # Save examples
    print("\n📝 Generating example JSON files...")
    save_examples_to_files()
    
    # Generate sample CSV
    print("\n📊 Generating sample schema CSV...")
    generate_sample_schema_csv()
    
    # Run tests
    print("\n🧪 Running tests...")
    try:
        test_column_parsing()
        test_state_transitions()
        print("\n✅ All tests passed!")
    except Exception as e:
        print(f"\n❌ Test failed: {str(e)}")
    
    print("\n" + "=" * 60)
    print("Example metadata files created successfully!")
    print("You can use these as templates for your pipelines.")
    print("=" * 60)
