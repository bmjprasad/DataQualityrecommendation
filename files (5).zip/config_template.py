"""
Configuration Template for Pipeline Metadata Builder

Customize these settings for your Databricks environment
"""

# Databricks Connection Settings
DATABRICKS_CONFIG = {
    # Unity Catalog settings
    "catalog": "metadata",
    "schema": "pipeline_configs",
    "table_name": "pipeline_configs",
    
    # Databricks workspace URL (optional, for API integration)
    "workspace_url": "https://your-workspace.cloud.databricks.com",
    
    # Authentication (optional, for API integration)
    # Option 1: Use personal access token
    "auth_token": None,  # Set to your token or use env variable
    
    # Option 2: Use service principal
    "client_id": None,
    "client_secret": None,
    "tenant_id": None,
}

# Default Pipeline Settings
DEFAULT_PIPELINE_SETTINGS = {
    "default_target_database": "bronze",
    "default_sync_mode": "append",
    "default_file_format": "parquet",
    "enable_schema_evolution": True,
    "enable_data_quality": True,
}

# Data Quality Rule Templates
DQ_RULE_TEMPLATES = {
    "not_null": {
        "name": "Not Null Check",
        "description": "Ensures column has no null values",
        "default_threshold": 0.0
    },
    "unique": {
        "name": "Uniqueness Check", 
        "description": "Ensures all values are unique",
        "default_threshold": 0.0
    },
    "valid_values": {
        "name": "Valid Values Check",
        "description": "Ensures values are in allowed list",
        "default_threshold": 0.0
    },
    "regex_match": {
        "name": "Regex Pattern Match",
        "description": "Validates against regex pattern",
        "default_threshold": 2.0
    },
    "range_check": {
        "name": "Range Validation",
        "description": "Ensures values are within range",
        "default_threshold": 1.0
    },
    "length_check": {
        "name": "Length Validation",
        "description": "Validates string length",
        "default_threshold": 2.0
    },
    "date_format": {
        "name": "Date Format Validation",
        "description": "Ensures dates match format",
        "default_threshold": 0.0
    },
    "custom_sql": {
        "name": "Custom SQL Check",
        "description": "Custom SQL expression",
        "default_threshold": 5.0
    }
}

# Transformation Type Templates
TRANSFORMATION_TEMPLATES = {
    "cast": {
        "name": "Type Cast",
        "description": "Convert data type",
        "example": "CAST(column AS INT)"
    },
    "rename": {
        "name": "Rename Column",
        "description": "Rename a column",
        "example": "old_name AS new_name"
    },
    "derive": {
        "name": "Derive Column",
        "description": "Create new column from expression",
        "example": "column_a + column_b AS total"
    },
    "filter": {
        "name": "Filter Rows",
        "description": "Filter based on condition",
        "example": "WHERE column > 100"
    },
    "aggregate": {
        "name": "Aggregation",
        "description": "Aggregate data",
        "example": "GROUP BY column, SUM(value)"
    },
    "join": {
        "name": "Join",
        "description": "Join with another dataset",
        "example": "JOIN table ON key"
    },
    "custom_sql": {
        "name": "Custom SQL",
        "description": "Custom SQL transformation",
        "example": "CASE WHEN ... THEN ... END"
    }
}

# Supported File Formats
SUPPORTED_FILE_FORMATS = [
    "parquet",
    "csv", 
    "json",
    "delta",
    "avro",
    "orc",
    "text"
]

# Supported Data Types
SUPPORTED_DATA_TYPES = [
    "string",
    "int",
    "bigint",
    "smallint",
    "tinyint",
    "double",
    "float",
    "decimal",
    "boolean",
    "timestamp",
    "date",
    "binary",
    "array",
    "map",
    "struct"
]

# Sync Modes
SYNC_MODES = [
    "append",    # Add new records
    "overwrite", # Replace all data
    "merge"      # Upsert based on keys
]

# Common Read Options by Format
READ_OPTIONS_TEMPLATES = {
    "csv": {
        "header": "true",
        "delimiter": ",",
        "quote": '"',
        "escape": "\\",
        "inferSchema": "false",
        "nullValue": "",
        "dateFormat": "yyyy-MM-dd"
    },
    "json": {
        "multiline": "false",
        "mode": "PERMISSIVE",
        "dateFormat": "yyyy-MM-dd"
    },
    "parquet": {
        "mergeSchema": "false"
    },
    "delta": {
        "mergeSchema": "false",
        "timestampAsOf": None,
        "versionAsOf": None
    }
}

# UI Customization
UI_CONFIG = {
    "app_title": "Pipeline Metadata Builder",
    "app_icon": "🤖",
    "theme": "light",  # or "dark"
    "sidebar_state": "expanded",  # or "collapsed"
    "layout": "wide",  # or "centered"
}

# Validation Rules
VALIDATION_CONFIG = {
    "require_pipeline_name": True,
    "require_description": False,
    "require_tags": False,
    "min_columns": 1,
    "max_columns": 1000,
    "require_dq_rules": False,
    "require_transformations": False,
    "validate_column_names": True,  # Check for special characters
    "validate_sql_syntax": False,   # Basic SQL validation
}

# Export Settings
EXPORT_CONFIG = {
    "json_indent": 2,
    "include_timestamps": True,
    "include_metadata": True,
    "prettify_output": True,
}

# Logging Configuration
LOGGING_CONFIG = {
    "enable_logging": True,
    "log_level": "INFO",  # DEBUG, INFO, WARNING, ERROR
    "log_file": "metadata_builder.log",
    "log_format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
}

# Feature Flags
FEATURE_FLAGS = {
    "enable_ai_suggestions": False,      # Future: AI-powered suggestions
    "enable_schema_inference": True,     # Infer schema from files
    "enable_preview": False,             # Preview data before saving
    "enable_version_control": False,     # Future: Version tracking
    "enable_collaboration": False,       # Future: Multi-user editing
    "enable_templates": True,            # Use predefined templates
    "enable_import_export": True,        # Import/export configurations
    "enable_api_integration": False,     # Direct Databricks API calls
}

# Common Column Name Patterns
COLUMN_NAME_PATTERNS = {
    "primary_keys": ["id", "_id", "_key", "pk_"],
    "timestamps": ["created_at", "updated_at", "timestamp", "_ts", "_date"],
    "soft_delete": ["is_deleted", "deleted_at", "is_active"],
    "audit_columns": ["created_by", "updated_by", "modified_by"],
    "partition_candidates": ["year", "month", "day", "date", "event_date"]
}

# Environment-specific Settings
ENVIRONMENT_CONFIGS = {
    "dev": {
        "catalog": "dev_metadata",
        "workspace_url": "https://dev-workspace.cloud.databricks.com"
    },
    "staging": {
        "catalog": "staging_metadata", 
        "workspace_url": "https://staging-workspace.cloud.databricks.com"
    },
    "prod": {
        "catalog": "prod_metadata",
        "workspace_url": "https://prod-workspace.cloud.databricks.com"
    }
}

# Current environment (change as needed)
CURRENT_ENVIRONMENT = "dev"


def get_config(environment: str = None):
    """
    Get configuration for specified environment
    
    Args:
        environment: Environment name (dev, staging, prod)
        
    Returns:
        Dictionary with environment-specific configuration
    """
    env = environment or CURRENT_ENVIRONMENT
    
    config = DATABRICKS_CONFIG.copy()
    
    if env in ENVIRONMENT_CONFIGS:
        config.update(ENVIRONMENT_CONFIGS[env])
    
    return config


def validate_config():
    """Validate that required configuration is set"""
    
    errors = []
    
    if not DATABRICKS_CONFIG.get("catalog"):
        errors.append("Databricks catalog not configured")
    
    if not DATABRICKS_CONFIG.get("schema"):
        errors.append("Databricks schema not configured")
    
    return len(errors) == 0, errors


if __name__ == "__main__":
    print("Configuration Template")
    print("=" * 60)
    
    is_valid, errors = validate_config()
    
    if is_valid:
        print("✅ Configuration is valid")
    else:
        print("❌ Configuration errors:")
        for error in errors:
            print(f"  - {error}")
    
    print(f"\nCurrent Environment: {CURRENT_ENVIRONMENT}")
    print(f"Catalog: {DATABRICKS_CONFIG['catalog']}")
    print(f"Schema: {DATABRICKS_CONFIG['schema']}")
    print(f"Table: {DATABRICKS_CONFIG['table_name']}")
