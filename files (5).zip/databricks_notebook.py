# Databricks notebook source
# MAGIC %md
# MAGIC # Pipeline Metadata Builder - Databricks Notebook
# MAGIC 
# MAGIC This notebook sets up and runs the Pipeline Metadata Builder Streamlit app in Databricks.
# MAGIC 
# MAGIC ## Setup Steps:
# MAGIC 1. Install required libraries
# MAGIC 2. Create metadata table
# MAGIC 3. Upload application files
# MAGIC 4. Run Streamlit app

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Install Required Libraries

# COMMAND ----------

# MAGIC %pip install streamlit pandas delta-spark

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Create Metadata Table

# COMMAND ----------

from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

# Create catalog and schema
spark.sql("CREATE CATALOG IF NOT EXISTS metadata")
spark.sql("CREATE SCHEMA IF NOT EXISTS metadata.pipeline_configs")

# Create metadata table
create_table_ddl = """
CREATE TABLE IF NOT EXISTS metadata.pipeline_configs.pipeline_metadata (
    pipeline_id STRING,
    pipeline_name STRING,
    source STRUCT<
        source_name: STRING,
        source_location: STRING,
        source_columns: ARRAY<STRUCT<name: STRING, type: STRING>>,
        file_format: STRING
    >,
    data_quality_rules ARRAY<STRUCT<
        column_name: STRING,
        rule_type: STRING,
        rule_config: MAP<STRING, STRING>
    >>,
    transformations ARRAY<STRUCT<
        column_name: STRING,
        transformation_type: STRING,
        transformation_logic: STRING
    >>,
    target STRUCT<
        target_table: STRING,
        target_database: STRING,
        sync_mode: STRING,
        merge_keys: ARRAY<STRING>
    >,
    created_at TIMESTAMP,
    created_by STRING,
    updated_at TIMESTAMP,
    is_active BOOLEAN
) USING DELTA
"""

spark.sql(create_table_ddl)
print("✅ Metadata table created successfully!")

# COMMAND ----------

# Verify table creation
display(spark.sql("DESCRIBE EXTENDED metadata.pipeline_configs.pipeline_metadata"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Upload Application Files
# MAGIC 
# MAGIC Upload the following files to DBFS:
# MAGIC - metadata_bot_app.py
# MAGIC - databricks_integration.py
# MAGIC - requirements.txt

# COMMAND ----------

# Create directory
dbutils.fs.mkdirs("/apps/metadata-builder/")

# List files (after uploading manually or via CLI)
display(dbutils.fs.ls("/apps/metadata-builder/"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Test Databricks Integration

# COMMAND ----------

# Test the DatabricksMetadataManager
import sys
sys.path.append("/dbfs/apps/metadata-builder/")

from databricks_integration import DatabricksMetadataManager
from datetime import datetime

# Initialize manager
metadata_manager = DatabricksMetadataManager(
    spark=spark,
    catalog="metadata",
    schema="pipeline_configs"
)

# Create test metadata
test_metadata = {
    "pipeline_id": f"pipeline_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
    "pipeline_name": "test_pipeline",
    "source": {
        "source_name": "test_source",
        "source_location": "s3://test-bucket/data/",
        "source_columns": [
            {"name": "id", "type": "int"},
            {"name": "name", "type": "string"}
        ],
        "file_format": "parquet"
    },
    "data_quality_rules": [],
    "transformations": [],
    "target": {
        "target_table": "test_table",
        "target_database": "test_db",
        "sync_mode": "append",
        "merge_keys": []
    },
    "created_at": datetime.now().isoformat(),
    "created_by": "databricks_user",
    "is_active": True
}

# Save test metadata
pipeline_id = metadata_manager.save_metadata(test_metadata)
print(f"✅ Test metadata saved: {pipeline_id}")

# COMMAND ----------

# Retrieve and display the test metadata
retrieved = metadata_manager.get_metadata(pipeline_id)
print(retrieved)

# COMMAND ----------

# List all pipelines
all_pipelines = metadata_manager.list_all_pipelines()
print(f"Total active pipelines: {len(all_pipelines)}")

# COMMAND ----------

# Display pipelines in table format
display(spark.sql("""
SELECT 
    pipeline_id,
    pipeline_name,
    source.source_name,
    source.file_format,
    target.target_table,
    created_at,
    is_active
FROM metadata.pipeline_configs.pipeline_metadata
ORDER BY created_at DESC
"""))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Run Streamlit App
# MAGIC 
# MAGIC **Note**: This runs the Streamlit app on the driver node. Access via driver proxy.

# COMMAND ----------

# MAGIC %sh
# MAGIC cd /dbfs/apps/metadata-builder/
# MAGIC nohup streamlit run metadata_bot_app.py --server.port 8501 --server.address 0.0.0.0 &

# COMMAND ----------

# Get the driver proxy URL
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
org_id = context.tags().get("orgId").get()
cluster_id = context.tags().get("clusterId").get()

streamlit_url = f"https://{spark.conf.get('spark.databricks.workspaceUrl')}/driver-proxy/o/{org_id}/{cluster_id}/8501/"
print(f"🚀 Streamlit App URL: {streamlit_url}")

displayHTML(f'<a href="{streamlit_url}" target="_blank">Open Metadata Builder App</a>')

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Using Metadata in Data Pipelines

# COMMAND ----------

def run_metadata_driven_pipeline(pipeline_id: str):
    """
    Run a data pipeline using metadata configuration
    """
    from databricks_integration import DatabricksMetadataManager
    
    # Get metadata
    metadata_manager = DatabricksMetadataManager(spark, "metadata", "pipeline_configs")
    metadata = metadata_manager.get_metadata(pipeline_id)
    
    if not metadata:
        raise ValueError(f"Pipeline not found: {pipeline_id}")
    
    print(f"📋 Running pipeline: {metadata['pipeline_name']}")
    
    # Read source data
    print(f"📥 Reading from: {metadata['source']['source_location']}")
    df = spark.read \
        .format(metadata['source']['file_format']) \
        .load(metadata['source']['source_location'])
    
    # Apply data quality rules
    print(f"✅ Applying {len(metadata['data_quality_rules'])} DQ rules...")
    for rule in metadata['data_quality_rules']:
        if rule['rule_type'] == 'null_check':
            df = df.filter(f"{rule['column_name']} IS NOT NULL")
        elif rule['rule_type'] == 'unique_check':
            # Add unique check logic
            pass
    
    # Apply transformations
    print(f"🔄 Applying {len(metadata['transformations'])} transformations...")
    for transform in metadata['transformations']:
        if transform['transformation_type'] == 'cast':
            # Parse cast logic
            col_name = transform['column_name']
            target_type = transform['transformation_logic'].split('as ')[1].strip(')')
            df = df.withColumn(col_name, df[col_name].cast(target_type))
        elif transform['transformation_type'] == 'filter':
            df = df.filter(transform['transformation_logic'])
    
    # Write to target
    target_table = f"{metadata['target']['target_database']}.{metadata['target']['target_table']}"
    print(f"💾 Writing to: {target_table}")
    
    df.write \
        .format("delta") \
        .mode(metadata['target']['sync_mode']) \
        .saveAsTable(target_table)
    
    print(f"✅ Pipeline completed successfully!")
    
    return df.count()

# Example usage:
# record_count = run_metadata_driven_pipeline("pipeline_20240101_120000")
# print(f"Processed {record_count} records")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Schedule Pipeline Execution

# COMMAND ----------

# Example: Create a scheduled job
from databricks.sdk import WorkspaceClient
from databricks.sdk.service import jobs

w = WorkspaceClient()

# Create job for each active pipeline
metadata_manager = DatabricksMetadataManager(spark, "metadata", "pipeline_configs")
pipelines = metadata_manager.list_all_pipelines(active_only=True)

for pipeline in pipelines:
    job_config = jobs.CreateJob(
        name=f"Metadata Pipeline: {pipeline['pipeline_name']}",
        tasks=[
            jobs.Task(
                task_key="run_pipeline",
                notebook_task=jobs.NotebookTask(
                    notebook_path="/path/to/this/notebook",
                    base_parameters={"pipeline_id": pipeline['pipeline_id']}
                ),
                existing_cluster_id=spark.conf.get("spark.databricks.clusterUsageTags.clusterId")
            )
        ],
        schedule=jobs.CronSchedule(
            quartz_cron_expression="0 0 0 * * ?",  # Daily at midnight
            timezone_id="UTC"
        )
    )
    
    # Uncomment to create jobs
    # job = w.jobs.create(**job_config.as_dict())
    # print(f"Created job: {job.job_id} for pipeline: {pipeline['pipeline_name']}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Monitoring and Maintenance

# COMMAND ----------

# View pipeline statistics
display(spark.sql("""
SELECT 
    COUNT(*) as total_pipelines,
    SUM(CASE WHEN is_active THEN 1 ELSE 0 END) as active_pipelines,
    COUNT(DISTINCT source.source_name) as unique_sources,
    COUNT(DISTINCT target.target_database) as unique_targets
FROM metadata.pipeline_configs.pipeline_metadata
"""))

# COMMAND ----------

# View pipelines by source
display(spark.sql("""
SELECT 
    source.source_name,
    source.file_format,
    COUNT(*) as pipeline_count
FROM metadata.pipeline_configs.pipeline_metadata
WHERE is_active = true
GROUP BY source.source_name, source.file_format
ORDER BY pipeline_count DESC
"""))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 9. Cleanup (Optional)

# COMMAND ----------

# Stop Streamlit app
# %sh pkill -f streamlit

# Drop test data
# spark.sql("DELETE FROM metadata.pipeline_configs.pipeline_metadata WHERE pipeline_name = 'test_pipeline'")
