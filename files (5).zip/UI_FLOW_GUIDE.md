# UI Flow Guide - Pipeline Metadata Builder

This document shows the complete user interface flow through the Streamlit application.

---

## 🎬 Screen Flow Overview

```
Welcome → Pipeline Info → Source System → Source Columns → 
Data Quality → Transformations → Target Config → Review → Complete
```

---

## Screen 1: Welcome Screen

```
┌─────────────────────────────────────────────────────────────┐
│  🤖 Pipeline Metadata Builder                               │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Welcome! Let's build your data pipeline metadata together. │
│                                                              │
│  ℹ️  I'll guide you through creating metadata for your      │
│     Spark pipeline. This replaces your Excel template       │
│     and will generate a JSON configuration that's stored    │
│     in your Delta table.                                    │
│                                                              │
│  What we'll collect:                                        │
│  • Source information (system, location, columns)           │
│  • Data quality rules                                       │
│  • Transformation logic                                     │
│  • Target configuration                                     │
│                                                              │
│  ┌──────────────────────────┐  ┌──────────────┐            │
│  │ 🚀 Start Building Metadata│  │ 📥 Import    │            │
│  └──────────────────────────┘  │   Existing   │            │
│                                 └──────────────┘            │
└─────────────────────────────────────────────────────────────┘
```

**Actions:**
- Click "Start Building Metadata" to begin
- Click "Import Existing" to load saved config

---

## Screen 2: Pipeline Information

```
┌─────────────────────────────────────────────────────────────┐
│  📋 Pipeline Information                                    │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Pipeline Name *                                            │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ customer_data_ingestion                               │  │
│  └──────────────────────────────────────────────────────┘  │
│  A unique identifier for this pipeline                      │
│                                                              │
│  Description                                                │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ Daily ingestion of customer data from Salesforce     │  │
│  │                                                       │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
│  Tags (comma-separated)                                     │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ daily, customer, bronze-layer                         │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
│  ┌──────────┐  ┌──────────────────────────────────────┐   │
│  │ ⬅️ Back  │  │         Next ➡️                       │   │
│  └──────────┘  └──────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

**Required Fields:**
- Pipeline Name (must be unique)

**Optional Fields:**
- Description (recommended)
- Tags (helpful for searching)

---

## Screen 3: Source System

```
┌─────────────────────────────────────────────────────────────┐
│  📁 Source System                                           │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Source System Name *                                       │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ salesforce                                            │  │
│  └──────────────────────────────────────────────────────┘  │
│  Name of the source system or data source                  │
│                                                              │
│  Source Location *                                          │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ s3://data-lake/raw/salesforce/customers/             │  │
│  └──────────────────────────────────────────────────────┘  │
│  Full path to the source data                              │
│                                                              │
│  File Format *                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ parquet ▼                                             │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
│  Read Options                                               │
│  (Additional options based on format selection)             │
│                                                              │
│  ┌──────────┐  ┌──────────────────────────────────────┐   │
│  │ ⬅️ Back  │  │         Next ➡️                       │   │
│  └──────────┘  └──────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

**Format Options:**
- parquet, csv, json, delta, avro, orc

**Format-Specific Options:**
- CSV: header, delimiter, quote character
- JSON: multiline option
- Delta: merge schema option

---

## Screen 4: Source Columns

```
┌─────────────────────────────────────────────────────────────┐
│  📊 Source Columns                                          │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Define your source columns.                                │
│                                                              │
│  ▼ ➕ Quick Add Columns                                     │
│  ┌────────────────┬────────────────┬──────────┐            │
│  │ Column Name    │ Data Type  ▼   │   Add    │            │
│  ├────────────────┼────────────────┼──────────┤            │
│  │ customer_id    │ bigint         │    ✓     │            │
│  └────────────────┴────────────────┴──────────┘            │
│                                                              │
│  ▼ 📋 Bulk Paste from Excel                                │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ customer_id:bigint                                    │  │
│  │ first_name:string                                     │  │
│  │ email:string                                          │  │
│  └──────────────────────────────────────────────────────┘  │
│  [ Parse and Add ]                                          │
│                                                              │
│  Current Columns                                            │
│  ┌──────────────┬───────────┬─────────────────────────┐   │
│  │ Column Name  │ Data Type │ Description             │   │
│  ├──────────────┼───────────┼─────────────────────────┤   │
│  │ customer_id  │ bigint    │ Primary key             │   │
│  │ first_name   │ string    │                         │   │
│  │ last_name    │ string    │                         │   │
│  │ email        │ string    │                         │   │
│  │ phone        │ string    │                         │   │
│  └──────────────┴───────────┴─────────────────────────┘   │
│                                                              │
│  ┌──────────┐  ┌──────────────────────────────────────┐   │
│  │ ⬅️ Back  │  │         Next ➡️                       │   │
│  └──────────┘  └──────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

**Methods to Add Columns:**
1. Quick Add: One at a time
2. Bulk Paste: Multiple from Excel
3. Direct Edit: Edit in table

---

## Screen 5: Data Quality Rules

```
┌─────────────────────────────────────────────────────────────┐
│  ✅ Data Quality Rules                                      │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Define data quality checks for your pipeline.              │
│                                                              │
│  ▼ ➕ Add Data Quality Rule                                │
│  ┌────────────────────────────────────────────────────┐    │
│  │  Column to Check:  customer_id ▼                   │    │
│  │                                                     │    │
│  │  Rule Type:        not_null ▼                      │    │
│  │                                                     │    │
│  │  Error Threshold:  [=========>] 0%                 │    │
│  │                                                     │    │
│  │           [ Add Rule ]                             │    │
│  └────────────────────────────────────────────────────┘    │
│                                                              │
│  Current Rules                                              │
│  ▼ customer_id - not_null                                  │
│     {"column_name": "customer_id", "rule_type": "not_null"} │
│     [ 🗑️ Remove ]                                          │
│                                                              │
│  ▼ email - regex_match                                     │
│     {"column_name": "email", "pattern": "^[a-zA-Z0-9..."}  │
│     [ 🗑️ Remove ]                                          │
│                                                              │
│  ┌──────────┐  ┌──────────────────────────────────────┐   │
│  │ ⬅️ Back  │  │         Next ➡️                       │   │
│  └──────────┘  └──────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

**Rule Types:**
- not_null, unique, valid_values, regex_match
- range_check, length_check, date_format, custom_sql

---

## Screen 6: Transformations

```
┌─────────────────────────────────────────────────────────────┐
│  🔄 Transformations                                         │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Define transformations to apply to your data.              │
│                                                              │
│  ▼ ➕ Add Transformation                                   │
│  ┌────────────────────────────────────────────────────┐    │
│  │  Transformation Name:  calculate_full_name         │    │
│  │                                                     │    │
│  │  Type:                 derive ▼                    │    │
│  │                                                     │    │
│  │  Target Column:        full_name                   │    │
│  │                                                     │    │
│  │  Source Columns:       [first_name, last_name]     │    │
│  │                                                     │    │
│  │  Logic:                                            │    │
│  │  ┌──────────────────────────────────────────────┐  │    │
│  │  │ concat(first_name, ' ', last_name)           │  │    │
│  │  └──────────────────────────────────────────────┘  │    │
│  │                                                     │    │
│  │  Description:          Create full name field      │    │
│  │                                                     │    │
│  │           [ Add Transformation ]                   │    │
│  └────────────────────────────────────────────────────┘    │
│                                                              │
│  Current Transformations                                    │
│  ▼ calculate_full_name (derive)                            │
│     Target: full_name                                       │
│     Sources: first_name, last_name                          │
│     concat(first_name, ' ', last_name)                      │
│     [ 🗑️ Remove ]                                          │
│                                                              │
│  ┌──────────┐  ┌──────────────────────────────────────┐   │
│  │ ⬅️ Back  │  │         Next ➡️                       │   │
│  └──────────┘  └──────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

**Transformation Types:**
- cast, rename, derive, filter, aggregate, join, custom_sql

---

## Screen 7: Target Configuration

```
┌─────────────────────────────────────────────────────────────┐
│  🎯 Target Configuration                                    │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Target Database *        Target Table *                    │
│  ┌──────────────────┐    ┌──────────────────────────┐      │
│  │ bronze           │    │ customer_data            │      │
│  └──────────────────┘    └──────────────────────────┘      │
│                                                              │
│  Target Schema            Sync Mode *                       │
│  ┌──────────────────┐    ┌──────────────────────────┐      │
│  │ default          │    │ append ▼                 │      │
│  └──────────────────┘    └──────────────────────────┘      │
│                                                              │
│  Partitioning (Optional)                                    │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ Partition Columns:  [ingestion_date]                 │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
│  ┌──────────┐  ┌──────────────────────────────────────┐   │
│  │ ⬅️ Back  │  │         Next ➡️                       │   │
│  └──────────┘  └──────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

**Sync Modes:**
- append: Add new records
- overwrite: Replace all data
- merge: Upsert (requires merge keys)

---

## Screen 8: Review & Generate

```
┌─────────────────────────────────────────────────────────────┐
│  📋 Review & Generate                                       │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Review your pipeline metadata before generating JSON       │
│                                                              │
│  ▼ 📋 Pipeline Information                                 │
│     Name: customer_data_ingestion                           │
│     Description: Daily ingestion from Salesforce            │
│     Tags: daily, customer, bronze                           │
│                                                              │
│  ▼ 📁 Source Information                                   │
│     System: salesforce                                      │
│     Location: s3://data-lake/raw/salesforce/customers/      │
│     Format: parquet                                         │
│     Columns: 5                                              │
│     [x] Show columns                                        │
│                                                              │
│  ▼ ✅ Data Quality Rules (2)                               │
│     - customer_id: not_null                                 │
│     - email: regex_match                                    │
│                                                              │
│  ▼ 🔄 Transformations (1)                                  │
│     - calculate_full_name: derive                           │
│                                                              │
│  ▼ 🎯 Target Configuration                                 │
│     Database: bronze                                        │
│     Table: customer_data                                    │
│     Sync Mode: append                                       │
│                                                              │
│  ┌──────────────┐              ┌──────────────────────┐    │
│  │ ⬅️ Back to   │              │ ✅ Generate JSON     │    │
│  │    Edit      │              │                      │    │
│  └──────────────┘              └──────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

**Actions:**
- Review all configurations
- Go back to edit if needed
- Generate final JSON

---

## Screen 9: Complete

```
┌─────────────────────────────────────────────────────────────┐
│  🎉 Metadata Generated Successfully!                        │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ✅ Pipeline metadata for customer_data_ingestion has been  │
│     generated!                                              │
│                                                              │
│  Generated JSON Configuration                               │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ {                                                     │  │
│  │   "pipeline_id": "pipeline_20250113_120000",        │  │
│  │   "pipeline_name": "customer_data_ingestion",       │  │
│  │   "source": {                                        │  │
│  │     "source_name": "salesforce",                    │  │
│  │     ...                                              │  │
│  │   }                                                  │  │
│  │ }                                                     │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────────┐   │
│  │ 📥 Download  │ │ 📋 Copy JSON │ │ 🔄 Start New     │   │
│  │    JSON      │ │              │ │                  │   │
│  └──────────────┘ └──────────────┘ └──────────────────┘   │
│                                                              │
│  💾 Save to Delta Table                                    │
│  Next Steps:                                                │
│  1. Copy the JSON above                                    │
│  2. Use the PySpark code below in Databricks               │
│                                                              │
│  [Code example shown for saving to Delta]                  │
│                                                              │
│  📊 Summary                                                │
│  Source Columns: 5     DQ Rules: 2                         │
│  Transformations: 1    Sync Mode: append                   │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

**Actions:**
- Download JSON file
- Copy JSON to clipboard
- View save instructions
- Start new pipeline

---

## Sidebar (Visible on All Screens)

```
┌─────────────────────┐
│  🤖 Metadata Bot    │
├─────────────────────┤
│                     │
│  Progress           │
│  [========>   ] 6/8 │
│  Step 6 of 8        │
│                     │
│  ─────────────────  │
│                     │
│  Current Step       │
│  ℹ️ Target Config   │
│                     │
│  ─────────────────  │
│                     │
│  Summary            │
│  📋 Pipeline:       │
│  customer_data_...  │
│  📊 Columns: 5      │
│  ✅ DQ Rules: 2     │
│  🔄 Transforms: 1   │
│                     │
│  ─────────────────  │
│                     │
│  ▼ ❓ Help          │
│     Tips & Support  │
│                     │
└─────────────────────┘
```

---

## Navigation Pattern

**Forward Navigation:**
- Click "Next ➡️" button
- Form validation before proceeding
- Progress saved automatically

**Backward Navigation:**
- Click "⬅️ Back" button
- Returns to previous screen
- Data preserved

**Skip Optional Sections:**
- Data Quality (optional)
- Transformations (optional)
- Can add later if needed

---

## Key UI Features

✅ **Progress Indicator:** Shows current step  
✅ **Validation:** Real-time field validation  
✅ **Auto-Save:** Data persisted in session  
✅ **Bulk Import:** Paste from Excel  
✅ **Interactive Tables:** Edit columns inline  
✅ **Expandable Sections:** Collapsible panels  
✅ **Summary Sidebar:** Always visible stats  
✅ **Help Section:** Context-sensitive help  

---

## Keyboard Navigation

- **Tab**: Move between fields
- **Enter**: Submit forms
- **Escape**: Close dialogs
- **Ctrl+R**: Rerun app (if needed)

---

**This completes the UI flow guide. Users should now have a clear understanding of the entire interface workflow.**
