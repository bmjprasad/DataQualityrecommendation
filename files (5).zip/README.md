# Pipeline Metadata Builder - Streamlit Application

A conversational bot interface built with Streamlit to collect and manage pipeline metadata for Spark-based data frameworks. This replaces Excel-based metadata templates with an interactive, guided experience.

## Features

- 🤖 **Conversational Interface**: Guided step-by-step metadata collection
- 📊 **Progress Tracking**: Visual progress indicator for metadata completion
- ✅ **Data Quality Rules**: Define validation rules (null checks, format validation, range checks, etc.)
- 🔄 **Transformations**: Configure data transformations (cast, rename, derive, filter, aggregate)
- 💾 **JSON Export**: Export metadata to JSON format
- 🔗 **Databricks Integration**: Save metadata directly to Delta tables
- 📝 **Schema Import**: Upload CSV files with column definitions

## Installation

### Local Development

```bash
# Install dependencies
pip install -r requirements.txt

# Run the app
streamlit run metadata_bot_app.py
```

### Databricks Deployment

Upload to DBFS and create a Databricks App or run in a notebook.

## Usage Example

```
Bot: What would you like to name this pipeline?
You: sales_etl_pipeline

Bot: What's the name of your source system?
You: sales_database

Bot: Where is the source data located?
You: s3://company-data-lake/raw/sales/

Bot: What's the file format?
You: parquet

Bot: Tell me about source columns...
You: order_id:int, customer_id:int, amount:double, order_date:timestamp

[Continue through data quality rules, transformations, and target config]
```

## JSON Output

```json
{
  "pipeline_id": "pipeline_20240101_120000",
  "pipeline_name": "sales_etl_pipeline",
  "source": {
    "source_name": "sales_database",
    "source_location": "s3://company-data-lake/raw/sales/",
    "source_columns": [
      {"name": "order_id", "type": "int"},
      {"name": "amount", "type": "double"}
    ],
    "file_format": "parquet"
  },
  "data_quality_rules": [...],
  "transformations": [...],
  "target": {...}
}
```

## Databricks Integration

```python
from databricks_integration import DatabricksMetadataManager
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
metadata_manager = DatabricksMetadataManager(spark, "metadata", "pipeline_configs")

# Save metadata
pipeline_id = metadata_manager.save_metadata(metadata_dict)

# Retrieve metadata
metadata = metadata_manager.get_metadata(pipeline_id)

# Use in pipeline
source_df = spark.read.format(metadata['source']['file_format']) \
    .load(metadata['source']['source_location'])
```

## License

MIT License
