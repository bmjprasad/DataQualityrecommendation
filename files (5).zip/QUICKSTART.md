# Quick Start Guide - Pipeline Metadata Builder

## 🚀 Get Started in 5 Minutes

### Option 1: Run Locally (Fastest)

```bash
# 1. Install dependencies
pip install streamlit pandas

# 2. Run the app
streamlit run metadata_bot_app.py

# 3. Open browser to http://localhost:8501
```

### Option 2: Deploy to Databricks

```python
# 1. In Databricks notebook, install Streamlit
%pip install streamlit

# 2. Upload files to DBFS
dbutils.fs.cp("local/metadata_bot_app.py", "dbfs:/apps/metadata-builder/")

# 3. Run the app
%sh
cd /dbfs/apps/metadata-builder/
streamlit run metadata_bot_app.py --server.port 8501 &

# 4. Access via driver proxy URL (see deployment guide)
```

## 📝 Your First Pipeline (2 Minutes)

1. **Open the app** and click "Start"

2. **Basic Info:**
   ```
   Pipeline Name: my_first_pipeline
   Source Name: customer_data
   Source Location: s3://my-bucket/customers/
   File Format: parquet
   ```

3. **Define Columns:**
   ```
   Enter: id:int, name:string, email:string, created_at:timestamp
   ```

4. **Add Data Quality Rule:**
   - Column: `email`
   - Rule Type: `format_validation`
   - Pattern: `^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$`

5. **Target Config:**
   ```
   Database: analytics
   Table: customers
   Sync Mode: append
   ```

6. **Review & Confirm** - Download your JSON!

## 📊 Use Metadata in Your Pipeline

```python
# Read the generated JSON
import json
with open('my_first_pipeline_20240101_120000.json') as f:
    metadata = json.load(f)

# Use in Spark
from pyspark.sql import SparkSession
spark = SparkSession.builder.getOrCreate()

# Read source
df = spark.read \
    .format(metadata['source']['file_format']) \
    .load(metadata['source']['source_location'])

# Apply DQ rules
for rule in metadata['data_quality_rules']:
    if rule['rule_type'] == 'null_check':
        df = df.filter(f"{rule['column_name']} IS NOT NULL")

# Write to target
target = f"{metadata['target']['target_database']}.{metadata['target']['target_table']}"
df.write.mode(metadata['target']['sync_mode']).saveAsTable(target)
```

## 🎯 Common Use Cases

### Use Case 1: Daily Sales ETL
```
Source: s3://data-lake/sales/daily/
Format: parquet
Columns: order_id, amount, date, status
DQ Rules: null_check on order_id, range_check on amount
Transform: cast date to date type
Target: analytics.sales_fact (append)
```

### Use Case 2: Customer Dimension Sync
```
Source: /dbfs/mnt/crm/customers/
Format: json
Columns: id, name, email, phone, updated_at
DQ Rules: format_validation on email, unique_check on id
Transform: derive full_name from first + last
Target: analytics.dim_customer (merge on id)
```

### Use Case 3: Log Processing
```
Source: s3://logs/application/
Format: csv
Columns: timestamp, level, message, user_id
DQ Rules: value_in_list on level (INFO,WARN,ERROR)
Transform: filter where level IN ('ERROR','CRITICAL')
Target: monitoring.error_logs (append)
```

## 🔧 Customization Tips

**Add Custom Rule Types:**
Edit line ~340 in `metadata_bot_app.py`:
```python
rule_type = st.selectbox(
    "Rule Type",
    ["null_check", "unique_check", "your_custom_rule"],
    ...
)
```

**Change Default Values:**
Edit `get_prompt()` method in `MetadataConversationBot` class.

**Integrate with Your Tools:**
Add exports to your CI/CD, data catalog, or workflow orchestrator.

## 📚 Next Steps

- Read the full [README.md](README.md) for detailed features
- See [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) for production setup
- Check [example_usage.py](example_usage.py) for code examples
- Import [databricks_notebook.py](databricks_notebook.py) to your workspace

## 💡 Pro Tips

1. **Use Schema Inference**: Type "infer" when asked about columns
2. **Template Pipelines**: Export JSON and modify for similar pipelines
3. **Version Control**: Store metadata JSON files in Git
4. **Automate**: Create jobs that read metadata and run pipelines
5. **Monitor**: Query metadata table to track all your pipelines

## ❓ Need Help?

- Check troubleshooting section in README.md
- Review example files
- Test with small datasets first
- Use the "Start Over" button if stuck

## 🎉 That's It!

You now have a conversational interface for managing pipeline metadata. 
No more Excel templates! 🎊
