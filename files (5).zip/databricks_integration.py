"""
Databricks Integration Module
Handles saving and retrieving metadata from Delta tables
"""

from pyspark.sql import SparkSession
from delta.tables import DeltaTable
from typing import Dict, List, Optional
import json
from datetime import datetime


class DatabricksMetadataManager:
    """Manage metadata storage in Databricks Delta tables"""
    
    def __init__(self, spark: SparkSession, catalog: str = "metadata", schema: str = "pipeline_configs"):
        self.spark = spark
        self.catalog = catalog
        self.schema = schema
        self.table_name = f"{catalog}.{schema}.pipeline_metadata"
        
        # Initialize table if it doesn't exist
        self._create_table_if_not_exists()
    
    def _create_table_if_not_exists(self):
        """Create the metadata table if it doesn't exist"""
        
        ddl = f"""
        CREATE TABLE IF NOT EXISTS {self.table_name} (
            pipeline_id STRING,
            pipeline_name STRING,
            source STRUCT<
                source_name: STRING,
                source_location: STRING,
                source_columns: ARRAY<STRUCT<name: STRING, type: STRING>>,
                file_format: STRING
            >,
            data_quality_rules ARRAY<STRUCT<
                column_name: STRING,
                rule_type: STRING,
                rule_config: MAP<STRING, STRING>
            >>,
            transformations ARRAY<STRUCT<
                column_name: STRING,
                transformation_type: STRING,
                transformation_logic: STRING
            >>,
            target STRUCT<
                target_table: STRING,
                target_database: STRING,
                sync_mode: STRING,
                merge_keys: ARRAY<STRING>
            >,
            created_at TIMESTAMP,
            created_by STRING,
            updated_at TIMESTAMP,
            is_active BOOLEAN
        ) USING DELTA
        """
        
        try:
            self.spark.sql(ddl)
            print(f"✅ Table {self.table_name} is ready")
        except Exception as e:
            print(f"⚠️ Error creating table: {str(e)}")
    
    def save_metadata(self, metadata: Dict) -> str:
        """Save metadata to Delta table"""
        try:
            metadata['updated_at'] = datetime.now().isoformat()
            df = self.spark.createDataFrame([metadata])
            df.write.format("delta").mode("append").saveAsTable(self.table_name)
            print(f"✅ Metadata saved: {metadata['pipeline_id']}")
            return metadata['pipeline_id']
        except Exception as e:
            print(f"❌ Error saving metadata: {str(e)}")
            raise
    
    def get_metadata(self, pipeline_id: str) -> Optional[Dict]:
        """Retrieve metadata by pipeline_id"""
        try:
            df = self.spark.read.table(self.table_name) \
                .filter(f"pipeline_id = '{pipeline_id}'") \
                .filter("is_active = true")
            
            if df.count() > 0:
                return df.collect()[0].asDict()
            return None
        except Exception as e:
            print(f"❌ Error retrieving metadata: {str(e)}")
            return None
    
    def list_all_pipelines(self, active_only: bool = True) -> List[Dict]:
        """List all pipeline metadata"""
        try:
            df = self.spark.read.table(self.table_name)
            if active_only:
                df = df.filter("is_active = true")
            df = df.orderBy("created_at", ascending=False)
            return [row.asDict() for row in df.collect()]
        except Exception as e:
            print(f"❌ Error listing pipelines: {str(e)}")
            return []
