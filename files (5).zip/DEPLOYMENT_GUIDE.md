# Databricks Deployment Guide

## Quick Start Guide for Deploying to Databricks

### Step 1: Upload Files to DBFS

**Option A: Using Databricks UI**
1. Go to Databricks Workspace
2. Navigate to Data → DBFS
3. Create folder: `/apps/metadata-builder/`
4. Upload all files:
   - metadata_bot_app.py
   - databricks_integration.py
   - requirements.txt

**Option B: Using Databricks CLI**
```bash
# Install Databricks CLI
pip install databricks-cli

# Configure authentication
databricks configure --token

# Upload files
databricks fs cp metadata_bot_app.py dbfs:/apps/metadata-builder/
databricks fs cp databricks_integration.py dbfs:/apps/metadata-builder/
databricks fs cp requirements.txt dbfs:/apps/metadata-builder/
```

**Option C: Using Python in Notebook**
```python
# Create directory
dbutils.fs.mkdirs("/apps/metadata-builder/")

# Upload files (copy content to variables)
dbutils.fs.put("/apps/metadata-builder/metadata_bot_app.py", metadata_bot_code, True)
dbutils.fs.put("/apps/metadata-builder/databricks_integration.py", integration_code, True)
dbutils.fs.put("/apps/metadata-builder/requirements.txt", requirements, True)
```

### Step 2: Create Cluster with Required Libraries

1. Create a new cluster or use existing
2. Install libraries:
   - PyPI: `streamlit>=1.28.0`
   - PyPI: `delta-spark>=3.0.0`

Or use cluster init script:
```bash
#!/bin/bash
pip install streamlit pandas delta-spark
```

### Step 3: Create Metadata Table

Run in Databricks notebook:

```python
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

# Create catalog and schema
spark.sql("CREATE CATALOG IF NOT EXISTS metadata")
spark.sql("CREATE SCHEMA IF NOT EXISTS metadata.pipeline_configs")

# Create table
spark.sql("""
CREATE TABLE IF NOT EXISTS metadata.pipeline_configs.pipeline_metadata (
    pipeline_id STRING,
    pipeline_name STRING,
    source STRUCT<
        source_name: STRING,
        source_location: STRING,
        source_columns: ARRAY<STRUCT<name: STRING, type: STRING>>,
        file_format: STRING
    >,
    data_quality_rules ARRAY<STRUCT<
        column_name: STRING,
        rule_type: STRING,
        rule_config: MAP<STRING, STRING>
    >>,
    transformations ARRAY<STRUCT<
        column_name: STRING,
        transformation_type: STRING,
        transformation_logic: STRING
    >>,
    target STRUCT<
        target_table: STRING,
        target_database: STRING,
        sync_mode: STRING,
        merge_keys: ARRAY<STRING>
    >,
    created_at TIMESTAMP,
    created_by STRING,
    updated_at TIMESTAMP,
    is_active BOOLEAN
) USING DELTA
""")

print("✅ Metadata table created successfully!")
```

### Step 4: Deploy Streamlit App

**Option A: Run in Notebook (Development)**
```python
# Install dependencies
%pip install streamlit

# Run app
%sh
cd /dbfs/apps/metadata-builder/
streamlit run metadata_bot_app.py --server.port 8501 --server.address 0.0.0.0 &

# Access via: https://<databricks-instance>/driver-proxy/o/<org-id>/<cluster-id>/8501/
```

**Option B: Databricks Apps (Production)**
```python
from databricks.sdk import WorkspaceClient

w = WorkspaceClient()

# Create app
app = w.apps.create(
    name="pipeline-metadata-builder",
    description="Conversational metadata builder",
    source_code_path="/apps/metadata-builder/"
)

print(f"App created: {app.url}")
```

**Option C: External Hosting (Streamlit Cloud/AWS/Azure)**
1. Deploy to external platform
2. Configure Databricks connection:

```python
# Add to metadata_bot_app.py
import os
from databricks import sql

@st.cache_resource
def get_databricks_connection():
    return sql.connect(
        server_hostname=os.getenv("DATABRICKS_SERVER_HOSTNAME"),
        http_path=os.getenv("DATABRICKS_HTTP_PATH"),
        access_token=os.getenv("DATABRICKS_TOKEN")
    )
```

3. Set environment variables in hosting platform:
```
DATABRICKS_SERVER_HOSTNAME=<your-workspace>.databricks.com
DATABRICKS_HTTP_PATH=/sql/1.0/warehouses/<warehouse-id>
DATABRICKS_TOKEN=<your-token>
```

### Step 5: Configure Permissions

```sql
-- Grant permissions to users/groups
GRANT SELECT, INSERT, UPDATE ON TABLE metadata.pipeline_configs.pipeline_metadata TO `data_engineers`;
GRANT SELECT ON TABLE metadata.pipeline_configs.pipeline_metadata TO `analysts`;
```

### Step 6: Test the Application

1. Open the Streamlit app
2. Create a test pipeline:
   - Name: `test_pipeline`
   - Source: `s3://test-bucket/data/`
   - Format: `parquet`
   - Columns: `id:int, name:string`
   - Target: `test.test_table`

3. Verify in Databricks:
```sql
SELECT * FROM metadata.pipeline_configs.pipeline_metadata;
```

## Integration with Existing Pipelines

### Using Metadata in Spark Jobs

```python
from databricks_integration import DatabricksMetadataManager
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
metadata_manager = DatabricksMetadataManager(
    spark,
    catalog="metadata",
    schema="pipeline_configs"
)

# Get metadata
pipeline_id = "pipeline_20240101_120000"
metadata = metadata_manager.get_metadata(pipeline_id)

# Use in pipeline
df = spark.read \
    .format(metadata['source']['file_format']) \
    .load(metadata['source']['source_location'])

# Apply transformations
for transform in metadata['transformations']:
    if transform['transformation_type'] == 'cast':
        # Parse and apply cast
        pass

# Apply DQ rules
for rule in metadata['data_quality_rules']:
    if rule['rule_type'] == 'null_check':
        df = df.filter(f"{rule['column_name']} IS NOT NULL")

# Write to target
target = f"{metadata['target']['target_database']}.{metadata['target']['target_table']}"
df.write.format("delta").mode(metadata['target']['sync_mode']).saveAsTable(target)
```

### Creating Workflows

```python
# Create Databricks Job using metadata
from databricks.sdk import WorkspaceClient
from databricks.sdk.service import jobs

w = WorkspaceClient()

# Get all active pipelines
pipelines = metadata_manager.list_all_pipelines()

for pipeline in pipelines:
    job = w.jobs.create(
        name=f"Pipeline: {pipeline['pipeline_name']}",
        tasks=[
            jobs.Task(
                task_key="run_pipeline",
                spark_python_task=jobs.SparkPythonTask(
                    python_file="dbfs:/jobs/run_metadata_pipeline.py",
                    parameters=[pipeline['pipeline_id']]
                ),
                existing_cluster_id="<cluster-id>"
            )
        ]
    )
```

## Monitoring and Maintenance

### View All Pipelines
```sql
SELECT 
    pipeline_id,
    pipeline_name,
    source.source_name,
    target.target_table,
    created_at,
    is_active
FROM metadata.pipeline_configs.pipeline_metadata
WHERE is_active = true
ORDER BY created_at DESC;
```

### Deactivate Pipeline
```python
metadata_manager.update_metadata(
    pipeline_id="pipeline_20240101_120000",
    updates={"is_active": False}
)
```

### Export Metadata
```python
# Export to JSON
metadata_manager.export_to_json(
    pipeline_id="pipeline_20240101_120000",
    output_path="/dbfs/exports/pipeline_metadata.json"
)
```

## Troubleshooting

### Issue: Can't access Streamlit app
- Check if port 8501 is open
- Verify cluster is running
- Check driver proxy URL format

### Issue: Table not found
- Verify catalog and schema exist
- Check permissions
- Run table creation DDL again

### Issue: Import errors
- Ensure all libraries are installed on cluster
- Check Python version compatibility (3.8+)
- Verify PYTHONPATH includes /dbfs/apps/metadata-builder/

## Security Best Practices

1. **Use Unity Catalog** for fine-grained access control
2. **Store credentials in Databricks Secrets**:
```python
token = dbutils.secrets.get(scope="metadata-app", key="databricks-token")
```
3. **Enable audit logging** for metadata changes
4. **Use Service Principals** for app authentication
5. **Implement row-level security** for multi-tenant scenarios

## Next Steps

1. Customize the UI for your organization's needs
2. Add validation rules specific to your data standards
3. Integrate with your CI/CD pipeline
4. Set up monitoring and alerting
5. Create training materials for users

## Support

- Streamlit docs: https://docs.streamlit.io
- Databricks docs: https://docs.databricks.com
- GitHub issues: [your-repo]/issues
